@echo off
setlocal
cd /d "%~dp0"
title SHADE KOREA 5.17.0 - Integrated Edition
where node.exe >nul 2>nul
if errorlevel 1 goto NO_NODE
node scripts\launch.js
if errorlevel 1 goto FAILED
pause
exit /b 0
:NO_NODE
echo Node.js 20.3+ is required. Install Node.js LTS from https://nodejs.org/
:FAILED
echo.
echo SHADE could not start. Read the message above.
pause
exit /b 1

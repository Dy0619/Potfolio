'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {metresPerDegree}=require('./precision');
const {pointSegment}=require('./route-context');
const normalizeDong=value=>String(value??'').normalize('NFC').replace(/\s/g,'');
const registryKey=value=>(typeof value==='string'||typeof value==='number'&&Number.isSafeInteger(value))&&/^[0-9]+(?:-[0-9]+)*$/.test(String(value).trim())&&/[1-9]/.test(String(value))&&String(value).trim().length<=80?String(value).trim():'';

function identity(properties) {
 const fields = Object.fromEntries(Object.entries(properties).map(([key, value]) => [key.replace(/_/g, '').toLowerCase(), String(value ?? '').trim()]));
 const pnu = fields.pnu;
 const rawKey=Object.entries(properties).find(([k])=>k.replace(/_/g,'').toLowerCase()==='mgmbldrgstpk')?.[1];
 const registryId=registryKey(rawKey);
 return /^[0-9]{10}[12][0-9]{8}$/.test(pnu || '') ? { pnu, dong: fields.dongnm || fields.bulddongnm || '', ...(registryId?{registryId}:{}) } : null;
}
function parcelParams(pnu) {
 return { sigunguCd: pnu.slice(0, 5), bjdongCd: pnu.slice(5, 10), platGbCd: pnu[10] === '2' ? '1' : '0', bun: pnu.slice(11, 15), ji: pnu.slice(15, 19) };
}
function matchRecord(building, siblings, records) {
 const id=building.tags.shade_hub_identity;
 const fail=reason=>({record:null,reason});
 if(!id)return fail('missing_identity');
 if(!records.length)return fail('no_records');
 const expected=parcelParams(id.pnu);
 const matches=records.filter(row=>Object.entries(expected).every(([key,value])=>row[key]!=null&&String(row[key]).trim()!==''&&String(row[key]).trim().padStart(value.length,'0')===value));
 if(!matches.length)return fail('parcel_mismatch');
 if(id.registryId){
  const same=matches.filter(row=>registryKey(row.mgmBldrgstPk)===id.registryId);
  if(same.length!==1)return fail(same.length?'ambiguous_record':'registry_mismatch');
  if(siblings.filter(b=>b.tags.shade_hub_identity?.registryId===id.registryId).length!==1)return fail('ambiguous_footprint');
  if(id.dong&&same[0].dongNm&&normalizeDong(id.dong)!==normalizeDong(same[0].dongNm))return fail('identity_conflict');
  return {record:same[0],method:'registry'};
 }
 if(!normalizeDong(id.dong))return fail('missing_dong');
 const same=matches.filter(row=>normalizeDong(row.dongNm)===normalizeDong(id.dong));
 if(same.length!==1)return fail(same.length?'ambiguous_record':'dong_mismatch');
 if(siblings.filter(b=>normalizeDong(b.tags.shade_hub_identity?.dong)===normalizeDong(id.dong)).length!==1)return fail('ambiguous_footprint');
 return {record:same[0],method:'parcel_dong'};
}
function selectRecord(building,siblings,records){return matchRecord(building,siblings,records).record;}
function applyRecord(building, record) {
 if (!record || building.tags.height) return building;
 const numeric=value=>typeof value==='number'&&Number.isFinite(value)?value:typeof value==='string'&&/^[+]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(value.trim())?Number(value):NaN;
 const height = numeric(record.heit), floors = numeric(record.grndFlrCnt);
 const tags = { ...building.tags };
 if (Number.isFinite(height) && height >= 2 && height <= 400) tags.height = String(height);
 else if (!tags['building:levels'] && Number.isInteger(floors) && floors >= 1 && floors <= 120) tags['building:levels'] = String(floors);
 else return building;
 tags.shade_height_supplemented = true;
 tags.shade_height_source = '건축HUB';
 return { ...building, tags };
}
function createHub({ key, directory, fetcher = fetch }) {
 const pending = new Map(),cooldowns=new Map();let globalCooldown=null;
 let decodedKey = key || '';
 try { decodedKey = decodeURIComponent(decodedKey); } catch { /* Accept raw keys. */ }
 function cacheFile(pnu) { return path.join(directory, crypto.createHash('sha256').update(pnu).digest('hex') + '.json'); }
 function cachedRows(pnu,needsRegistry=false) {
  const file = cacheFile(pnu);
  try {
   const cached = JSON.parse(fs.readFileSync(file, 'utf8'));
   if(needsRegistry&&cached.schema!==2)return null;
   if (Number.isFinite(cached.at) && cached.at <= Date.now() && Date.now() - cached.at < 7 * 86400000 && Array.isArray(cached.rows)&&cached.rows.every(row=>row&&typeof row==='object'&&!Array.isArray(row))) return cached.rows;
  } catch { /* Fetch missing or expired cache entries. */ }
  return null;
 }
 const allowed=['HUB_HTTP_ERROR','HUB_RATE_LIMIT','HUB_AUTH','HUB_SIZE_LIMIT','HUB_INVALID_JSON','HUB_RESPONSE_ERROR','HUB_INCOMPLETE','HUB_PAGE_LIMIT','HUB_REQUEST_BUDGET'];
 const safeReason=error=>['TimeoutError','AbortError'].includes(error?.name)?'HUB_TIMEOUT':allowed.includes(error?.message)?error.message:'HUB_NETWORK_ERROR';
 const number=value=>typeof value==='number'&&Number.isSafeInteger(value)?value:typeof value==='string'&&/^\d+$/.test(value)?Number(value):NaN;
 async function query(pnu,budget,diagnostics,signal) {
  signal?.throwIfAborted();
  if(!signal&&pending.has(pnu)){diagnostics.sharedQueries++;return pending.get(pnu);}
  const file=cacheFile(pnu);
  const operation=(async()=>{
   const kept=[],seen=new Map();let total=null,size=100;
   for(let page=1;page<=5;page++){
    signal?.throwIfAborted();
    if(budget.calls>=12||Date.now()>=budget.stop)throw Error('HUB_REQUEST_BUDGET');
    budget.calls++;diagnostics.pageRequests++;
    const params=new URLSearchParams({...parcelParams(pnu),serviceKey:decodedKey,_type:'json',numOfRows:String(size),pageNo:String(page)});
    const timeout=AbortSignal.timeout(Math.max(1,Math.min(8000,budget.stop-Date.now())));
    const response=await fetcher('https://apis.data.go.kr/1613000/BldRgstHubService/getBrTitleInfo?'+params,{signal:signal?AbortSignal.any([signal,timeout]):timeout});
    if(!response.ok)throw Error(response.status===429?'HUB_RATE_LIMIT':[401,403].includes(response.status)?'HUB_AUTH':'HUB_HTTP_ERROR');
    const raw=await response.text();if(raw.length>2000000)throw Error('HUB_SIZE_LIMIT');
    let json;try{json=JSON.parse(raw).response;}catch{throw Error('HUB_INVALID_JSON');}
    if(!['00','0','000'].includes(String(json?.header?.resultCode)))throw Error('HUB_RESPONSE_ERROR');
    const body=json.body,currentTotal=number(body?.totalCount);
    if(!Number.isSafeInteger(currentTotal)||currentTotal<0)throw Error('HUB_INCOMPLETE');
    if(body.pageNo!=null&&number(body.pageNo)!==page)throw Error('HUB_INCOMPLETE');
    const reportedSize=body.numOfRows==null?size:number(body.numOfRows);
    if(!Number.isInteger(reportedSize)||reportedSize<1||reportedSize>100||(page>1&&reportedSize!==size))throw Error('HUB_INCOMPLETE');
    size=reportedSize;
    if(total===null){total=currentTotal;if(total>size*5)throw Error('HUB_PAGE_LIMIT');}
    else if(total!==currentTotal)throw Error('HUB_INCOMPLETE');
    const items=body.items?.item,rows=Array.isArray(items)?items:items?[items]:[];
    if(rows.length!==Math.min(size,total-kept.length))throw Error('HUB_INCOMPLETE');
    for(const row of rows){
     if(!row||typeof row!=='object'||Array.isArray(row))throw Error('HUB_INCOMPLETE');
     const clean=Object.fromEntries(['sigunguCd','bjdongCd','platGbCd','bun','ji','dongNm','heit','grndFlrCnt','mgmBldrgstPk'].map(k=>[k,row[k]]));
     const pk=registryKey(clean.mgmBldrgstPk),fingerprint=pk?'id:'+pk:JSON.stringify(clean);
     // Duplicate IDs or repeated rows across pages mean completeness is not proven.
     if(seen.has(fingerprint)&&(pk||seen.get(fingerprint)!==page))throw Error('HUB_INCOMPLETE');
     seen.set(fingerprint,page);kept.push(clean);
    }
    signal?.throwIfAborted();
    if(kept.length===total){
     try{fs.mkdirSync(directory,{recursive:true,mode:0o700});const temporary=file+'.'+crypto.randomBytes(6).toString('hex');fs.writeFileSync(temporary,JSON.stringify({schema:2,at:Date.now(),rows:kept}),{mode:0o600});fs.renameSync(temporary,file);}catch{/* Optional cache. */}
     return kept;
    }
   }
   throw Error('HUB_PAGE_LIMIT');
  })();
  if(signal)return operation;
  pending.set(pnu,operation);
  try{return await operation;}finally{pending.delete(pnu);}
 }
 async function enrich(data, routes, deadline, signal) {
  signal?.throwIfAborted();
  const diagnostics = { configured: !!key, queried: 0, upgraded: 0, failed: 0, unmatched: 0, succeeded: 0, eligibleParcels: 0, limited: false, identityAvailable: 0, missingIdentity: 0, cacheHits: 0, networkRequests: 0, remainingParcels: 0, failureReasons: {}, pageRequests: 0, sharedQueries: 0, deferredParcels: 0, matchReasons: {}, matchedBy: {}, emptyParcels: 0 };
  if (!key) return { ...data, hub: diagnostics };
  diagnostics.identityAvailable = data.elements.filter(b => (b.tags.shade_hub_identity?.dong||b.tags.shade_hub_identity?.registryId)).length;
  diagnostics.missingIdentity = data.elements.filter(b => !b.tags.height && !(b.tags.shade_hub_identity?.dong||b.tags.shade_hub_identity?.registryId)).length;
  const groups = new Map();
  for (const building of data.elements) {
   const id = building.tags.shade_hub_identity;
   if (!id) continue;
   if (!groups.has(id.pnu)) groups.set(id.pnu, []);
   groups.get(id.pnu).push(building);
  }
  const origin=routes[0]?.coords[0]||[36,128],m=metresPerDegree(origin[0]);
  const xy=p=>[(p[1]-origin[1])*m.east,(p[0]-origin[0])*m.north];
  const segments=routes.flatMap(r=>r.coords.slice(1).map((p,i)=>[xy(r.coords[i]),xy(p)]));
  const distance=building=>{const p=xy([building.geometry[0].lat,building.geometry[0].lon]);return segments.length?Math.min(...segments.map(([a,b])=>pointSegment(p,a,b))):Math.hypot(...p);};
  const candidates=[...groups].filter(([,buildings])=>buildings.some(b=>!b.tags.height&&(b.tags.shade_hub_identity.dong||b.tags.shade_hub_identity.registryId))).map(([pnu,buildings])=>({pnu,buildings,distance:Math.min(...buildings.map(distance))})).sort((a,b)=>a.distance-b.distance).map(x=>[x.pnu,x.buildings]);
  diagnostics.eligibleParcels = candidates.length;
  const replacements = new Map();
  const stop = Math.min(deadline, Date.now() + 25000),budget={stop,calls:0};
  for(const [pnu,value] of cooldowns)if(value.until<=Date.now())cooldowns.delete(pnu);
  if(globalCooldown?.until<=Date.now())globalCooldown=null;
  function useRows(buildings, rows) {
   diagnostics.succeeded++;if(!rows.length)diagnostics.emptyParcels++;
   for (const building of buildings) {
    if(building.tags.height)continue;
    const match=matchRecord(building,buildings,rows),updated=applyRecord(building,match.record);
    if(updated!==building){replacements.set(building.id,updated);diagnostics.upgraded++;diagnostics.matchedBy[match.method]=(diagnostics.matchedBy[match.method]||0)+1;}
    else{diagnostics.unmatched++;const reason=match.record?(building.tags['building:levels']?'no_height_improvement':'height_unusable'):match.reason;diagnostics.matchReasons[reason]=(diagnostics.matchReasons[reason]||0)+1;}

   }
  }
  // Cache hits never consume the remote request budget, even after the deadline.
  const uncached = [];
  for (const [pnu, buildings] of candidates) {
   const rows = cachedRows(pnu,buildings.some(b=>b.tags.shade_hub_identity?.registryId));
   if (rows !== null) {
    diagnostics.queried++; diagnostics.cacheHits++;
    useRows(buildings, rows);
   } else uncached.push([pnu, buildings]);
  }
  for(const [pnu,buildings] of uncached){
   if(globalCooldown||cooldowns.has(pnu)){diagnostics.deferredParcels++;continue;}
   if(budget.calls>=12||Date.now()+8000>stop)break;
   diagnostics.queried++;diagnostics.networkRequests++;
   try{useRows(buildings,await query(pnu,budget,diagnostics,signal));}
   catch(error){
    signal?.throwIfAborted();
    diagnostics.failed++;const reason=safeReason(error);diagnostics.failureReasons[reason]=(diagnostics.failureReasons[reason]||0)+1;
    if(reason!=='HUB_REQUEST_BUDGET'){
     if(cooldowns.size>=500)cooldowns.delete(cooldowns.keys().next().value);
     const cooldown={until:Date.now()+(reason==='HUB_RATE_LIMIT'?120000:60000),reason};cooldowns.set(pnu,cooldown);
     if(['HUB_AUTH','HUB_RATE_LIMIT'].includes(reason))globalCooldown=cooldown;
    }
   }
  }
  diagnostics.remainingParcels=uncached.length-diagnostics.networkRequests;
  diagnostics.limited=diagnostics.remainingParcels>0||!!diagnostics.failureReasons.HUB_REQUEST_BUDGET||!!diagnostics.failureReasons.HUB_PAGE_LIMIT;
  return { ...data, elements: data.elements.map(b => replacements.get(b.id) || b), hub: diagnostics };
 }
 return { enrich };
}
module.exports = { identity, parcelParams, selectRecord, matchRecord, applyRecord, createHub };

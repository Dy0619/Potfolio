'use strict';
// Explicit semantic aliases only. Do not guess heights from area, terrain altitude, or property order.
const HEIGHT_FIELDS=['height','buld_hght','buld_hg','buldHg','buldHght','bld_hght','building_height','bld_height','높이','건물높이'];
const FLOOR_FIELDS=['grnd_flr_cnt','grndFlrCnt','grnd_flr_co','grndFlrCo','groundFlrCnt','ground_floor_co','buld_flr_co','flr_cnt','floor_count','flrCo','grnd_flr','gro_flo_co','지상층수'];
const normalized=value=>String(value).replace(/_/g,'').toLowerCase();
function readNumber(raw,unit){if(raw===null||raw===undefined||typeof raw==='boolean'||typeof raw==='object')return null;const s=String(raw).trim().replace(/,/g,'');const re=unit?/^([+]?(?:\d+(?:\.\d+)?|\.\d+))\s*(?:m|미터)?$/i:/^([+]?\d+)\s*(?:층)?$/;const m=s.match(re);return m&&Number.isFinite(Number(m[1]))?Number(m[1]):null;}
function buildingHeight(props){
 const entries=Object.entries(props||{});
 for(const alias of HEIGHT_FIELDS)for(const [field,raw] of entries){if(normalized(field)!==normalized(alias))continue;const n=readNumber(raw,true);if(n!==null&&n>=2&&n<=400)return {height:n.toFixed(1),quality:'measured',field};}
 for(const alias of FLOOR_FIELDS)for(const [field,raw] of entries){if(normalized(field)!==normalized(alias))continue;const n=readNumber(raw,false);if(n!==null&&n>=1&&n<=120)return {levels:String(n),quality:'floor-estimate',field};}
 return {quality:'unknown'};
}
const rank=b=>b.tags?.height?2:b.tags?.['building:levels']?1:0;
function enrichExact(primary,secondary){
 // Geometry-derived ids identify the same normalized footprint. A nearby building or parcel ID is insufficient.
 const byManagement=new Map(),baseCounts=new Map();
 for(const b of secondary){const id=b.tags?.shade_join_id;if(id){if(!byManagement.has(id))byManagement.set(id,[]);byManagement.get(id).push(b);}}
 for(const b of primary){const id=b.tags?.shade_join_id;if(id)baseCounts.set(id,(baseCounts.get(id)||0)+1);}
 const matches=new Map();for(const b of secondary){const old=matches.get(b.id);if(!old||rank(b)>rank(old))matches.set(b.id,b);}
 let upgraded=0;
 const elements=primary.map(b=>{const exact=matches.get(b.id),id=b.tags?.shade_join_id,managed=id&&baseCounts.get(id)===1&&byManagement.get(id)?.length===1?byManagement.get(id)[0]:null;const match=exact&&rank(exact)>rank(b)?exact:managed;if(!match||rank(match)<=rank(b))return b;upgraded++;return {...b,tags:{...b.tags,...match.tags,shade_hub_identity:b.tags.shade_hub_identity||match.tags.shade_hub_identity,shade_geometry_unsupported:!!(b.tags.shade_geometry_unsupported||match.tags.shade_geometry_unsupported),shade_height_supplemented:true,shade_height_join:match.id===b.id?'footprint':'management-id'}};});
 return {elements,upgraded};
}
function schemaSummary(features){const fields=new Set();let provided=0,floors=0,unknown=0;for(const f of features){const p=f.properties||{};Object.keys(p).filter(k=>/^[A-Za-z0-9_가-힣]{1,60}$/.test(k)).slice(0,100).forEach(k=>fields.add(k));const h=buildingHeight(p);if(h.height)provided++;else if(h.levels)floors++;else unknown++;}return {fields:[...fields].sort().slice(0,100),provided,floors,unknown};}
module.exports={buildingHeight,enrichExact,schemaSummary};

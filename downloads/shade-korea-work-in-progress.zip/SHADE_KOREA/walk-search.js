'use strict';
const P=require('./precision');
function distance(a,b){const m=P.metresPerDegree((a[0]+b[0])/2);return Math.hypot((a[1]-b[1])*m.east,(a[0]-b[0])*m.north);}
function walkable(tags){const foot=tags.foot;const allowed=['yes','designated','permissive'].includes(foot);if(foot&&!allowed)return false;if(!allowed&&tags.access&&!['yes','permissive','designated','public'].includes(tags.access))return false;if(tags.area==='yes'||tags.indoor==='yes'||tags.tunnel==='yes')return false;return /^(footway|pedestrian|path|steps|living_street|residential|service|unclassified|tertiary|tertiary_link|secondary|secondary_link|primary|primary_link)$/.test(tags.highway||'')||(tags.highway==='cycleway'&&allowed);}
function graphFromWays(ways){
 const nodes=[],edges=[],ids=new Map();
 for(const way of ways){if(!walkable(way.tags||{})||!Array.isArray(way.nodes)||way.nodes.length!==way.geometry?.length)continue;
  const picked=way.geometry.map((p,i)=>{if(!Number.isSafeInteger(way.nodes[i])||way.nodes[i]<=0)return -1;const key=String(way.nodes[i]);if(!Number.isFinite(p.lat)||!Number.isFinite(p.lon)||p.lat<32.8||p.lat>39||p.lon<124||p.lon>132)return -1;if(ids.has(key)){const at=ids.get(key);return distance(nodes[at].coord,[p.lat,p.lon])<1?at:-1;}const at=nodes.length;ids.set(key,at);nodes.push({coord:[p.lat,p.lon],to:[]});return at;});
  for(let i=1;i<picked.length;i++){const a=picked[i-1],b=picked[i];if(a<0||b<0||a===b)continue;const d=distance(nodes[a].coord,nodes[b].coord);if(d<.1||d>1000)continue;const id=edges.length;edges.push({a,b,d,way:way.id,pedestrian:['footway','pedestrian','steps'].includes(way.tags.highway)||['sidewalk','crossing'].includes(way.tags.footway)});const one=way.tags['oneway:foot'];if(one!=='-1')nodes[a].to.push({to:b,id});if(one!=='yes'&&one!=='1'&&one!=='true')nodes[b].to.push({to:a,id});}
 }
 return {nodes,edges};
}
class Heap{constructor(){this.a=[];}push(v){let i=this.a.length;this.a.push(v);while(i){const p=(i-1)>>1;if(this.a[p][0]<=v[0])break;this.a[i]=this.a[p];i=p;}this.a[i]=v;}pop(){const top=this.a[0],last=this.a.pop();if(this.a.length){let i=0;while(i*2+1<this.a.length){let j=i*2+1;if(j+1<this.a.length&&this.a[j+1][0]<this.a[j][0])j++;if(this.a[j][0]>=last[0])break;this.a[i]=this.a[j];i=j;}this.a[i]=last;}return top;}get length(){return this.a.length;}}
function nearest(graph,coord,maxDistance=85){let id=-1,best=maxDistance;for(let i=0;i<graph.nodes.length;i++){if(!graph.nodes[i].to.length)continue;const d=distance(coord,graph.nodes[i].coord);if(d<best){best=d;id=i;}}return id;}
function solve(graph,start,end,cost,maxDistance){
 if(start<0||end<0||start===end)return null;
 const values=Array(graph.nodes.length).fill(Infinity),lengths=Array(graph.nodes.length).fill(Infinity),from=Array(graph.nodes.length).fill(null),queue=new Heap();values[start]=0;lengths[start]=0;queue.push([0,start]);
 while(queue.length){const [value,at]=queue.pop();if(value!==values[at])continue;if(at===end)break;for(const next of graph.nodes[at].to){const edge=graph.edges[next.id],metres=lengths[at]+edge.d;if(metres>maxDistance)continue;const updated=value+cost(edge,next.id);if(updated>=values[next.to])continue;values[next.to]=updated;lengths[next.to]=metres;from[next.to]={at,edge:next.id};queue.push([updated,next.to]);}}
 if(!from[end])return null;const coords=[],edgeIds=[];for(let at=end;at!==start;){coords.push(graph.nodes[at].coord);const previous=from[at];if(!previous)return null;edgeIds.push(previous.edge);at=previous.at;if(coords.length>graph.nodes.length)return null;}coords.push(graph.nodes[start].coord);return {coords:coords.reverse(),edgeIds:edgeIds.reverse(),distance:lengths[end]};
}
function waypoints(path,max=5){const points=path.coords;if(points.length<3)return [];const selected=[];const lengths=[0];for(let i=1;i<points.length;i++)lengths.push(lengths.at(-1)+distance(points[i-1],points[i]));for(let k=1;k<=max;k++){const goal=path.distance*k/(max+1);let best=1;for(let i=1;i<points.length-1;i++)if(Math.abs(lengths[i]-goal)<Math.abs(lengths[best]-goal))best=i;const point=points[best];if(!selected.some(p=>p[0]===point[0]&&p[1]===point[1]))selected.push(point);}return selected;}
function propose(ways,data,date,shortest,detour=.3){
 return proposeAtTimes(ways,data,[date],shortest,detour)[0];
}
function proposeAtTimes(ways,data,dates,shortest,detour=.3){
 const graph=graphFromWays(ways);if(graph.nodes.length>25000||graph.edges.length>45000)return dates.map(()=>({plans:[],status:'network_limit'}));
 const start=nearest(graph,shortest.coords[0]),end=nearest(graph,shortest.coords.at(-1));if(start<0||end<0)return dates.map(()=>({plans:[],status:'network_not_connected'}));
 const origin={lat:shortest.coords[0][0],lng:shortest.coords[0][1]},m=P.metresPerDegree(origin.lat);
 const buildings=(data.elements||[]).map(b=>({tags:b.tags,xy:b.geometry.map(p=>[(p.lon-origin.lng)*m.east,(p.lat-origin.lat)*m.north]),holes:(b.holes||[]).map(r=>r.map(p=>[(p.lon-origin.lng)*m.east,(p.lat-origin.lat)*m.north]))}));
 const eligible=buildings.filter(b=>P.heightRange(b.tags,15).source!=='assumed'&&!b.tags.shade_geometry_unsupported);
 return dates.map(date=>{
 const sun=P.sunPosition(date,origin.lat,origin.lng);
 const index=P.buildIndex(eligible,sun,15);const shade=graph.edges.map(e=>{const a=graph.nodes[e.a].coord,b=graph.nodes[e.b].coord;let total=0,valid=0;const n=Math.min(25,Math.max(2,Math.ceil(e.d/8)));for(let j=0;j<n;j++){const t=(j+.5)/n;const s=P.statusAt(index,((a[1]+(b[1]-a[1])*t)-origin.lng)*m.east,((a[0]+(b[0]-a[0])*t)-origin.lat)*m.north,sun);if(s&&!s.unknown){valid++;total+=Number(s.mid);}}return valid/n>=.9?total/valid:0;});
 const plans=[],seen=new Set(),used=new Set();
 for(const strength of [1,4,10]){
  // This is a bounded candidate search, not a proof of the globally shortest shade route.
  const path=solve(graph,start,end,(e,id)=>e.d*(1+strength*(1-shade[id]))*(used.has(id)?1.12:1)*(e.pedestrian?1:1.08),shortest.distance*(1+detour)+170);
  if(!path)continue;const via=waypoints(path);const key=via.map(p=>p.map(v=>v.toFixed(6)).join(',')).join(';');if(!via.length||seen.has(key))continue;seen.add(key);plans.push({via,origin:'shade-network'});path.edgeIds.forEach(id=>used.add(id));
 }
 return {plans:plans.slice(0,3),status:plans.length?'proposed':'no_candidate',nodes:graph.nodes.length,edges:graph.edges.length};
 });
}
function shadowProbes(data,date,shortest,detour=.3){
 const origin={lat:shortest.coords[0][0],lng:shortest.coords[0][1]},m=P.metresPerDegree(origin.lat),sun=P.sunPosition(date,origin.lat,origin.lng);if(sun.elevation<=5)return [];
 const toXY=p=>[(p[1]-origin.lng)*m.east,(p[0]-origin.lat)*m.north],toCoord=p=>[origin.lat+p[1]/m.north,origin.lng+p[0]/m.east];
 const buildings=(data.elements||[]).map(b=>({tags:b.tags,xy:b.geometry.map(p=>toXY([p.lat,p.lon])),holes:(b.holes||[]).map(r=>r.map(p=>toXY([p.lat,p.lon])))}));const index=P.buildIndex(buildings.filter(b=>P.heightRange(b.tags,15).source!=='assumed'&&!b.tags.shade_geometry_unsupported),sun,15),points=[],line=shortest.coords.map(toXY),maxLateral=Math.min(100,shortest.distance*(1+detour)/3);
 const dSegment=(p,a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/Math.max(.0001,dx*dx+dy*dy)));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy);};
 for(const b of buildings.slice(0,1500)){
  const h=P.heightRange(b.tags,15);if(h.source==='assumed'||b.tags.shade_geometry_unsupported)continue;const length=Math.min(40,h.low/Math.tan(sun.elevation*Math.PI/180)*.5);if(length<.5)continue;
  const dx=-length*Math.sin(sun.azimuth*Math.PI/180),dy=-length*Math.cos(sun.azimuth*Math.PI/180);
  for(let i=0;i<b.xy.length;i++){const a=b.xy[i],z=b.xy[(i+1)%b.xy.length],p=[(a[0]+z[0])/2+dx,(a[1]+z[1])/2+dy];const status=P.statusAt(index,p[0],p[1],sun);if(!status||status.unknown||!status.low)continue;
   let lateral=Infinity;for(let j=1;j<line.length;j++)lateral=Math.min(lateral,dSegment(p,line[j-1],line[j]));if(lateral>maxLateral)continue;
   const coord=toCoord(p);if(distance(coord,shortest.coords[0])<8||distance(coord,shortest.coords.at(-1))<8||distance(coord,shortest.coords[0])+distance(coord,shortest.coords.at(-1))>shortest.distance*(1+detour))continue;
   points.push({coord,lateral});if(points.length>=1500)break;
  }
  if(points.length>=1500)break;
 }
 points.sort((a,b)=>a.lateral-b.lateral);const chosen=[];for(const p of points){if(chosen.every(c=>distance(p.coord,c.via[0])>=15))chosen.push({via:[p.coord],origin:'shadow-probe'});if(chosen.length===3)break;}
 // These are modelled target points, not asserted roads. Only a successful provider route may be displayed.
 return chosen;
}
module.exports={distance,walkable,graphFromWays,solve,waypoints,propose,proposeAtTimes,shadowProbes};

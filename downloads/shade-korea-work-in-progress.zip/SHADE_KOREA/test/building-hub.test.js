'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const H=require('../building-hub');
const pnu='2623010100100010000';
const building={id:'a',tags:{shade_hub_identity:{pnu,dong:'101동'}},geometry:[{lat:35.15,lon:129.06}]};
const row={...H.parcelParams(pnu),dongNm:'101동',heit:'21',grndFlrCnt:'7'};
test('HUB identity needs explicit PNU and matching unique dong',()=>{assert.equal(H.identity({pnu:'bad'}),null);assert.equal(H.selectRecord(building,[building],[row]),row);assert.equal(H.selectRecord(building,[building],[row,row]),null);assert.equal(H.selectRecord({...building,tags:{shade_hub_identity:{pnu,dong:''}}},[building],[row]),null);assert.equal(H.selectRecord(building,[building],[{...row,bun:'9999'}]),null);});
test('HUB provides height or floors without overriding provided height',()=>{assert.equal(H.applyRecord(building,row).tags.height,'21');assert.equal(H.applyRecord(building,{...row,heit:0}).tags['building:levels'],'7');const existing={...building,tags:{...building.tags,height:'25'}};assert.equal(H.applyRecord(existing,row),existing);});
test('HUB successful response is cached and used in public route enrichment',async()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hub-test-'));let calls=0;const hub=H.createHub({key:'fixture',directory:dir,fetcher:async()=>{calls++;return {ok:true,text:async()=>JSON.stringify({response:{header:{resultCode:'00'},body:{totalCount:1,items:{item:row}}}})};}});try{for(let i=0;i<2;i++){const data=await hub.enrich({elements:[building]},[{coords:[[35.15,129.06]]}],Date.now()+30000);assert.equal(data.elements[0].tags.height,'21');assert.equal(data.hub.upgraded,1);}assert.equal(calls,1);}finally{fs.rmSync(dir,{recursive:true,force:true});}});
test('HUB errors preserve original buildings and report failure',async()=>{const hub=H.createHub({key:'fixture',directory:'/missing/hub-test',fetcher:async()=>{throw Error('secret must not escape');}});const data=await hub.enrich({elements:[building]},[{coords:[[35.15,129.06]]}],Date.now()+30000);assert.equal(data.elements[0],building);assert.equal(data.hub.failed,1);assert.ok(!JSON.stringify(data).includes('secret'));});
test('missing zero-valued parcel fields cannot match',()=>{const incomplete={...row};delete incomplete.ji;assert.equal(H.selectRecord(building,[building],[incomplete]),null);});
test('all cache hits are applied and do not consume new query budget',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hub-budget-'));
 const crypto=require('node:crypto');let calls=0;
 const buildings=Array.from({length:28},(_,i)=>({...building,id:String(i),tags:{shade_hub_identity:{pnu:'26230101001'+String(i+1).padStart(4,'0')+'0000',dong:'101동'}}}));
 const responseRow=pnu=>({...row,...H.parcelParams(pnu)});
 for(const b of buildings.slice(0,14)){const pnu=b.tags.shade_hub_identity.pnu;fs.writeFileSync(path.join(dir,crypto.createHash('sha256').update(pnu).digest('hex')+'.json'),JSON.stringify({at:Date.now(),rows:[responseRow(pnu)]}));}
 const hub=H.createHub({key:'fixture',directory:dir,fetcher:async url=>{calls++;const params=new URL(url).searchParams;const r={...row,...Object.fromEntries(['sigunguCd','bjdongCd','platGbCd','bun','ji'].map(k=>[k,params.get(k)]))};return {ok:true,text:async()=>JSON.stringify({response:{header:{resultCode:'00'},body:{totalCount:1,items:{item:r}}}})};}});
 try{
  const first=await hub.enrich({elements:buildings},[{coords:[[35.15,129.06]]}],Date.now()+30000);
  assert.equal(first.hub.cacheHits,14);assert.equal(first.hub.networkRequests,12);assert.equal(first.hub.upgraded,26);assert.equal(first.hub.remainingParcels,2);assert.equal(first.hub.limited,true);
  const second=await hub.enrich({elements:buildings},[{coords:[[35.15,129.06]]}],Date.now()+30000);
  assert.equal(second.hub.cacheHits,26);assert.equal(second.hub.networkRequests,2);assert.equal(second.hub.upgraded,28);assert.equal(second.hub.limited,false);assert.equal(calls,14);
  const expired=await hub.enrich({elements:buildings},[{coords:[[35.15,129.06]]}],Date.now()-1);
  assert.equal(expired.hub.upgraded,28);assert.equal(expired.hub.networkRequests,0);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('safe failure categories preserve buildings without caching failures',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hub-errors-'));
 const fixtures=[
  [async()=>({ok:false,status:429}),'HUB_RATE_LIMIT'],
  [async()=>({ok:false,status:403}),'HUB_AUTH'],
  [async()=>({ok:true,text:async()=>'<secret>key</secret>'}),'HUB_INVALID_JSON'],
  [async()=>{throw new DOMException('secret','TimeoutError');},'HUB_TIMEOUT'],
  [async()=>{throw Error('secret');},'HUB_NETWORK_ERROR'],
  [async()=>({ok:true,text:async()=>JSON.stringify({response:{header:{resultCode:'00'},body:{totalCount:2,items:{item:row}}}})}),'HUB_INCOMPLETE']
 ];
 try{for(const [fetcher,code] of fixtures){const hub=H.createHub({key:'secret',directory:dir,fetcher});const data=await hub.enrich({elements:[building]},[{coords:[[35.15,129.06]]}],Date.now()+30000);assert.deepEqual(data.hub.failureReasons,{[code]:1});assert.equal(data.elements[0],building);assert.ok(!JSON.stringify(data.hub).includes('secret'));assert.equal(fs.readdirSync(dir).length,0);}}
 finally{fs.rmSync(dir,{recursive:true,force:true});}
});

function hubResponse(rows,total,page=1,size=100){return {ok:true,text:async()=>JSON.stringify({response:{header:{resultCode:'00'},body:{pageNo:page,numOfRows:size,totalCount:total,items:{item:rows}}}})};}
const routeFixture=[{coords:[[35.15,129.06]]}];
async function withHub(fetcher,run){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hub-pages-'));try{return await run(H.createHub({key:'secret-fixture',directory:dir,fetcher}),dir);}finally{fs.rmSync(dir,{recursive:true,force:true});}}
const rows101=Array.from({length:101},(_,i)=>({...row,dongNm:(i+1)+'동',mgmBldrgstPk:String(1000+i)}));
test('second page target is matched only after all 101 rows arrive and complete result is cached',async()=>{
 const pages=[];await withHub(async url=>{const page=Number(new URL(url).searchParams.get('pageNo'));pages.push(page);return hubResponse(rows101.slice((page-1)*100,page*100),101,page);},async(hub)=>{
 const result=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(result.hub.upgraded,1);assert.equal(result.hub.pageRequests,2);assert.deepEqual(pages,[1,2]);
 const cached=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(cached.hub.cacheHits,1);assert.equal(cached.hub.pageRequests,0);assert.equal(cached.hub.upgraded,1);
 });
});
test('duplicate dong on a later page prevents falsely unique first-page matching',async()=>{
 const records=rows101.map(r=>({...r}));records[0].dongNm='101동';
 await withHub(async url=>{const page=Number(new URL(url).searchParams.get('pageNo'));return hubResponse(records.slice((page-1)*100,page*100),101,page);},async hub=>{
 const r=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(r.hub.upgraded,0);assert.equal(r.hub.matchReasons.ambiguous_record,1);assert.equal(r.elements[0],building);
 });
});
test('page failure, count drift, repeated records and wrong page index never cache partial rows',async()=>{
 for(const mode of ['failure','count','duplicate','page'])await withHub(async url=>{
 const page=Number(new URL(url).searchParams.get('pageNo'));if(page===1)return hubResponse(rows101.slice(0,100),101,1);
 if(mode==='failure')throw Error('secret');
 return hubResponse([mode==='duplicate'?rows101[0]:rows101[100]],mode==='count'?102:101,mode==='page'?1:2);
 },async(hub,dir)=>{const r=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(r.hub.failed,1);assert.equal(r.hub.upgraded,0);assert.equal(fs.readdirSync(dir).length,0);assert.ok(!JSON.stringify(r.hub).includes('secret'));});
});
test('provider page size is respected; over-five-page totals are rejected without partial cache',async()=>{
 await withHub(async url=>{const page=Number(new URL(url).searchParams.get('pageNo'));return hubResponse(rows101.slice((page-1)*10,page*10).slice(0,page===2?1:10),11,page,10);},async hub=>{
 const r=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(r.hub.pageRequests,2);assert.equal(r.hub.succeeded,1);
 });
 await withHub(async()=>hubResponse(rows101.slice(0,100),501),async(hub,dir)=>{const r=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(r.hub.failureReasons.HUB_PAGE_LIMIT,1);assert.equal(r.hub.pageRequests,1);assert.equal(fs.readdirSync(dir).length,0);});
});
test('all page requests consume the shared twelve-request budget',async()=>{
 const buildings=Array.from({length:3},(_,i)=>({...building,id:String(i),tags:{shade_hub_identity:{pnu:'26230101001'+String(i+1).padStart(4,'0')+'0000',dong:'101동'}}}));
 await withHub(async url=>{const u=new URL(url),page=Number(u.searchParams.get('pageNo'));const parcel=Object.fromEntries(['sigunguCd','bjdongCd','platGbCd','bun','ji'].map(k=>[k,u.searchParams.get(k)]));return hubResponse(Array.from({length:100},(_,i)=>({...row,...parcel,dongNm:String((page-1)*100+i+1)+'동',mgmBldrgstPk:String((page-1)*100+i+1)})),500,page);},async(hub,dir)=>{
 const r=await hub.enrich({elements:buildings},routeFixture,Date.now()+30000);assert.equal(r.hub.pageRequests,12);assert.equal(r.hub.succeeded,2);assert.equal(r.hub.upgraded,2);assert.equal(r.hub.failureReasons.HUB_REQUEST_BUDGET,1);assert.equal(fs.readdirSync(dir).length,2);
 });
});
test('explicit registry key joins without dong, rejects collisions and conflicts without fuzzy fallback',()=>{
 const idBuilding={...building,tags:{shade_hub_identity:H.identity({pnu,mgmBldrgstPk:'123',dong_nm:''})}};
 const record={...row,mgmBldrgstPk:'123'};
 assert.equal(H.matchRecord(idBuilding,[idBuilding],[record]).method,'registry');
 assert.equal(H.selectRecord(idBuilding,[idBuilding,idBuilding],[record]),null);
 assert.equal(H.selectRecord(idBuilding,[idBuilding],[record,record]),null);
 const mismatch={...building,tags:{shade_hub_identity:{pnu,dong:'101동',registryId:'456'}}};assert.equal(H.matchRecord(mismatch,[mismatch],[record]).reason,'registry_mismatch');
 const conflict={...building,tags:{shade_hub_identity:{pnu,dong:'102동',registryId:'123'}}};assert.equal(H.matchRecord(conflict,[conflict],[record]).reason,'identity_conflict');
 assert.equal(H.identity({pnu,mgmBldrgstPk:9007199254740992}).registryId,undefined);
 assert.equal(H.selectRecord({...building,tags:{shade_hub_identity:{pnu,dong:'101'}}},[building],[row]),null);
});
test('empty response is distinguished from failed API; exact ID can enrich public building without dong',async()=>{
 await withHub(async()=>hubResponse([],0),async hub=>{const r=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(r.hub.failed,0);assert.equal(r.hub.emptyParcels,1);assert.equal(r.hub.matchReasons.no_records,1);});
 const b={...building,tags:{shade_hub_identity:H.identity({pnu,mgm_bldrgst_pk:'123'})}};
 await withHub(async()=>hubResponse([{...row,mgmBldrgstPk:'123'}],1),async hub=>{const r=await hub.enrich({elements:[b]},routeFixture,Date.now()+30000);assert.equal(r.hub.upgraded,1);assert.equal(r.hub.matchedBy.registry,1);assert.equal(r.hub.missingIdentity,0);});
});
test('transient failure gets a cooldown; auth failure pauses other parcels',async()=>{
 let calls=0;await withHub(async()=>{calls++;throw Error('secret');},async hub=>{await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);const retry=await hub.enrich({elements:[building]},routeFixture,Date.now()+30000);assert.equal(calls,1);assert.equal(retry.hub.deferredParcels,1);assert.equal(retry.hub.failed,0);});
 const other={...building,id:'b',tags:{shade_hub_identity:{pnu:'2623010100100020000',dong:'101동'}}};
 await withHub(async()=>({ok:false,status:403}),async hub=>{const r=await hub.enrich({elements:[building,other]},routeFixture,Date.now()+30000);assert.equal(r.hub.pageRequests,1);assert.equal(r.hub.failureReasons.HUB_AUTH,1);assert.equal(r.hub.deferredParcels,1);});
});

test('placeholder registry IDs and malformed height types cannot create a match or height',()=>{
 for(const value of ['-', 'unknown', '0','000',true,{},9007199254740992])assert.equal(H.identity({pnu,mgmBldrgstPk:value}).registryId,undefined);
 assert.equal(H.applyRecord(building,{...row,heit:true,grndFlrCnt:true}),building);
});
test('simultaneous same-parcel enrichment shares the page fetch',async()=>{
 let calls=0;await withHub(async()=>{calls++;await new Promise(r=>setTimeout(r,5));return hubResponse([row],1);},async hub=>{
 const [a,b]=await Promise.all([hub.enrich({elements:[building]},routeFixture,Date.now()+30000),hub.enrich({elements:[building]},routeFixture,Date.now()+30000)]);
 assert.equal(calls,1);assert.equal(a.hub.upgraded,1);assert.equal(b.hub.upgraded,1);assert.equal(a.hub.pageRequests+b.hub.pageRequests,1);assert.equal(a.hub.sharedQueries+b.hub.sharedQueries,1);
 });
});

test('cancelling a HUB lookup does not set a failure cooldown or block retry',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hub-cancel-'));
 const controller=new AbortController();
 let calls=0;
 const hub=H.createHub({key:'fixture',directory:dir,fetcher:async(url,{signal})=>{
  if(++calls===1)return new Promise((resolve,reject)=>{
   signal.addEventListener('abort',()=>reject(signal.reason),{once:true});
  });
  return Response.json({response:{header:{resultCode:'00'},body:{totalCount:1,items:{item:row}}}});
 }});
 const data={elements:[building]},routes=[{coords:[[35.15,129.06]]}];
 try{
  const aborted=assert.rejects(hub.enrich(data,routes,Date.now()+30000,controller.signal),{name:'AbortError'});
  controller.abort();
  await aborted;
  assert.equal(fs.readdirSync(dir).length,0);
  const retried=await hub.enrich(data,routes,Date.now()+30000,new AbortController().signal);
  assert.equal(calls,2);
  assert.equal(retried.hub.upgraded,1);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../public/app.js'),'utf8');
const nodes=new Map();
const context=vm.createContext({$:id=>{
 if(!nodes.has(id))nodes.set(id,{classList:{toggle(){}}});
 return nodes.get(id);
},exposureTime:seconds=>seconds/60+'분',formatDistance:meters=>meters+'m'});
vm.runInContext(source.slice(source.indexOf('function describeResult'),source.indexOf('let retryJob'))+source.slice(source.indexOf('function updateHighlight'),source.indexOf('let routeAnimation')),context);
const base={time:720,analysis:{knownShadeMidDistance:200}};
const alternative={time:840,analysis:{knownShadeMidDistance:500}};
function render(overrides){
 const result={routes:[base,alternative],comparison:'different',shady:1,analysisMode:'complete',savedExposureSeconds:300,...overrides};
 context.updateHighlight(result,context.describeResult(result));
 return nodes.get('highlightValue').textContent;
}
test('choice gives extra time and saved exposure for complete comparisons',()=>{
 assert.equal(render({}),'햇빛을 약 5분 덜 받아요');
 assert.equal(nodes.get('highlightLabel').textContent,'약 2분 더 걸으면');
});
test('partial or failed comparisons do not claim exposure savings',()=>{
 assert.equal(render({analysisMode:'reference'}),'계산된 그늘 약 300m 더');
 assert.equal(render({comparison:'same',shady:0,search:{verificationFailures:1}}),'빠른 길로 갈 수 있어요');
 assert.equal(render({comparison:'same',shady:0}),'이번에는 빠른 길을 추천해요');
});

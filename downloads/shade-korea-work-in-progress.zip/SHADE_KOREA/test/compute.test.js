'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const compute=require('../compute');
test('worker computation can be terminated through cancellation',async()=>{
 const controller=new AbortController();
 const pending=compute('analysis','departure',['2026-06-21','12:00'],controller.signal);
 controller.abort();
 await assert.rejects(pending,{name:'AbortError'});
 const date=await compute('analysis','departure',['2026-06-21','12:00']);
 assert.equal(date.toISOString(),'2026-06-21T03:00:00.000Z');
});

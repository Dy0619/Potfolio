"""Optional real Chromium UI smoke; external responses are explicitly mocked.
Start node server.js first; install Python Playwright and Chromium separately.
"""
from playwright.sync_api import sync_playwright
import os
base=os.environ.get('SHADE_TEST_URL','http://127.0.0.1:5500')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH','/usr/bin/chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page()
    page.route('**/api/client-config',lambda r:r.fulfill(json={'kakaoJavaScriptKey':''}))
    page.goto(base)
    page.wait_for_function("document.querySelector('#mapSetup').open")
    assert page.locator('#detour').is_visible()
    assert not page.locator('a[href="/admin"]').count()
    for width,height in [(1440,1000),(768,1024),(412,917),(360,800)]:
        page.set_viewport_size({'width':width,'height':height})
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),width
    page.goto(base+'/admin')
    assert page.url.endswith('/admin/login')
    browser.close()
print('Viewport and anonymous entry smoke: PASS')

'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const A=require('../analysis'),P=require('../precision');
const route={mode:'SHORTEST',distance:100,time:90,coords:[[35.158,129.06],[35.158,129.061]]};
function building(tags={height:'12'}){return {id:'a'.repeat(24),tags:{building:'yes',...tags},geometry:[{lat:35.1581,lon:129.06},{lat:35.1581,lon:129.0603},{lat:35.1583,lon:129.0603},{lat:35.1583,lon:129.06}]};}
const date=new Date('2026-06-21T12:00:00+09:00');
test('KST conversion and invalid calendar rejection',()=>{assert.equal(A.departure('2026-06-21','12:00').toISOString(),'2026-06-21T03:00:00.000Z');for(const [d,t] of [['2026-02-30','12:00'],['2026-01-01','24:00'],['2026-01-01','00:60'],['bad','12:00']])assert.throws(()=>A.departure(d,t));});
test('no fabricated alternatives; same densified geometry deduplicates',()=>{assert.equal(A.uniqueRoutes([route,{...route,coords:[route.coords[0],[35.158,129.0605],route.coords[1]]}]).length,1);});
test('route bbox includes full detour and shadow buffer; long path rejected',()=>{const b=A.routeBox([route]);assert.ok(b[0]<35.156&&b[2]>35.160&&b[1]<129.057&&b[3]>129.064);assert.throws(()=>A.routeBox([{coords:[[35,129],[37,127]]}]));});
for(const [name,data] of [['empty',{elements:[]}],['unknown height',{elements:[building({})]}],['unsupported courtyard',{elements:[building({height:'12',shade_geometry_unsupported:true})]}]])test(name+' suppresses ratios and recommendation',()=>{const r=A.evaluate([route],data,date);assert.equal(r.routes[0].analysis,null);assert.equal(r.shady,null);assert.equal(r.comparison,'unavailable');assert.ok(r.reason);});
test('night and very long shadows are not reported as 100% shade',()=>{assert.equal(A.evaluate([route],{elements:[building()]},new Date('2026-06-21T23:00:00+09:00')).shady,null);const long=A.evaluate([route],{elements:[building({height:'400'})]},new Date('2026-06-21T08:00:00+09:00'));assert.equal(long.analysisMode,'reference');assert.equal(long.routes[0].analysis.mid,null);});
test('valid provided heights produce bounded estimate and single route disclosure',()=>{const r=A.evaluate([route],{elements:[building()]},date);assert.equal(r.comparison,'single');assert.equal(r.shady,0);const a=r.routes[0].analysis;assert.ok(a.low>=0&&a.high<=1&&a.low<=a.mid&&a.mid<=a.high);assert.equal(r.quality.provided,1);});
test('height sources and corrected values remain distinct',()=>{assert.equal(P.heightRange({height:'15'},15).source,'measured');assert.equal(P.heightRange({'building:levels':'4'},15).source,'floors');assert.equal(P.heightRange({},15).source,'assumed');const r=A.evaluate([route],{elements:[building({})]},date,{['a'.repeat(24)]:{height:12}});assert.equal(r.quality.corrected,1);assert.equal(r.quality.assumed,0);});
test('ray geometry: sunward wall casts shadow, opposite wall does not',()=>{const b={tags:{height:'10'},xy:[[5,-5],[10,-5],[10,5],[5,5]]},sun={azimuth:90,elevation:45};const index=P.buildIndex([b],sun,15);assert.equal(P.statusAt(index,0,0,sun).mid,true);assert.equal(P.statusAt(index,20,0,sun).mid,false);assert.equal(P.statusAt(index,7,0,sun).unknown,true);});
test('solar coordinates regression from NREL SPA reference example',()=>{ // NREL SPA reference example: 2003-10-17 12:30:30 MST, 39.742476N 105.1786W. Geometric elevation ~39.87, azimuth ~194.34.
 const sun=P.sunPosition(new Date('2003-10-17T19:30:30Z'),39.742476,-105.1786);assert.ok(Math.abs(sun.elevation-39.87)<.15);assert.ok(Math.abs(sun.azimuth-194.34)<.15);});
test('route percentage weights physical distance rather than vertex count',()=>{const sun=P.sunPosition(date,35.158,129.06),origin={lat:35.158,lng:129.06}; // Real geometry comparison under differing short-segment densification.
 const index=P.buildIndex([{xy:[[5,-20],[9,-20],[9,20],[5,20]],tags:{height:'15'}}],sun,15);
 const a=P.sampleRoute(route.coords,origin,date,index,1.25);const b=P.sampleRoute([route.coords[0],[35.158,129.060001],route.coords[1]],origin,date,index,1.25);assert.ok(Math.abs(a.mid-b.mid)<.06);});

test('partial data preserves known-height shade evidence without full-route ratios',()=>{const r=A.evaluate([route],{elements:[building()],partial:true},date);assert.equal(r.analysisMode,'reference');const a=r.routes[0].analysis;for(const key of ['low','mid','high'])assert.equal(a[key],null);assert.ok(a.knownShadeMidDistance>=0&&a.knownShadeMidDistance<=route.distance);assert.ok(a.segments.some(s=>s.kind==='unknown'));assert.ok(!a.segments.some(s=>s.kind==='sun'));});
test('unknown height behind walking samples does not invent shade or invalidate sun segments',()=>{const known=building({height:'12'});known.geometry=known.geometry.map(p=>({...p,lat:p.lat+.005}));const r=A.evaluate([route],{elements:[known,building({})]},date);assert.equal(r.analysisMode,'complete');assert.equal(r.routes[0].analysis.knownShadeHighDistance,0);assert.ok(r.routes[0].analysis.segments.every(s=>s.kind==='sun'));});

test('shadow hit cannot mask later footprint overlap; independent of building order',()=>{
 const sun={elevation:45,azimuth:180};
 const caster={xy:[[-5,-15],[5,-15],[5,-10],[-5,-10]],tags:{height:'30'}};
 const containing={xy:[[-2,-2],[2,-2],[2,2],[-2,2]],tags:{height:'10'}};
 for(const bs of [[caster,containing],[containing,caster]]){const s=P.statusAt(P.buildIndex(bs,sun,15),0,0,sun);assert.equal(s.unknown,true);assert.equal(s.mid,false);assert.equal(s.reason,'building_overlap');}
});
test('overlapping shadows are a union, not summed; shadow is opposite solar direction',()=>{
 const sun={elevation:45,azimuth:180},b={xy:[[-5,-15],[5,-15],[5,-10],[-5,-10]],tags:{height:'30'}};
 const one=P.statusAt(P.buildIndex([b],sun,15),0,0,sun),two=P.statusAt(P.buildIndex([b,b],sun,15),0,0,sun);
 assert.deepEqual(one,two);assert.equal(one.mid,true);assert.equal(P.statusAt(P.buildIndex([b],sun,15),0,-25,sun).mid,false);
});
test('route inside a known footprint is excluded and reported as overlap, never shade',()=>{
 const m=P.metresPerDegree(35.158),origin={lat:35.158,lng:129.06},coords=[[origin.lat,origin.lng],[origin.lat,origin.lng+10/m.east]];
 const b={xy:[[-5,-5],[15,-5],[15,5],[-5,5]],tags:{height:'20'}};
 const sun=P.sunPosition(date,origin.lat,origin.lng),index=P.buildIndex([b],sun,15);
 const r=P.sampleRoute(coords,origin,date,index,1,700,{allowPartial:true,reference:true});
 assert.equal(r.knownShadeMid,0);assert.equal(r.buildingOverlapFraction,1);assert.equal(r.unknownFraction,1);assert.ok(r.segments.every(s=>s.kind==='unknown'));
});

test('missing height influence follows the sunward ray, without an invented height',()=>{
 const b={xy:[[-5,-15],[5,-15],[5,-10],[-5,-10]],minx:-5,maxx:5,miny:-15,maxy:-10};
 assert.equal(P.missingHeightCanShade([b],0,0,{azimuth:180}),true);
 assert.equal(P.missingHeightCanShade([b],0,-25,{azimuth:180}),false);
 assert.equal(P.missingHeightCanShade([b],20,0,{azimuth:180}),false);
 assert.equal(P.missingHeightCanShade([b],0,-25,{azimuth:0}),true);
});
test('one unknown sunward building only invalidates affected samples; lengths partition the route',()=>{
 const m=P.metresPerDegree(route.coords[0][0]),o=route.coords[0];
 const make=(id,box,tags)=>({id,tags,geometry:box.map(([x,y])=>({lat:o[0]+y/m.north,lon:o[1]+x/m.east}))});
 const unknown=make('unknown',[[30,-30],[50,-30],[50,-10],[30,-10]],{});
 const remote=make('remote',[[300,300],[310,300],[310,310],[300,310]],{height:'10'});
 const r=A.evaluate([route],{elements:[remote,unknown]},date),a=r.routes[0].analysis;
 assert.equal(r.analysisMode,'reference');assert.equal(a.mid,null);
 assert.ok(a.classifiedSunDistance>0);assert.ok(a.unclassifiedDistance>0);
 assert.ok(a.segments.some(s=>s.kind==='sun'));assert.ok(a.segments.some(s=>s.reason==='height_missing'));
 assert.equal(a.knownShadeHighDistance,0);assert.equal(a.buildingOverlapDistance,0);
 assert.ok(Math.abs(a.knownShadeLowDistance+a.uncertainDistance+a.classifiedSunDistance+a.unclassifiedDistance-route.distance)<1e-6);
 assert.ok(Math.abs(a.unknownReasonDistances.height_missing-a.unclassifiedDistance)<1e-6);
});
test('source truncation still suppresses sunlight claims even if missing buildings are behind route',()=>{
 const r=A.evaluate([route],{elements:[building()],partial:true},date),a=r.routes[0].analysis;
 assert.equal(r.analysisMode,'reference');assert.equal(a.classifiedSunDistance,0);assert.equal(a.mid,null);
 assert.ok(a.segments.filter(s=>s.kind==='unknown').every(s=>s.reason==='source_incomplete'));
});
test('known shadow evidence survives another missing sunward height, with no duplicate shade length',()=>{
 const m=P.metresPerDegree(35.158),origin={lat:35.158,lng:129.06},sun=P.sunPosition(date,origin.lat,origin.lng);
 const known={xy:[[-200,-20],[200,-20],[200,-10],[-200,-10]],tags:{height:'100'}};
 const missing={xy:[[-200,-40],[200,-40],[200,-30],[-200,-30]],minx:-200,maxx:200,miny:-40,maxy:-30};
 const coords=[[origin.lat,origin.lng],[origin.lat,origin.lng+10/m.east]],index=P.buildIndex([known],sun,15);
 const a=P.sampleRoute(coords,origin,date,index,1,700,{allowPartial:true,exclusions:[missing]});
 const b=P.sampleRoute(coords,origin,date,index,1,700,{allowPartial:true});
 assert.equal(a.knownShadeLow,b.knownShadeLow);assert.equal(a.knownShadeLow,1);assert.equal(a.unknownFraction,0);
});

test('localized failed tile leaves unaffected sun segments while suppressing full ratios',()=>{
 const m=P.metresPerDegree(route.coords[0][0]),o=route.coords[0];
 const gap=[o[0]-30/m.north,o[1]+30/m.east,o[0]-10/m.north,o[1]+50/m.east];
 const a=A.evaluate([route],{elements:[building()],partial:true,coverageGaps:[gap]},date).routes[0].analysis;
 assert.equal(a.kind,'reference');assert.equal(a.mid,null);assert.ok(a.classifiedSunDistance>0);
 assert.ok(a.unknownReasonDistances.source_incomplete>0);assert.ok(a.segments.some(s=>s.kind==='sun'));
});
test('malformed failed tile metadata falls back to conservative incomplete coverage',()=>{
 const a=A.evaluate([route],{elements:[building()],partial:true,coverageGaps:[[0,0,0,0]]},date).routes[0].analysis;
 assert.equal(a.kind,'reference');assert.equal(a.classifiedSunDistance,0);assert.ok(a.unknownReasonDistances.source_incomplete>0);
});

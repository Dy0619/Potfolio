'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const P=require('../precision'),Search=require('../walk-search'),Context=require('../route-context'),J=require('../journey');const {wallShadows}=require('../public/map-visuals');
const origin=[35.158,129.06],m=P.metresPerDegree(origin[0]),point=(x,y)=>[origin[0]+y/m.north,origin[1]+x/m.east];const direct=[point(0,0),point(100,0)],detour=[point(0,0),point(0,12),point(100,12),point(100,0)];
const way=(id,nodes,coords,tags={highway:'footway'})=>({id,nodes,geometry:coords.map(p=>({lat:p[0],lon:p[1]})),tags});
const network=[way(1,[1,2],direct),way(2,[1,3,4,2],detour)];
const building={id:'known',tags:{height:'12',building:'yes'},geometry:[point(8,3),point(92,3),point(92,8),point(8,8)].map(p=>({lat:p[0],lon:p[1]}))};
const base={mode:'SHORTEST',origin:'provider',distance:100,time:80,coords:direct};const verified={mode:'SHORTEST',origin:'shade-network',distance:124,time:100,coords:detour};const input={start:{lat:origin[0],lng:origin[1]},end:{lat:direct[1][0],lng:direct[1][1]},date:'2026-11-10',time:'12:00',detour:.3};const data={elements:[building],bbox:[35.15,129.05,35.17,129.07],partial:false};
test('road graph preserves node topology; geometric crossings with distinct ids do not connect',()=>{const graph=Search.graphFromWays([way(1,[1,2],[point(0,0),point(100,0)]),way(2,[3,4],[point(50,-50),point(50,50)])]);assert.equal(Search.solve(graph,0,3,e=>e.d,1000),null);assert.equal(Search.walkable({highway:'footway',foot:'no'}),false);assert.equal(Search.walkable({highway:'service',access:'private'}),false);assert.equal(Search.walkable({highway:'service',access:'private',foot:'yes'}),true);});
test('pedestrian one-way restrictions are honored',()=>{const graph=Search.graphFromWays([way(1,[1,2],direct,{highway:'footway','oneway:foot':'yes'})]);assert.ok(Search.solve(graph,0,1,e=>e.d,1000));assert.equal(Search.solve(graph,1,0,e=>e.d,1000),null);});
test('shade search proposes actual road nodes rather than invented offsets',()=>{const proposed=Search.propose(network,data,new Date('2026-11-10T12:00:00+09:00'),base,.3);assert.ok(proposed.plans.length>0);const nodes=network.flatMap(w=>w.geometry.map(p=>[p.lat,p.lon]));for(const plan of proposed.plans){assert.ok(plan.via.length<=5);for(const p of plan.via)assert.ok(nodes.some(n=>n[0]===p[0]&&n[1]===p[1]));}assert.ok(proposed.plans.some(p=>p.via.some(p=>p[0]>origin[0])));});
test('end-to-end: same original route -> shade graph -> provider verification -> expanded coverage -> reduced exposure',async()=>{const calls=[],phases=[];const result=await J.findJourney(input,{progress:p=>phases.push(p),walk:async(mode,via)=>{calls.push({mode,via});return via.length?verified:base;},buildings:async routes=>{assert.ok(routes.every(r=>r===base||r.origin==='shade-network'));return data;},roads:async()=>({elements:network})});assert.equal(result.routes.length,2);assert.equal(result.comparison,'different');assert.equal(result.routes[result.shady].distance,124);assert.equal(result.routes[result.shady].time,100);assert.deepEqual(result.routes[result.shady].coords,detour);assert.ok(result.savedExposureSeconds>5);assert.ok(calls.some(c=>c.via.length));assert.ok(phases.indexOf('VERIFY_ROUTES')<phases.indexOf('CHECK_COVERAGE'));assert.ok(result.routes[result.shady].analysis.segments.some(s=>s.kind==='shade'));});
test('provider rejection never turns a graph proposal into a fake displayed route',async()=>{const result=await J.findJourney(input,{walk:async(mode,via)=>{if(via.length)throw Error('provider denied');return base;},buildings:async()=>data,roads:async()=>({elements:network})});assert.equal(result.routes.length,1);assert.equal(result.comparison,'single');assert.ok(result.search.rejected>0);assert.equal(result.search.verificationFailures,result.search.rejected);assert.equal(result.search.noRoute,0);});
test('detour constraint is applied to provider distance and time, not to a graph estimate',async()=>{const result=await J.findJourney({...input,detour:.1},{walk:async(mode,via)=>via.length?verified:base,buildings:async()=>data,roads:async()=>({elements:network})});assert.equal(result.routes.length,1);assert.equal(result.shady,0);});
test('partially expanded coverage retains verified paths as references without full ratios',async()=>{const result=await J.findJourney(input,{walk:async(mode,via)=>via.length?verified:base,buildings:async routes=>routes.length>1?{...data,partial:true}:data,roads:async()=>({elements:network})});assert.equal(result.routes.length,2);assert.equal(result.analysisMode,'reference');assert.equal(result.savedExposureSeconds,null);assert.ok(result.routes.every(r=>r.analysis.mid===null&&r.analysis.exposedSeconds===null));});
test('height failure shows real route and available footprints but no invented ratio or shade recommendation',async()=>{let searched=false;const result=await J.findJourney(input,{walk:async()=>base,buildings:async()=>({...data,elements:[{...building,tags:{building:'yes'}}]}),roads:async()=>{searched=true;throw Error();}});assert.equal(result.shady,null);assert.equal(result.routes[0].analysis,null);assert.equal(result.visuals.buildings[0].height,null);assert.equal(searched,false);});
test('ranking minimizes expected sun exposure time; higher shade percentage alone cannot win',()=>{const r=(distance,time,mid)=>({distance,time,analysis:{low:mid,mid,high:mid}});const result=J.rank({comparison:'different',routes:[r(100,100,.5),r(140,140,.6),r(120,120,.7)],shady:1},.5);assert.equal(result.shady,2);assert.ok(Math.abs(result.savedExposureSeconds-14)<1e-8);});
test('corridor tiling covers an 8 km route without filling its whole enclosing rectangle',()=>{const coords=[point(0,0),point(8000,0)],tiles=Context.routeTiles([{coords}]);assert.ok(tiles.boxes.length<=48);for(let x=0;x<=8000;x+=100)for(const dy of [-325,0,325]){const p=point(x,dy);assert.ok(tiles.boxes.some(b=>p[0]>=b[0]&&p[0]<=b[2]&&p[1]>=b[1]&&p[1]<=b[3]));}assert.throws(()=>Context.routeTiles([{coords:[point(0,0),point(60000,0)]}]));});
test('courtyard ray cast accounts for inner walls and does not classify empty courtyard as inside building',()=>{const sun={elevation:45,azimuth:90};const index=P.buildIndex([{xy:[[0,0],[30,0],[30,30],[0,30]],holes:[[[5,5],[25,5],[25,25],[5,25]]],tags:{height:'20'}}],sun,15);assert.equal(P.statusAt(index,10,10,sun).unknown,false);assert.equal(P.statusAt(index,10,10,sun).mid,true);assert.equal(P.statusAt(index,2,10,sun).unknown,true);});
test('wall shadow preview points away from sun; missing heights and night generate no fake polygons',()=>{const ring=[point(0,0),point(10,0),point(10,10),point(0,10)];const shadows=wallShadows([ring],10,{elevation:45,azimuth:180});assert.equal(shadows.length,4);assert.ok(shadows[0][2][0]>shadows[0][1][0]);assert.equal(wallShadows([ring],null,{elevation:45,azimuth:180}).length,0);assert.equal(wallShadows([ring],10,{elevation:-5,azimuth:180}).length,0);});

test('when road source is unavailable, shadow target probes still require provider confirmation',async()=>{
 const result=await J.findJourney(input,{walk:async(mode,via)=>via.length?verified:base,buildings:async()=>data,roads:async()=>{throw Error('source offline');}});assert.equal(result.search.method,'shadow-probes');assert.ok(result.search.proposed>0);assert.equal(result.comparison,'different');assert.deepEqual(result.routes[result.shady].coords,detour);
 const denied=await J.findJourney(input,{walk:async(mode,via)=>{if(via.length)throw Error('unwalkable');return base;},buildings:async()=>data,roads:async()=>{throw Error('offline');}});assert.equal(denied.routes.length,1);
});

test('incomplete source plus missing heights retains real detour verification',async()=>{
 const missing=Array.from({length:9},(_,i)=>({...building,id:'missing'+i,tags:{building:'yes'},geometry:building.geometry.map(p=>({...p,lat:p.lat+.003+i*.0001}))}));
 const mixed={...data,partial:true,elements:[building,...missing]};let checked=0,queried=0;
 const result=await J.findJourney(input,{walk:async(mode,via)=>{if(via.length)checked++;return via.length?verified:base;},buildings:async()=>mixed,roads:async()=>{queried++;return {elements:network};}});
 assert.ok(checked&&queried);assert.equal(result.quality.missing,9);assert.equal(result.quality.usable,1);assert.equal(result.analysisMode,'reference');assert.equal(result.comparison,'same');assert.equal(result.shady,0);assert.equal(result.coverageMismatch,true);assert.equal(result.savedExposureSeconds,null);assert.deepEqual(result.routes[1].coords,detour);
 for(const r of result.routes){assert.equal(r.analysis.mid,null);assert.equal(r.analysis.exposedSeconds,null);assert.ok(!r.analysis.segments.some(s=>s.kind==='sun'));assert.ok(r.analysis.knownShadeHighDistance<=r.distance);}
 assert.ok(result.visuals.buildings.some(b=>b.height===null));assert.ok(result.visuals.truncated);assert.equal(result.quality.missing,9);
});
test('reference ranking pays for extra walking time rather than maximizing known shade length alone',()=>{const r=(distance,time,shade)=>({distance,time,analysis:{kind:'reference',low:null,mid:null,high:null,knownShadeLowSeconds:shade}});const result=J.rank({analysisMode:'reference',comparison:'different',routes:[r(100,100,30),r(150,150,60),r(120,120,65)]},.5);assert.equal(result.shady,2);assert.equal(result.savedExposureSeconds,null);assert.equal(result.referenceScoreImprovement,15);});

test('time comparison preserves verified geometry, handles KST rollover and suppresses night metrics',()=>{
 const date=new Date('2026-11-10T00:10:00+09:00');
 const current=require('../analysis').evaluate([base],data,date);
 const times=J.timeComparison([base],data,date,{},current);
 assert.deepEqual(times.map(x=>[x.date,x.time]),[['2026-11-09','23:40'],['2026-11-10','00:10'],['2026-11-10','00:40']]);
 assert.ok(times.every(t=>t.routes[0].analysis===null));assert.deepEqual(base.coords,direct);
});
test('time comparison agrees with independent walking-time evaluation and preserves partial status',()=>{
 const A=require('../analysis'),date=new Date('2026-11-10T12:00:00+09:00'),partial={...data,partial:true};
 const times=J.timeComparison([base,verified],partial,date,{},A.evaluate([base,verified],partial,date));
 for(const t of times){const expected=A.evaluate([base,verified],partial,new Date(+date+t.offset*60000));assert.deepEqual(t.routes.map(r=>r.analysis),expected.routes.map(r=>r.analysis));assert.ok(t.routes.every(r=>!r.analysis||r.analysis.mid===null));}
});
test('visual display budget reaches destination despite dense buildings near departure',()=>{
 const buildings=Array.from({length:700},(_,i)=>({...building,id:'near'+i,geometry:building.geometry.map(p=>({...p,lat:p.lat+i*.0000001}))}));
 const far={...building,id:'far',geometry:building.geometry.map(p=>({...p,lon:p.lon+3000/m.east}))};
 const route={...base,coords:[point(0,0),point(3000,0)]};
 const v=J.visualContext({elements:[...buildings,far]},new Date('2026-11-10T12:00:00+09:00'),route);
 assert.ok(v.buildings.length<=600);assert.ok(v.truncated);assert.ok(v.buildings.some(b=>b.rings[0][0][1]===far.geometry[0].lon));
});

test('no-route responses and over-limit routes are not counted as lookup failures',async()=>{
 const result=await J.findJourney(input,{
  walk:async(mode,via)=>{
   if(mode==='ACCESSIBLE'||via.length)throw Object.assign(Error('no route'),{status:422});
   return base;
  },
  buildings:async()=>data,roads:async()=>({elements:network})
 });
 assert.equal(result.candidateFailures,0);
 assert.ok(result.search.noRoute>0);
 assert.equal(result.search.verificationFailures,0);
 const overLimit=await J.findJourney(input,{
  walk:async(mode,via)=>via.length?{...verified,distance:200}:base,
  buildings:async()=>data,roads:async()=>({elements:network})
 });
 assert.ok(overLimit.search.overLimit>0);
 assert.equal(overLimit.search.verificationFailures,0);
});

test('now departure compares only present and future times',()=>{
 const date=new Date('2026-06-21T12:00:00+09:00');
 const A=require('../analysis');
 const current=A.evaluate([base],data,date);
 const times=J.timeComparison([base],data,date,{},current,'now');
 assert.deepEqual(times.map(item=>item.offset),[0,30,60]);
 assert.deepEqual(times.map(item=>item.time),['12:00','12:30','13:00']);
});

test('additional minutes permit eight minutes when shortest is three minutes',()=>{
 const base={distance:200,time:180,analysis:{mid:0,low:0,high:0,knownShadeLowSeconds:0}};
 const candidate={distance:700,time:480,analysis:{mid:.9,low:.9,high:.9,knownShadeLowSeconds:432}};
 assert.equal(J.rank({routes:[base,candidate],analysisMode:'complete'},.3,5).shady,1);
 assert.equal(J.rank({routes:[base,{...candidate,time:481}],analysisMode:'complete'},.3,5).shady,0);
});

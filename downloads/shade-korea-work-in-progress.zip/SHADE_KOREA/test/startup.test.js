'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const {fork}=require('node:child_process');const path=require('node:path');
test('integrated server sends its build only after binding and serves a consistent complete asset set',async()=>{
 const child=fork(path.resolve(__dirname,'../server.js'),[],{env:{...process.env,PORT:'0'},execArgv:[],stdio:['ignore','ignore','ignore','ipc']});
 try{
 const ready=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('startup timeout')),10000);child.once('error',e=>{clearTimeout(timer);reject(e);});child.once('exit',()=>{clearTimeout(timer);reject(Error('server stopped'));});child.on('message',m=>{if(m.type==='shade-ready'){clearTimeout(timer);resolve(m);}});});
 assert.equal(ready.version,'5.17.0');assert.equal(ready.build,'SK517-20261116-DESIGN');
 const health=await(await fetch(ready.url+'/api/health')).json();assert.equal(health.version,ready.version);assert.equal(health.build,ready.build);
 const html=await(await fetch(ready.url)).text();assert.ok(html.includes('5.17'));assert.ok(html.includes('/map-loader.js?v=5.17.0'));
 for(const asset of ['/app.js?v=5.17.0','/map-loader.js?v=5.17.0','/style.css?v=5.17.0','/login.js']){const r=await fetch(ready.url+asset);assert.equal(r.status,200,asset);await r.text();}
 const r=await fetch(ready.url);const csp=r.headers.get('content-security-policy');for(const name of ['script-src','style-src','img-src','connect-src']){const value=csp.split(';').find(x=>x.trim().startsWith(name+' '));assert.ok(value.includes('http://*.kakaocdn.net'));assert.ok(value.includes('https://*.kakaocdn.net'));}
 assert.equal((await fetch(ready.url+'/api/admin/status')).status,401);
 }finally{child.kill();}
});

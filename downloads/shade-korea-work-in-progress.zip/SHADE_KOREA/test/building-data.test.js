'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const {buildingHeight,enrichExact,schemaSummary}=require('../building-data');const A=require('../analysis');
process.env.VWORLD_API_KEY='test-height-fixture-only';
const {queryBuildingTile}=require('../server');
const geometry={type:'Polygon',coordinates:[[[129.06,35.1581],[129.0603,35.1581],[129.0603,35.1583],[129.06,35.1583],[129.06,35.1581]]]};
function feature(properties){return {type:'Feature',properties,geometry};}
test('height and ground floor aliases normalize case/camel/snake without using basement floors',()=>{for(const field of ['GRND_FLR','grnd_flr','GRO_FLO_CO','groFloCo','GRND_FLR_CNT']){const h=buildingHeight({[field]:4,UND_FLO_CO:8});assert.equal(h.levels,'4',field);assert.equal(h.quality,'floor-estimate');}assert.equal(buildingHeight({BULD_HG:'12.5 m'}).height,'12.5');assert.equal(buildingHeight({HEIGHT:'0',GRND_FLR:4}).levels,'4');assert.equal(buildingHeight({UND_FLO_CO:5,ARCHAREA:1000,altitude:100}).quality,'unknown');});
test('malformed numeric fields do not become artificial heights',()=>{for(const value of ['12평','12??',-3,0,true,{},'unknown'])assert.equal(buildingHeight({HEIGHT:value}).quality,'unknown');assert.equal(buildingHeight({GRND_FLR:'3.5'}).quality,'unknown');assert.equal(buildingHeight({HEIGHT:'1,200'}).quality,'unknown');});
test('height merge accepts only exact footprint ids and never replaces better primary data',()=>{const b=(id,tags)=>({id,tags});const primary=[b('one',{}),b('two',{height:'22'})];const r=enrichExact(primary,[b('nearby',{height:'100'}),b('one',{'building:levels':'5'}),b('two',{'building:levels':'9'})]);assert.equal(r.upgraded,1);assert.equal(r.elements[0].tags['building:levels'],'5');assert.equal(r.elements[1].tags.height,'22');assert.equal(r.elements.length,2);const no=enrichExact([b('one',{})],[b('another',{height:'100'})]);assert.equal(no.upgraded,0);assert.ok(!no.elements[0].tags.height);});
test('diagnostics report field names and counts, not raw property values',()=>{const s=schemaSummary([feature({GRND_FLR:4,name:'private-building-name'})]);assert.equal(s.floors,1);assert.ok(s.fields.includes('GRND_FLR'));assert.ok(!JSON.stringify(s).includes('private-building-name'));});
test('successful geometry with missing height triggers secondary query, upgrades exact match and enables estimate',async()=>{const original=global.fetch,calls=[];try{global.fetch=async url=>{const u=new URL(url);calls.push(u.pathname);return Response.json({type:'FeatureCollection',features:[feature(u.pathname==='/req/data'?{NAME:'fixture'}:{GRND_FLR:4})]});};const tile=await queryBuildingTile([35.158,129.059,35.159,129.062]);assert.ok(calls.length>=2&&calls.length<=3);assert.ok(calls[1].includes('getBldgisSpceWFS'));assert.equal(tile.supplemented,1);assert.equal(tile.elements[0].tags['building:levels'],'4');assert.equal(tile.elements[0].tags.shade_height_field,'GRND_FLR');assert.equal(tile.heightDiagnostics.length,calls.length);const route={distance:100,time:90,coords:[[35.158,129.06],[35.158,129.061]]};const result=A.evaluate([route],{...tile,partial:false},new Date('2026-11-10T12:00:00+09:00'));assert.equal(result.comparison,'single');assert.equal(result.quality.floorEstimated,1);assert.equal(result.quality.supplemented,1);}finally{global.fetch=original;}});
test('secondary failure retains primary geometry without inventing height',async()=>{const original=global.fetch;try{global.fetch=async url=>{const u=new URL(url);if(u.pathname!=='/req/data')throw Error('fixture failure');return Response.json({type:'FeatureCollection',features:[feature({NAME:'fixture'})]});};const tile=await queryBuildingTile([35.1579,129.059,35.159,129.062]);assert.equal(tile.elements.length,1);assert.ok(!tile.elements[0].tags.height);assert.equal(tile.heightDiagnostics[1].ok,false);const result=A.evaluate([{distance:100,time:90,coords:[[35.158,129.06],[35.158,129.061]]}],{...tile,partial:false},new Date('2026-11-10T12:00:00+09:00'));assert.equal(result.reasonCode,'HEIGHT_LOOKUP_FAILED');assert.equal(result.shady,null);}finally{global.fetch=original;}});

test('management id supplementation requires one-to-one identity, not a parcel or nearest building',()=>{
 const b=(id,management,tags={})=>({id,tags:{...tags,shade_join_id:management}});
 const merged=enrichExact([b('original','1234567890123456789012345')],[b('updated-footprint','1234567890123456789012345',{'building:levels':'7'})]);assert.equal(merged.upgraded,1);assert.equal(merged.elements[0].id,'original');assert.equal(merged.elements[0].tags.shade_height_join,'management-id');
 const ambiguous=enrichExact([b('original','same')],[b('other1','same',{height:'99'}),b('other2','same',{height:'20'})]);assert.equal(ambiguous.upgraded,0);
});
test('road-address floors remain available when supplementary sources lack heights',async()=>{const original=global.fetch,calls=[];try{global.fetch=async url=>{const u=new URL(url);calls.push(u.searchParams.get('data')||'WFS');return Response.json({type:'FeatureCollection',features:[feature(u.searchParams.get('data')==='LT_C_SPBD'?{GRO_FLO_CO:6}:{NAME:'fixture'})]});};const tile=await queryBuildingTile([35.1578,129.059,35.159,129.062]);assert.equal(calls.length,3);assert.equal(calls[0],'LT_C_SPBD');assert.equal(tile.elements[0].tags['building:levels'],'6');}finally{global.fetch=original;}});

test('provided GIS height upgrades road-address floor estimate on the same footprint',async()=>{const original=global.fetch,calls=[];try{global.fetch=async url=>{const u=new URL(url);calls.push(u.pathname);return Response.json({type:'FeatureCollection',features:[feature(u.pathname==='/req/data'?{GRO_FLO_CO:4}:{HEIGHT:20})]});};const tile=await queryBuildingTile([35.1577,129.059,35.159,129.062]);assert.equal(tile.elements[0].tags.height,'20.0');assert.equal(tile.elements[0].tags.shade_height_source,'measured');assert.equal(calls.length,2);}finally{global.fetch=original;}});

test('reported production schema: GIS parcel identity survives different road footprints and reaches HUB',async()=>{
 const original=global.fetch;
 const pnu='2623010100100010000';
 try {
  global.fetch=async url=>{
   const u=new URL(url);
   if(u.pathname.includes('getBldgisSpceWFS'))return Response.json({features:[{...feature({pnu,dong_nm:'101동',ground_floor_co:4}),geometry:{type:'Polygon',coordinates:[geometry.coordinates[0].map(([x,y])=>[x+.00001,y])]}}]});
   return Response.json({features:[feature({gro_flo_co:3,bd_mgt_sn:'1234567890123456789012345'})]});
  };
  const tile=await queryBuildingTile([35.1576,129.059,35.159,129.062]);
  assert.equal(tile.source,'GIS건물통합 WFS');
  assert.equal(tile.elements.length,1);
  assert.equal(tile.elements[0].tags.shade_hub_identity.pnu,pnu);
  assert.equal(tile.elements[0].tags['building:levels'],'4');
  const H=require('../building-hub');
  const hub=H.createHub({key:'fixture',directory:require('node:os').tmpdir()+'/shade55-'+Date.now(),fetcher:async()=>Response.json({response:{header:{resultCode:'00'},body:{totalCount:1,items:{item:{...H.parcelParams(pnu),dongNm:'101동',heit:24}}}}})});
  const enriched=await hub.enrich(tile,[{coords:[[35.158,129.06]]}],Date.now()+30000);
  assert.equal(enriched.hub.queried,1);
  assert.equal(enriched.hub.upgraded,1);
  assert.equal(enriched.elements[0].tags.height,'24');
 }finally{global.fetch=original;}
});

test('failed tile location survives alongside successful data for segment uncertainty',async()=>{
 const original=global.fetch;const good=[35.15,129.05,35.16,129.07],bad=[35.15,129.08,35.16,129.09];
 try{global.fetch=async url=>{if(String(url).includes('129.08'))throw Error('fixture unavailable');return Response.json({type:'FeatureCollection',features:[feature({height:12})]});};
 const data=await require('../server').upstreamBuildings([35.15,129.05,35.16,129.09],[good,bad]);
 assert.equal(data.partial,true);assert.ok(data.elements.length);assert.ok(data.coverageGaps.some(b=>JSON.stringify(b)===JSON.stringify(bad)));assert.ok(!data.coverageGaps.some(b=>JSON.stringify(b)===JSON.stringify(good)));
 }finally{global.fetch=original;}
});
test('deadline preserves all unrequested tile boxes rather than silently dropping coverage',async()=>{
 const original=global.fetch,boxes=[[35.1,129.1,35.15,129.11],[35.15,129.1,35.15,129.11]];let calls=0;
 try{global.fetch=async()=>{calls++;throw Error('must not fetch');};const data=await require('../server').upstreamBuildings([35.1,129.1,35.15,129.11],boxes,Date.now()-1);assert.equal(calls,0);assert.equal(data.partial,true);assert.deepEqual(data.coverageGaps,boxes);}
 finally{global.fetch=original;}
});

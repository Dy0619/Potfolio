/* Optional semantic UI integration test. Requires jsdom as a test-only dependency.
   Map SDK + external service responses are explicitly simulated; this is NOT a real map/browser layout test. */
'use strict';
const assert=require('node:assert/strict'),path=require('node:path');const {JSDOM,requestInterceptor,VirtualConsole}=require(process.env.JSDOM_PATH||'jsdom');const J=require('../journey'),P=require('../precision');
const {server}=require('../server');
const origin=[35.158,129.06],m=P.metresPerDegree(origin[0]),point=(x,y)=>[origin[0]+y/m.north,origin[1]+x/m.east],direct=[point(0,0),point(100,0)],detour=[point(0,0),point(0,10),point(100,10),point(100,0)];
const way=(id,nodes,coords)=>({id,nodes,tags:{highway:'footway'},geometry:coords.map(p=>({lat:p[0],lon:p[1]}))});
const data={elements:[{id:'fixture',tags:{height:'12'},geometry:[point(8,3),point(92,3),point(92,9),point(8,9)].map(p=>({lat:p[0],lon:p[1]}))}],partial:false,bbox:[35.15,129.05,35.17,129.07]};
const input={start:{lat:origin[0],lng:origin[1]},end:{lat:direct[1][0],lng:direct[1][1]},date:'2025-06-21',time:'12:00',detour:.3};
const mockSdk=`(()=>{window.__mapObjects=[];class LatLng{constructor(lat,lng){this.lat=lat;this.lng=lng;}getLat(){return this.lat}getLng(){return this.lng}}class Map{constructor(el,o){this.center=o.center;this.level=o.level}getCenter(){return this.center}setCenter(c){this.center=c}panTo(c){this.center=c}setBounds(){}getLevel(){return this.level}setLevel(l){this.level=l}relayout(){}}class Shape{constructor(o){this.options=o;this.map=o.map;window.__mapObjects.push(this)}setMap(m){this.map=m}setOptions(o){Object.assign(this.options,o)}}window.kakao={maps:{load(cb){cb()},Map,LatLng,LatLngBounds:class{extend(){}},Polyline:Shape,Polygon:Shape,CustomOverlay:Shape,event:{addListener(){}}}}})();`;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));async function until(fn){for(let i=0;i<100;i++){if(fn())return;await sleep(50);}throw Error('UI condition timed out');}
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
 let result=await J.findJourney(input,{walk:async(mode,via)=>via.length?{mode,distance:120,time:96,coords:detour}:{mode,distance:100,time:80,coords:direct},buildings:async()=>data,roads:async()=>({elements:[way(1,[1,2],direct),way(2,[1,3,4,2],detour)]})});
 const errors=[],checks=[];let pending=false,submissionDelay=0,transientPoll=false,jobGets=0,deleted=0,nasaReads=0,powerReads=0;const vc=new VirtualConsole();vc.on('jsdomError',e=>{if(!/Could not parse CSS|Not implemented: navigation/.test(e.message))errors.push(e.message);});
 const dom=await JSDOM.fromURL(base,{resources:{interceptors:[requestInterceptor(request=>{if(request.url.startsWith('https://dapi.kakao.com/'))return new Response(mockSdk,{headers:{'Content-Type':'application/javascript'}});})]},runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){
  w.matchMedia=query=>({matches:query==='(max-width: 650px)'});w.AbortController=global.AbortController;w.AbortSignal=global.AbortSignal;w.HTMLElement.prototype.scrollIntoView=function(){};w.ResizeObserver=class{observe(){}};
  w.fetch=async(url,opts={})=>{const u=new URL(url,base);if(opts.signal?.aborted)throw new DOMException('cancelled','AbortError');
   if(u.pathname==='/api/client-config')return Response.json({kakaoJavaScriptKey:'a'.repeat(32)});
   if(u.pathname==='/api/places'){const start=u.searchParams.get('q').includes('출발');return Response.json({places:[{name:start?'테스트 출발':'테스트 도착',address:'테스트 전용 주소',lat:start?origin[0]:direct[1][0],lng:start?origin[1]:direct[1][1]}]});}
   if(u.pathname==='/api/journeys'){if(submissionDelay)await sleep(submissionDelay);jobGets=0;return Response.json({id:'a'.repeat(48)},{status:202});}
   if(u.pathname.startsWith('/api/journeys/')){if(opts.method==='DELETE'){deleted++;return Response.json({ok:true});}jobGets++;if(transientPoll){transientPoll=false;return Response.json({error:'temporary'},{status:503});}return Response.json(pending||jobGets===1?{status:'running',phase:'VERIFY_ROUTES',message:'실제 우회 경로 확인 중'}:{status:'done',result});}
   if(u.pathname==='/api/solar-check'){nasaReads++;return Response.json({status:'matched',deltaElevation:.01,deltaAzimuth:.02});}
   if(u.pathname==='/api/solar-power'){powerReads++;return Response.json({source:'NASA POWER',unit:'Wh/m^2',hours:[{utc:'2025062103',value:450}]});}
   throw Error('Unexpected UI request '+u.pathname);
  };
 }});
 try{
  const w=dom.window,d=w.document,$=id=>d.getElementById(id);await until(()=>$('mapFallback').hidden);checks.push('SDK lifecycle reaches map creation with explicit simulated SDK');
  for(const [key,text] of [['start','출발'],['end','도착']]){$(key).focus();$(key).value=text;$(key).dispatchEvent(new w.Event('input',{bubbles:true}));await until(()=>$(key+'List').children.length>0);$(key).dispatchEvent(new w.KeyboardEvent('keydown',{key:'ArrowDown',bubbles:true}));$(key).dispatchEvent(new w.KeyboardEvent('keydown',{key:'Enter',bubbles:true}));assert.ok($(key).value.includes('테스트'));}checks.push('Both endpoints selected using real autocomplete input and keyboard handlers');
  assert.equal($('departureFields').hidden,true);$('departLater').click();assert.equal($('departureFields').hidden,false);$('date').value=input.date;$('time').value=input.time;$('routeForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));await until(()=>$('status').textContent.includes('실제 우회 경로 확인 중'));assert.equal($('detour').disabled,true);assert.equal($('analysisProgress').querySelector('[aria-current]').dataset.phase,'compare');checks.push('Anonymous analysis displays server phase and locks departure conditions');
  await until(()=>!$('results').hidden&&$('analyse').disabled===false);assert.equal(d.querySelectorAll('.route-card').length,2);assert.ok($('resultNote').textContent.includes('줄어드는'));assert.ok($('routeCards').textContent.includes('120 m'));assert.equal(d.activeElement,$('results'));$('showRouteMap').click();assert.equal(d.activeElement,$('mapStage'));$('showRouteResults').click();assert.equal(d.activeElement,$('results'));checks.push('Verified alternate route and real fixture metrics render after job completion');
  assert.ok(w.__mapObjects.some(o=>o.options.path?.length));assert.ok(!w.__mapObjects.some(o=>o.options.fillColor==='#2a5572'&&o.map));$('toggleShadows').click();const prior=w.__mapObjects.filter(o=>o.options.fillColor==='#2a5572'&&o.map).length;$('toggleShadows').click();assert.equal(w.__mapObjects.filter(o=>o.options.fillColor==='#2a5572'&&o.map).length,0);$('toggleShadows').click();assert.equal(w.__mapObjects.filter(o=>o.options.fillColor==='#2a5572'&&o.map).length,prior);checks.push('Building/shadow polygons and layer toggle use the map API');
  assert.equal(powerReads,0);$('powerCondition').closest('details').open=true;
  await until(()=>$('nasaCondition').textContent.includes('0.010')&&$('powerCondition').textContent.includes('450'));assert.ok(nasaReads&&powerReads);assert.equal($('conditions').hidden,false);checks.push('NASA comparison and historical POWER references load without login');
  $('time').value='13:00';$('time').dispatchEvent(new w.Event('change'));assert.equal($('results').hidden,true);assert.equal($('conditions').hidden,true);checks.push('Changing departure time invalidates route, shade overlays and solar references');
  const partialData={...data,partial:true,elements:[...data.elements,...Array.from({length:9},(_,i)=>({...data.elements[0],id:'unknown'+i,tags:{building:'yes'},geometry:data.elements[0].geometry.map(p=>({...p,lat:p.lat+.003+i*.0001}))}))]};
  result=await J.findJourney(input,{walk:async(mode,via)=>via.length?{mode,distance:120,time:96,coords:detour}:{mode,distance:100,time:80,coords:direct},buildings:async()=>partialData,roads:async()=>({elements:[way(1,[1,2],direct),way(2,[1,3,4,2],detour)]})});
  assert.equal(result.analysisMode,'reference');
  // Exercise the reference-card UI independently of the coverage threshold.
  result={...result,comparison:'different',shady:1,coverageMismatch:false};$('time').value=input.time;$('routeForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));await until(()=>!$('results').hidden&&$('analyse').disabled===false);
  assert.ok($('routeCards').textContent.includes('그늘 우선 참고 경로'));assert.ok($('routeCards').textContent.includes('부분 자료로 비교'));assert.ok($('routeCards').textContent.includes('120 m'));assert.ok(!$('routeCards').textContent.includes('%'));assert.ok(!$('routeCards').textContent.includes('예상 햇빛 노출'));assert.ok($('quality').textContent.includes('미확인 9개'));checks.push('90% missing-height case renders verified reference detour with real metrics and no invented percentage or exposure');
  assert.ok(w.__mapObjects.some(o=>o.options.strokeColor==='#20a774'&&o.map));assert.equal($('routeHighlight').hidden,false);assert.ok($('highlightValue').textContent.includes('더'));assert.ok($('highlightDetail').textContent.includes('확인하기 어려워요'));assert.equal($('sunGraphic').hidden,false);d.querySelector('.route-shortest').click();assert.equal(d.querySelector('.route-shortest').getAttribute('aria-pressed'),'true');d.querySelector('.route-shade').click();assert.equal(d.querySelector('.route-shade').getAttribute('aria-pressed'),'true');assert.equal($('segmentSummary').hidden,false);assert.ok($('segmentValues').children.length<4);assert.equal($('segmentSummary').open,false);assert.ok($('segmentReasons').textContent.includes('조회 범위 누락'));checks.push('Segment summary shows four categories and missing-data reasons without fabricating percentages');
  assert.equal($('timeExplorer').hidden,false);const later=d.querySelector('[data-preview="2"]');assert.ok(later.textContent.includes('12:30'));later.click();assert.equal(later.getAttribute('aria-pressed'),'true');assert.ok($('previewLabel').textContent.includes('12:30'));assert.ok($('previewMetric').textContent.includes('확보한 자료'));assert.ok($('mapCaption').textContent.includes('미리보기'));assert.ok(!$('previewMetric').textContent.includes('%'));assert.ok($('previewChange').textContent.includes('검색 시각')||$('previewChange').textContent.includes('변화가 작아요'));assert.ok($('routeAudit').textContent.includes('겹쳐 제외'));checks.push('Time buttons compare with original departure and exposes excluded overlap diagnostics');
  result={...result,shady:0,comparison:'same'};$('routeForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));await until(()=>!$('results').hidden&&$('analyse').disabled===false);assert.equal(d.querySelectorAll('.route-card').length,1);assert.ok($('resultNote').textContent.includes('판단하기 어려워요'));assert.equal($('resultHeading').textContent,'경로 선택');assert.ok(!$('routeCards').textContent.match(/(\d+ m)–\1/));checks.push('Same-route result renders one card, guidance headline and no identical range');
  const referenceResult=result;
  const evaluated=referenceResult.routes.map(route=>({...route,analysis:{...route.analysis,kind:'complete',low:.2,mid:.2,high:.2}}));
  const complete={...referenceResult,analysisMode:'complete',routes:evaluated,search:{status:'ok'}};
  for(const [scenario,heading,retry] of [
   [{...complete,routes:evaluated.slice(0,1),comparison:'single'},'비교할 다른 길을 찾지 못했어요',false],
   [complete,'햇빛 노출을 충분히 줄이는 우회로가 없었어요',false],
   [{...complete,search:{status:'shadow_points_proposed',networkStatus:'network_unavailable'}},'최단 경로를 찾았어요',true],
   [{...complete,search:{status:'network_limit'}},'우회 경로 탐색 범위가 제한됐어요',false],
   [{...complete,routes:[{...evaluated[0],analysis:null,analysisReason:'SUN_TOO_LOW'}],shady:null,comparison:'unavailable'},'이 시간에는 그늘 비교가 어려워요',false]
  ]){
   result=scenario;
   $('routeForm').requestSubmit();
   await until(()=>!$('results').hidden&&!$('analyse').disabled);
   assert.equal($('resultHeading').textContent,'경로 선택');
   assert.equal($('retryJourney').hidden,!retry);
   assert.equal(d.querySelectorAll('.route-card').length,1);
   if(retry){
    $('retryJourney').click();
    await until(()=>!$('results').hidden&&!$('analyse').disabled);
    assert.equal($('resultHeading').textContent,'경로 선택');
   }
   checks.push('Outcome and retry UI: '+heading);
  }
  $('departNow').click();assert.equal($('departNow').getAttribute('aria-pressed'),'true');assert.equal($('results').hidden,true);checks.push('Depart-now mode clears stale results');
  pending=true;$('routeForm').dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));await until(()=>!$('analysisProgress').hidden&&jobGets>0);$('cancelAnalyse').click();await until(()=>$('analyse').disabled===false);assert.ok(deleted);assert.ok($('status').textContent.includes('취소'));checks.push('Cancellation revokes job and unlocks inputs for retry');
  const beforeEarly=deleted;
  submissionDelay=250;
  $('routeForm').requestSubmit();
  $('cancelAnalyse').click();
  await until(()=>deleted>beforeEarly&&!$('analyse').disabled);
  assert.equal($('results').hidden,true);
  checks.push('Cancelling before a job ID arrives still deletes the submitted job');
  pending=false;submissionDelay=0;transientPoll=true;
  $('routeForm').requestSubmit();
  await until(()=>$('status').textContent.includes('다시 연결'));
  await until(()=>!$('results').hidden&&!$('analyse').disabled);
  assert.equal($('analysisProgress').hidden,true);
  checks.push('Temporary poll failure reconnects to the same job and displays results');
  assert.deepEqual(errors,[]);checks.push('No uncaught app JavaScript errors in DOM integration');console.log(JSON.stringify({passed:checks.length,checks,scope:'jsdom; SDK and external responses explicitly simulated; no browser layout claim'},null,2));
 }finally{dom.window.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});

'use strict';
const {test,before,after}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),crypto=require('node:crypto');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'shade-test-'));process.env.SHADE_DATA_DIR=temp;process.env.ADMIN_USERNAME='test-admin';const salt='test-only-salt';process.env.ADMIN_PASSWORD_HASH='scrypt:'+salt+':'+crypto.scryptSync('test-password-only',salt,64).toString('hex');process.env.APP_ORIGIN='http://127.0.0.1:5500';process.env.KAKAO_REST_API_KEY='test-only';process.env.VWORLD_API_KEY='test-only';
const realFetch=global.fetch;let failRoute=false,partial=false,same=true,holdWalk=false,walkStarted=0,walkAborted=0;
const coords=[[129.06,35.158],[129.061,35.158]];
global.fetch=async(url,opts)=>{const u=new URL(url);if(u.hostname==='127.0.0.1')return realFetch(url,opts);
 if(u.hostname==='dapi.kakao.com'){if(u.pathname.includes('/local/'))return Response.json({documents:[{place_name:'부산 테스트 장소',address_name:'테스트 주소',x:'129.06',y:'35.158'}]});if(holdWalk){
  walkStarted++;
  return new Promise((resolve,reject)=>{
   opts.signal.addEventListener('abort',()=>{walkAborted++;reject(opts.signal.reason);},{once:true});
  });
 }if(failRoute)return Response.json({}, {status:401});const mode=u.searchParams.get('route_mode');return Response.json({status:'OK',route:{properties:{totalDistance:100,totalTime:90},legs:[{steps:[{path:{points:partial?[[129.07,35.17],[129.071,35.17]]:same||mode==='SHORTEST'?coords:[[129.06,35.158],[129.0605,35.1575],[129.061,35.158]]}}]}]}});}
 if(u.hostname==='api.vworld.kr'){if(partial)return Response.json({response:{status:'ERROR',error:{text:'test failure'}}});const bb=(u.searchParams.get('geomFilter')?.match(/BOX\((.*)\)/)?.[1]||'').split(',').map(Number);if(bb.length===4&&(bb[2]<129.06||bb[0]>129.0603||bb[3]<35.1581||bb[1]>35.1583))return Response.json({type:'FeatureCollection',features:[]});return Response.json({type:'FeatureCollection',features:[{type:'Feature',properties:{height:12},geometry:{type:'Polygon',coordinates:[[[129.06,35.1581],[129.0603,35.1581],[129.0603,35.1583],[129.06,35.1583],[129.06,35.1581]]]}}]});}
 if(u.hostname==='ssd.jpl.nasa.gov')return Response.json({result:'$$SOE\n2026-Jun-21 03:00, , 160.5, 76.0,\n$$EOE'});
 if(u.hostname==='power.larc.nasa.gov')return Response.json({parameters:{ALLSKY_SFC_SW_DWN:{units:'Wh/m^2'}},properties:{parameter:{ALLSKY_SFC_SW_DWN:{2026062100:200,2026062101:-999}}}});
 throw Error('Unexpected external URL');};
const {server,buildingHeight,fromGeometry}=require('../server');let base,cookie,csrf;
before(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));base='http://127.0.0.1:'+server.address().port;});after(async()=>{await new Promise(r=>server.close(r));global.fetch=realFetch;fs.rmSync(temp,{recursive:true,force:true});});
function req(p,method='GET',b,extra={}){return fetch(base+p,{method,redirect:'manual',headers:{Origin:process.env.APP_ORIGIN,'Content-Type':'application/json',...extra},...(b?{body:JSON.stringify(b)}:{})});}
const trip={start:{lat:35.158,lng:129.06},end:{lat:35.158,lng:129.061},date:'2026-06-21',time:'12:00'};
test('public entry works; secrets and source files cannot be downloaded',async()=>{assert.equal((await req('/')).status,200);for(const p of ['/.env','/server.js','/data/heights.json','/package.json','/../server.js'])assert.equal((await req(p)).status,404);const config=await(await req('/api/client-config')).json();assert.deepEqual(Object.keys(config),['kakaoJavaScriptKey']);});
test('all admin pages and old/new diagnostic endpoints require server auth',async()=>{for(const p of ['/admin','/admin.html','/admin.js'])assert.equal((await req(p)).status,303);for(const p of ['/api/admin/status','/api/admin/heights','/api/buildings','/api/nasa-sun','/api/vworld-status','/api/power','/api/osm'])assert.equal((await req(p)).status,401);assert.equal((await req('/api/admin/heights','POST',{id:'a'.repeat(24),height:10,source:'test'})).status,401);});
test('login is origin protected and wrong password fails',async()=>{assert.equal((await req('/api/admin/login','POST',{username:'test-admin',password:'bad'},{Origin:'https://evil.example'})).status,403);assert.equal((await req('/api/admin/login','POST',{username:'test-admin',password:'bad'})).status,401);});
test('scrypt authentication; HttpOnly SameSite cookie; protected assets accessible',async()=>{const r=await req('/api/admin/login','POST',{username:'test-admin',password:'test-password-only'});assert.equal(r.status,200);cookie=r.headers.get('set-cookie').split(';')[0];assert.match(r.headers.get('set-cookie'),/HttpOnly; SameSite=Strict/);csrf=(await r.json()).csrf;assert.equal((await req('/admin','GET',null,{Cookie:cookie})).status,200);assert.equal((await req('/admin.js','GET',null,{Cookie:cookie})).status,200);});
test('height mutation CSRF + bounds + persistent save + removal',async()=>{const id='a'.repeat(24),b={id,height:23,source:'대장 확인 테스트'};assert.equal((await req('/api/admin/heights','POST',b,{Cookie:cookie})).status,403);assert.equal((await req('/api/admin/heights','POST',{...b,height:999},{Cookie:cookie,'X-CSRF-Token':csrf})).status,400);assert.equal((await req('/api/admin/heights','POST',b,{Cookie:cookie,'X-CSRF-Token':csrf})).status,200);assert.equal(JSON.parse(fs.readFileSync(path.join(temp,'heights.json')))[id].height,23);assert.equal((await req('/api/admin/height-history')).status,401);const history=await(await req('/api/admin/height-history','GET',null,{Cookie:cookie})).json();assert.equal(history.history.at(-1).after.height,23);assert.equal((await req('/api/admin/heights','DELETE',{id},{Cookie:cookie,'X-CSRF-Token':csrf})).status,200);});
test('place proxy projects safe place fields',async()=>{const d=await(await req('/api/places?q=부산')).json();assert.equal(d.places[0].name,'부산 테스트 장소');assert.equal(d.places[0].lat,35.158);});
test('automatic pipeline: real-shaped provider fixtures, no duplicate alternative',async()=>{const r=await req('/api/analyse','POST',trip);assert.equal(r.status,200);const d=await r.json();assert.equal(d.routes.length,1);assert.equal(d.comparison,'single');assert.equal(d.routes[0].distance,100);assert.equal(d.routes[0].time,90);assert.ok(d.routes[0].analysis);const record=JSON.parse(fs.readFileSync(path.join(temp,'building-check.json'),'utf8'));assert.ok(record.reasonCode);assert.ok(!JSON.stringify(record).includes('test-only'));assert.ok(!('coords' in record));});
test('different returned routes are compared without inventing coordinates',async()=>{same=false;const d=await(await req('/api/analyse','POST',{...trip,end:{lat:35.158,lng:129.0611}})).json();assert.equal(d.routes.length,2);assert.ok(d.shady===0||d.shady===1,JSON.stringify(d));same=true;});
test('upstream route denial produces error without invented distance or secret',async()=>{failRoute=true;const r=await req('/api/analyse','POST',{...trip,end:{lat:35.158,lng:129.062}});assert.equal(r.status,502);assert.ok(!(await r.text()).includes('test-only'));failRoute=false;});
test('incomplete buildings preserve actual walking metrics, suppress shade',async()=>{partial=true;const d=await(await req('/api/analyse','POST',{...trip,end:{lat:35.158,lng:129.065}})).json();assert.equal(d.routes[0].distance,100);assert.equal(d.shady,null);assert.equal(d.routes[0].analysis,null);partial=false;});
test('invalid date/coordinate/same point rejected before upstream request',async()=>{for(const b of [{...trip,date:'2026-02-30'},{...trip,start:{lat:0,lng:0}},{...trip,end:trip.start}])assert.equal((await req('/api/analyse','POST',b)).status,400);assert.equal((await req('/api/analyse','POST',trip,{Origin:'https://evil.example'})).status,403);});
test('JPL response parsed and independently compared with local calculation',async()=>{const r=await req('/api/admin/sun?lat=35.158&lng=129.06&date=2026-06-21&time=12:00','GET',null,{Cookie:cookie});const d=await r.json();assert.equal(d.nasa.azimuth,160.5);assert.ok(Number.isFinite(d.deltaElevation));assert.ok(Number.isFinite(d.local.elevation));});
test('POWER fill values excluded; time standard and provider unit preserved',async()=>{const d=await(await req('/api/admin/power?lat=35.158&lng=129.06&date=2026-06-21','GET',null,{Cookie:cookie})).json();assert.equal(d.hours.length,1);assert.equal(d.unit,'Wh/m^2');assert.equal(d.timeStandard,'UTC');});
test('provided height and floors extraction; MultiPolygon and courtyard classification',()=>{assert.equal(buildingHeight({buld_hght:'13.5'}).quality,'measured');assert.equal(buildingHeight({grnd_flr_cnt:'4'}).quality,'floor-estimate');const poly=[[[129,35],[129.001,35],[129.001,35.001],[129,35]]];const b=fromGeometry({type:'MultiPolygon',coordinates:[poly]}, {},[34,128,36,130]);assert.equal(b.length,1);assert.match(b[0].id,/^[a-f0-9]{24}$/);const holes=fromGeometry({type:'Polygon',coordinates:[...poly,poly[0]]},{},[34,128,36,130]);assert.equal(holes[0].tags.shade_geometry_unsupported,true);});
test('logout revokes session and clears cookie',async()=>{const r=await req('/api/admin/logout','POST',{}, {Cookie:cookie,'X-CSRF-Token':csrf});assert.equal(r.status,200);assert.match(r.headers.get('set-cookie'),/Max-Age=0/);assert.equal((await req('/api/admin/status','GET',null,{Cookie:cookie})).status,401);});
test('login brute force rate limit',async()=>{for(let i=0;i<6;i++)await req('/api/admin/login','POST',{username:'test-admin',password:'bad'});assert.equal((await req('/api/admin/login','POST',{username:'test-admin',password:'test-password-only'})).status,429);});

// Oct 2026 official SDK CDN migration: allow automatic SDK resources in every required directive.
test('HTTP response permits Kakao current CDN scripts/styles/images/connections and keeps other restrictions',async()=>{
 const r=await req('/');const policy=r.headers.get('content-security-policy');
 for(const name of ['script-src','style-src','img-src','connect-src']){const directive=policy.split(';').map(s=>s.trim()).find(s=>s.startsWith(name+' '));assert.ok(directive.split(/\s+/).includes('https://*.kakaocdn.net'),name);}
 assert.match(policy,/object-src 'none'/);assert.match(policy,/frame-ancestors 'none'/);assert.ok(!policy.includes('unsafe-eval'));assert.ok(!policy.includes("script-src *"));
});

test('anonymous public journey job completes without cookies or an administrator login',async()=>{const submitted=await req('/api/journeys','POST',trip);assert.equal(submitted.status,202);const {id}=await submitted.json();assert.match(id,/^[a-f0-9]{48}$/);let job;for(let i=0;i<400;i++){job=await(await req('/api/journeys/'+id)).json();if(job.status!=='running')break;await new Promise(r=>setTimeout(r,25));}assert.equal(job.status,'done');assert.ok(job.result.routes[0].distance>0);assert.ok(job.result.visuals);assert.equal((await req('/api/journeys/'+'0'.repeat(48))).status,404);});
test('NASA comparison and POWER references are readable without login while editing remains protected',async()=>{const sun=await req('/api/solar-check?lat=35.158&lng=129.06&date=2026-06-21&time=12:00');assert.equal(sun.status,200);assert.ok(Number.isFinite((await sun.json()).deltaElevation));const power=await req('/api/solar-power?lat=35.158&lng=129.06&date=2026-06-21');assert.equal(power.status,200);assert.equal((await req('/api/admin/heights','POST',{id:'a'.repeat(24),height:20,source:'attempt'})).status,401);});
test('cancel job is origin protected and remains cancelled despite late provider completion',async()=>{const {id}=await(await req('/api/journeys','POST',trip)).json();assert.equal((await req('/api/journeys/'+id,'DELETE',null,{Origin:'https://evil.example'})).status,403);assert.equal((await req('/api/journeys/'+id,'DELETE')).status,200);const job=await(await req('/api/journeys/'+id)).json();assert.equal(job.status,'cancelled');});

test('cancelling one job aborts only its requests and frees a slot for another job',async()=>{
 const ids=[];
 holdWalk=true;
 try{
  const first={...trip,end:{lat:35.158,lng:129.066}};
  const second={...trip,end:{lat:35.158,lng:129.067}};
  for(const input of [first,second]){
   const response=await req('/api/journeys','POST',input);
   assert.equal(response.status,202);
   ids.push((await response.json()).id);
  }
  assert.equal(walkStarted,6);
  assert.equal((await req('/api/analyse','POST',first)).status,429);
  assert.equal((await req('/api/journeys/'+ids[0],'DELETE')).status,200);
  assert.equal(walkAborted,3);
  const cancelled=await(await req('/api/journeys/'+ids[0])).json();
  assert.equal(cancelled.status,'cancelled');
  assert.equal(cancelled.result,undefined);
  assert.equal((await(await req('/api/journeys/'+ids[1])).json()).status,'running');
  holdWalk=false;
  assert.equal((await req('/api/analyse','POST',first)).status,200);
 }finally{
  holdWalk=false;
  for(const id of ids)await req('/api/journeys/'+id,'DELETE');
 }
});

test('retry reuses the original departure and rejects expired result IDs',async()=>{
 const input={...trip,time:'12:37'};
 const response=await req('/api/journeys','POST',input);
 const {id}=await response.json();
 async function finish(id){
  for(let i=0;i<400;i++){
   const job=await(await req('/api/journeys/'+id)).json();
   if(job.status!=='running')return job;
   await new Promise(resolve=>setTimeout(resolve,25));
  }
  throw Error('job did not finish');
 }
 const original=await finish(id);
 assert.equal(original.status,'done');
 const retry=await req('/api/journeys','POST',{retryJob:id,time:'23:59'});
 assert.equal(retry.status,202);
 const updated=await finish((await retry.json()).id);
 assert.equal(updated.status,'done');
 assert.equal(updated.result.departure,original.result.departure);
 assert.equal((await req('/api/journeys','POST',{retryJob:'0'.repeat(48)})).status,404);
});

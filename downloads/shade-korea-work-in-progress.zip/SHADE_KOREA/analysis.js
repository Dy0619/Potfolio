'use strict';
const P=require('./precision');
function departure(date,time){
 if(!/^20\d{2}-\d{2}-\d{2}$/.test(date||'')||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time||''))throw Error('올바른 날짜와 시간을 선택해 주세요.');
 const d=new Date(`${date}T${time}:00+09:00`);
 if(!Number.isFinite(+d)||new Date(+d+9*3600000).toISOString().slice(0,10)!==date)throw Error('존재하지 않는 날짜입니다.');
 return d;
}
function routeKey(r){ // Ignore provider densification of the same straight segments.
 const m=P.metresPerDegree(r.coords[0][0]);const stack=[];
 for(const p of r.coords){const q=[p[1]*m.east,p[0]*m.north];if(stack.length&&Math.hypot(q[0]-stack.at(-1)[0],q[1]-stack.at(-1)[1])<.1)continue;
 while(stack.length>=2){const a=stack.at(-2),b=stack.at(-1),dx=q[0]-a[0],dy=q[1]-a[1],l=Math.hypot(dx,dy);if(!l||Math.abs(dx*(b[1]-a[1])-dy*(b[0]-a[0]))/l>.5||(b[0]-a[0])*dx+(b[1]-a[1])*dy<0)break;stack.pop();}stack.push(q);}
 return stack.map(p=>p.map(x=>Math.round(x)).join(',')).join(';');
}
function uniqueRoutes(routes){const seen=new Set();return routes.filter(r=>{const k=routeKey(r);if(seen.has(k))return false;seen.add(k);return true;});}
function routeBox(routes){
 const pts=routes.flatMap(r=>r.coords),lat=pts.reduce((n,p)=>n+p[0],0)/pts.length,m=P.metresPerDegree(lat),pad=325;
 const b=[Math.min(...pts.map(p=>p[0]))-pad/m.north,Math.min(...pts.map(p=>p[1]))-pad/m.east,Math.max(...pts.map(p=>p[0]))+pad/m.north,Math.max(...pts.map(p=>p[1]))+pad/m.east];
 if(b[0]<32.8||b[2]>39||b[1]<124||b[3]>132||(b[2]-b[0])*(b[3]-b[1])>.00035)throw Error('이 경로는 한 번에 분석할 수 있는 범위를 넘었어요. 더 가까운 두 지점으로 시도해 주세요.');
 return b;
}
function evaluate(routes,data,date,overrides={}){
 const origin={lat:routes[0].coords[0][0],lng:routes[0].coords[0][1]},m=P.metresPerDegree(origin.lat);
 const buildings=(data.elements||[]).map(b=>({tags:overrides[b.id]?{...b.tags,height:String(overrides[b.id].height)}:b.tags,xy:b.geometry.map(p=>[(p.lon-origin.lng)*m.east,(p.lat-origin.lat)*m.north]),holes:(b.holes||[]).map(r=>r.map(p=>[(p.lon-origin.lng)*m.east,(p.lat-origin.lat)*m.north]))}));
 const known=buildings.filter(b=>P.heightRange(b.tags,15).source!=='assumed'&&!b.tags.shade_geometry_unsupported);
 const missing=buildings.filter(b=>P.heightRange(b.tags,15).source==='assumed'||b.tags.shade_geometry_unsupported).map(b=>({...b,minx:Math.min(...b.xy.map(p=>p[0])),maxx:Math.max(...b.xy.map(p=>p[0])),miny:Math.min(...b.xy.map(p=>p[1])),maxy:Math.max(...b.xy.map(p=>p[1]))}));
 // Explicit failed/unprocessed tile boxes are used only to localize uncertainty.
 const coverageGaps=(data.coverageGaps||[]).filter(b=>Array.isArray(b)&&b.length===4&&b.every(Number.isFinite)&&b[0]<b[2]&&b[1]<b[3]).map(b=>{
  const minx=(b[1]-origin.lng)*m.east,maxx=(b[3]-origin.lng)*m.east,miny=(b[0]-origin.lat)*m.north,maxy=(b[2]-origin.lat)*m.north;
  return {xy:[[minx,miny],[maxx,miny],[maxx,maxy],[minx,maxy]],minx,maxx,miny,maxy};
 });
 const unknownCoverage=!!data.partial&&(!coverageGaps.length||coverageGaps.length!==(data.coverageGaps||[]).length);
 const quality={hub:data.hub,total:buildings.length,provided:buildings.filter(b=>P.heightRange(b.tags,15).source==='measured').length,floorEstimated:buildings.filter(b=>P.heightRange(b.tags,15).source==='floors').length,assumed:buildings.filter(b=>P.heightRange(b.tags,15).source==='assumed').length,missing:buildings.filter(b=>P.heightRange(b.tags,15).source==='assumed').length,unsupported:buildings.filter(b=>b.tags.shade_geometry_unsupported).length,usable:known.length,corrected:Object.keys(overrides).filter(id=>data.elements.some(b=>b.id===id)).length,partial:!!data.partial,supplemented:buildings.filter(b=>b.tags.shade_height_supplemented).length,heightSourceChecked:(data.heightDiagnostics||[]).filter(x=>x.ok).length,heightSourceFailed:(data.heightDiagnostics||[]).filter(x=>!x.ok).length};
 const results=routes.map(r=>({...r,analysis:null})),sun=P.sunPosition(date,origin.lat,origin.lng);
 function unavailable(reason,reasonCode){for(const r of results){delete r._profile;delete r._referenceProfile;}return {reason,reasonCode,routes:results,shortest:0,shady:null,quality,sun,analysisMode:'unavailable',comparison:'unavailable'};}
 if(!buildings.length)return unavailable('주변 건물 자료를 확보하지 못했어요. 실제 도보 경로만 표시해요.','BUILDING_EMPTY');
 if(!known.length)return unavailable('분석에 사용할 높이·층수 자료를 가진 건물이 없어요. 그늘 경로라고 표시할 근거가 없어 실제 도보 경로만 보여드려요.',quality.heightSourceFailed?'HEIGHT_LOOKUP_FAILED':quality.unsupported?'GEOMETRY_UNSUPPORTED':'HEIGHT_DATA_INSUFFICIENT');
 // Unknown heights are checked against each walking sample's sunward ray.
 // Incomplete source coverage and unsupported geometry stay conservative.
 let reference=!!data.partial||quality.unsupported>0;
 for(const r of results){
  const end=P.sunPosition(new Date(+date+r.time*1000),origin.lat,origin.lng),minimum=Math.min(sun.elevation,end.elevation);
  if(minimum<=5){r.analysisReason='SUN_TOO_LOW';continue;}
  const shadowLimited=minimum-6<=5||known.some(b=>P.heightRange(b.tags,15).high/Math.tan((minimum-6)*Math.PI/180)>320);
  const conservative=unknownCoverage||quality.unsupported>0||shadowLimited;
  const referenceReason=unknownCoverage?'source_incomplete':quality.unsupported?'geometry_unsupported':'shadow_limit';
  const index=P.buildIndex(known,{...sun,elevation:Math.min(sun.elevation,end.elevation)},15);
  const metres=r.coords.slice(1).reduce((d,p,i)=>d+Math.hypot((p[1]-r.coords[i][1])*m.east,(p[0]-r.coords[i][0])*m.north),0);
  const profile=P.sampleRoute(r.coords,origin,date,index,metres/r.time,700,{allowPartial:true,reference:conservative,referenceReason,exclusions:missing,coverageGaps});
  if(!profile||profile.insufficient){r.analysisReason='SAMPLE_INSUFFICIENT';continue;}
  r._profile=profile;
  if(conservative||profile.unknownFraction>1e-9)reference=true;
 }
 if(!results[0]._profile)return unavailable('이 시각의 경로는 태양이 낮거나 유효 판정 구간이 부족해 그늘을 비교하기 어려워요.','SUN_OR_SAMPLE_UNAVAILABLE');
 // A shared comparison mode suppresses full ratios if any route is incomplete,
 // but does not erase supported sun/shade segments on another route.
 for(const r of results){
  const a=r._profile;if(!a)continue;
  r.analysis={
   unknownReasonDistances:Object.fromEntries(Object.entries(a.reasonFractions||{}).map(([k,v])=>[k,r.distance*v])),
   classifiedSunDistance:r.distance*a.sunFraction,uncertainDistance:r.distance*a.uncertainFraction,
   buildingOverlapDistance:r.distance*(a.buildingOverlapFraction||0),unclassifiedDistance:r.distance*(a.unknownFraction||0),
   kind:reference?'reference':'complete',low:reference?null:a.low,mid:reference?null:a.mid,high:reference?null:a.high,
   coverage:a.coverage,points:a.points,segments:a.segments,visualTruncated:a.visualTruncated,
   knownShadeLowSeconds:r.time*a.knownShadeLow,knownShadeMidSeconds:r.time*a.knownShadeMid,knownShadeHighSeconds:r.time*a.knownShadeHigh,
   knownShadeLowDistance:r.distance*a.knownShadeLow,knownShadeMidDistance:r.distance*a.knownShadeMid,knownShadeHighDistance:r.distance*a.knownShadeHigh,
   unconfirmedSeconds:r.time*(a.unknownFraction||0)
  };
  delete r._profile;
 }
 const reason=reference?'경로에 영향을 줄 수 있는 미확인 자료 또는 계산 범위 제한이 있어 전체 그늘 비율은 표시하지 않아요. 판정 가능한 구간은 지도에 따로 표시해요.':'';
 return {reasonCode:reference?'PARTIAL_REFERENCE':'OK',routes:results,shortest:0,shady:0,quality,reason,analysisMode:reference?'reference':'complete',comparison:results.length===1?'single':'same',sun};
}
module.exports={departure,uniqueRoutes,routeBox,evaluate};

'use strict';
const {Worker}=require('node:worker_threads');
const path=require('node:path');
function compute(module,method,args,signal){
 signal?.throwIfAborted();
 return new Promise((resolve,reject)=>{
  const worker=new Worker(path.join(__dirname,'compute-worker.js'),{workerData:{module,method,args}});
  let settled=false;
  function finish(error,value){
   if(settled)return;
   settled=true;
   signal?.removeEventListener('abort',abort);
   worker.terminate();
   if(error)reject(error);else resolve(value);
  }
  function abort(){finish(signal.reason);}
  signal?.addEventListener('abort',abort,{once:true});
  worker.once('message',message=>finish(message.error?Error(message.error):null,message.value));
  worker.once('error',error=>finish(error));
  worker.once('exit',code=>{if(!settled)finish(Error('계산 작업이 종료됐어요. 다시 검색해 주세요.'));});
 });
}
module.exports=compute;

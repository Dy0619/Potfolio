'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { execFile } = require('node:child_process');
const { promisify } = require('node:util');
const { parseEnv } = require('./settings');
async function setup(root) {
 const file = path.join(root, '.env');
 const contents = fs.readFileSync(file, 'utf8');
 if (process.env.BUILDING_HUB_API_KEY || parseEnv(contents).BUILDING_HUB_API_KEY) return;
 if (process.platform !== 'win32') {
  console.log('건축HUB 보완을 사용하려면 .env의 BUILDING_HUB_API_KEY에 발급 키를 설정하세요.');
  return;
 }
 let key;
 try {
  key = (await promisify(execFile)('powershell.exe', ['-NoProfile', '-STA', '-Command', fs.readFileSync(path.join(__dirname, 'select-hub-key.ps1'), 'utf8')], { encoding: 'utf8', maxBuffer: 10000 })).stdout.trim();
 } catch {
  console.log('건축HUB 설정을 건너뛰었습니다. 다음 실행에서 다시 입력할 수 있어요.');
  return;
 }
 if (!key) return;
 if (!/^[A-Za-z0-9%+/=._-]{10,1000}$/.test(key)) throw Error('건축HUB 인증키 형식을 확인하세요.');
 const cleaned = contents.split(/\r?\n/).filter(line => !/^\s*BUILDING_HUB_API_KEY\s*=/.test(line)).join('\n');
 fs.writeFileSync(file, cleaned + '\nBUILDING_HUB_API_KEY=' + key + '\n', { mode: 0o600 });
 console.log('건축HUB 인증키를 저장했습니다. 서버에서 연결을 시도합니다.');
}
module.exports = { setup };

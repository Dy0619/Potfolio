'use strict';
const fs=require('node:fs');
function parseEnv(raw){const values={};for(const line of raw.replace(/^\uFEFF/,'').split(/\r?\n/)){const m=line.match(/^\s*(?:export\s+)?([A-Z_][A-Z0-9_]*)\s*=\s*(.*)$/);if(!m)continue;const value=m[2].trim(),quoted=value.match(/^(['"])(.*?)\1\s*(?:#.*)?$/);values[m[1]]=quoted?quoted[2]:value.replace(/\s+#.*$/,'').trim();}return values;}
function importSettings(source,destination){
 if(fs.statSync(source).size>100000)throw Error('선택한 파일이 너무 큽니다. 기존 .env 파일을 선택하세요.');
 const parsed=parseEnv(fs.readFileSync(source,'utf8'));
 const names=['KAKAO_REST_API_KEY','KAKAO_JAVASCRIPT_KEY','VWORLD_API_KEY','BUILDING_HUB_API_KEY','ADMIN_USERNAME','ADMIN_PASSWORD_HASH'];
 if(!names.some(k=>k.endsWith('KEY')&&parsed[k]))throw Error('API 키가 있는 기존 .env 파일을 선택해 주세요.');
 for(const k of names)if(parsed[k]&&/[\r\n'"]/.test(parsed[k]))throw Error('설정 값 형식을 확인할 수 없습니다.');
 const rows=names.map(k=>k+'='+(parsed[k]||''));rows.push('VWORLD_DOMAIN=http://127.0.0.1:5500','APP_ORIGIN=http://127.0.0.1:5500','NODE_ENV=development');
 fs.writeFileSync(destination,rows.join('\n')+'\n',{flag:'wx',mode:0o600});
 return {rest:!!parsed.KAKAO_REST_API_KEY,map:!!parsed.KAKAO_JAVASCRIPT_KEY,vworld:!!parsed.VWORLD_API_KEY};
}
module.exports={parseEnv,importSettings};

[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Windows.Forms
$form = New-Object System.Windows.Forms.Form
$form.Text = 'SHADE - 건축HUB 인증키 설정'
$form.Size = New-Object System.Drawing.Size(500,220)
$form.StartPosition = 'CenterScreen'
$label = New-Object System.Windows.Forms.Label
$label.Text = '공공데이터포털에서 발급받은 건축HUB 인증키를 붙여넣으세요.'
$label.SetBounds(20,20,450,40)
$inputBox = New-Object System.Windows.Forms.TextBox
$inputBox.SetBounds(20,65,440,30)
$inputBox.UseSystemPasswordChar = $true
$save = New-Object System.Windows.Forms.Button
$save.Text = '저장'
$save.SetBounds(250,115,100,35)
$save.DialogResult = [System.Windows.Forms.DialogResult]::OK
$skip = New-Object System.Windows.Forms.Button
$skip.Text = '나중에'
$skip.SetBounds(360,115,100,35)
$skip.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.AddRange(@($label,$inputBox,$save,$skip))
$form.AcceptButton = $save
$form.CancelButton = $skip
if ($form.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($inputBox.Text) }

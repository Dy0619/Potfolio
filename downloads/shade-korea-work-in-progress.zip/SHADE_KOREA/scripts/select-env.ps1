[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
Add-Type -AssemblyName System.Windows.Forms
$picker = New-Object System.Windows.Forms.OpenFileDialog
$picker.Title = "기존 SHADE 폴더의 .env 파일을 선택하세요"
$picker.Filter = "All files (*.*)|*.*"
$picker.FileName = ".env"
$picker.CheckFileExists = $true
if ($picker.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
    [Console]::Write($picker.FileName)
} else {
    exit 2
}

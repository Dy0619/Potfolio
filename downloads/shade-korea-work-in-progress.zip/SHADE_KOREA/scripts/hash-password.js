'use strict';
const crypto=require('node:crypto');
// Hidden input; avoids command history, process arguments and echoing passwords.
if(!process.stdin.isTTY){console.error('Run npm run admin:hash in an interactive terminal.');process.exit(1);}
process.stdout.write('New admin password (12+ characters, hidden): ');let password='';
process.stdin.setRawMode(true);process.stdin.setEncoding('utf8');process.stdin.resume();
process.stdin.on('data',data=>{for(const ch of data){if(ch==='\u0003'){process.stdin.setRawMode(false);process.exit(130);}if(ch==='\r'||ch==='\n'){process.stdin.setRawMode(false);process.stdin.pause();if(password.length<12){console.error('\nUse at least 12 characters.');process.exit(1);}const salt=crypto.randomBytes(16).toString('hex');console.log('\nADMIN_PASSWORD_HASH=scrypt:'+salt+':'+crypto.scryptSync(password,salt,64).toString('hex'));return;}if(ch==='\u007f'||ch==='\b')password=password.slice(0,-1);else if(password.length<256)password+=ch;}});

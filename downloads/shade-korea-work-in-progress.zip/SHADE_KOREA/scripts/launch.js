'use strict';
const fs=require('node:fs'),path=require('node:path');
const {fork,execFile}=require('node:child_process');
const {promisify}=require('node:util');const execute=promisify(execFile);
const {importSettings}=require('./settings');
const ROOT=path.resolve(__dirname,'..');
async function launch(){
 if(typeof AbortSignal.any!=='function')throw Error('Node.js 20.3 이상이 필요합니다. Node.js LTS를 설치한 뒤 다시 실행해 주세요.');
 process.chdir(ROOT);
 console.log('\nSHADE KOREA 5.17.0 | SK517-20261116-DESIGN');
 console.log('Folder: '+ROOT);
 if(!fs.existsSync(path.join(ROOT,'.env'))){
  console.log('\n최초 실행: 기존 SHADE 폴더의 .env 파일을 선택해 주세요.');
  let selected;
  if(process.platform==='win32'){
   try{selected=(await execute('powershell.exe',['-NoProfile','-STA','-Command',fs.readFileSync(path.join(__dirname,'select-env.ps1'),'utf8')],{encoding:'utf8',maxBuffer:100000})).stdout.trim();}
   catch{throw Error('설정 선택을 완료하지 못했습니다. 다시 실행하여 기존 SHADE 폴더의 .env 파일을 선택해 주세요.');}
  }else{
   const rl=require('node:readline/promises').createInterface({input:process.stdin,output:process.stdout});try{selected=await rl.question('Previous .env path: ');}finally{rl.close();}
  }
  if(!selected)throw Error('기존 .env 파일을 선택하지 않았습니다.');
  importSettings(selected,path.join(ROOT,'.env'));
  console.log('설정을 가져왔습니다. API 키 값은 화면에 표시하지 않습니다.');
 }
 await require('./setup-hub').setup(ROOT);
 const child=fork(path.join(ROOT,'server.js'),[],{cwd:ROOT,stdio:['inherit','inherit','inherit','ipc'],execArgv:[]});
 child.on('message',async message=>{
  if(message.type==='shade-ready'){
   console.log('\nREADY: SHADE '+message.version+' | '+message.build);
   console.log(message.url+'/?build='+encodeURIComponent(message.build));
   if(process.platform==='win32')try{await execute('explorer.exe',[message.url+'/?build='+encodeURIComponent(message.build)]);}catch{console.log('Open the address above in your browser.');}
  }
  if(message.type==='shade-error'&&message.code==='EADDRINUSE')console.error('\n5500 포트에서 다른 서버가 실행 중입니다. 이전 SHADE 검은 창 또는 Live Server를 종료한 뒤 이 폴더의 START_WINDOWS.bat을 다시 실행하세요.');
 });
 child.on('error',()=>{console.error('서버를 시작하지 못했습니다. Node.js 설치 상태를 확인하세요.');process.exitCode=1;});
 child.on('exit',code=>{process.exitCode=code||0;});
}
if(require.main===module)launch().catch(e=>{console.error(e.message);process.exitCode=1;});
module.exports={launch};

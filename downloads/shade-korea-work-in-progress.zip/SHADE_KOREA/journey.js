'use strict';
const A=require('./analysis'),Search=require('./walk-search'),P=require('./precision');
function validate(input){
 if(input.extraMinutes!==undefined&&![5,10,15].includes(input.extraMinutes))throw Error('추가 도보 시간을 선택해 주세요.');
 const date=A.departure(input.date,input.time);for(const p of [input.start,input.end])if(!p||typeof p.lat!=='number'||typeof p.lng!=='number'||!Number.isFinite(p.lat)||!Number.isFinite(p.lng)||p.lat<32.8||p.lat>39||p.lng<124||p.lng>132)throw Error('대한민국 내의 출발지와 도착지를 선택해 주세요.');
 if(input.start.lat===input.end.lat&&input.start.lng===input.end.lng)throw Error('출발지와 도착지가 같아요.');
 const detour=input.detour===undefined?.3:Number(input.detour);if(![.1,.3,.5,1].includes(detour))throw Error('우회 범위를 선택해 주세요.');return {date,detour};
}
function withinLimit(route,shortest,detour,extraMinutes){if(extraMinutes!==undefined)return route.time<=shortest.time+extraMinutes*60;return route.distance<=shortest.distance*(1+detour)+.1&&route.time<=shortest.time*(1+detour)+.1;}
function rank(result,detour,extraMinutes){
 if(result.comparison==='unavailable')return result;
 const base=result.routes[0],reference=result.analysisMode==='reference';
 const score=r=>reference?r.time-r.analysis.knownShadeLowSeconds:r.time*(1-r.analysis.mid);
 const unknownShare=r=>Math.min(1,Math.max(0,(r.analysis.unclassifiedDistance||0)/r.distance));
 const comparable=r=>!reference||Math.abs(unknownShare(r)-unknownShare(base))<=.15;
 const baseScore=score(base),improvement=Math.max(5,baseScore*.02);let chosen=0,best=baseScore,coverageMismatch=false;
 result.routes.forEach((r,i)=>{if(i&&r.analysis&&withinLimit(r,base,detour,extraMinutes)&&score(r)<best){if(!comparable(r)){coverageMismatch=true;return;}chosen=i;best=score(r);}});
 if(baseScore-best<improvement)chosen=0;
 for(const r of result.routes)if(r.analysis)r.analysis={...r.analysis,exposedSeconds:reference?null:r.time*(1-r.analysis.mid),exposedSecondsLow:reference?null:r.time*(1-r.analysis.high),exposedSecondsHigh:reference?null:r.time*(1-r.analysis.low)};
 result.coverageMismatch=coverageMismatch&&!chosen;
 result.shady=chosen;result.comparison=result.routes.length===1?'single':chosen?'different':'same';result.recommendationKind=reference?'reference':'estimated';result.savedExposureSeconds=reference?null:base.analysis.exposedSeconds-result.routes[chosen].analysis.exposedSeconds;result.knownShadeGainSeconds=result.routes[chosen].analysis.knownShadeLowSeconds-base.analysis.knownShadeLowSeconds;result.referenceScoreImprovement=reference?baseScore-score(result.routes[chosen]):null;result.recommendationRobust=reference?null:chosen?result.routes[chosen].analysis.exposedSecondsHigh<base.analysis.exposedSecondsLow:null;return result;
}
// Spread the display budget along all verified routes, not just the origin.
function visualContext(data,date,shortest,overrides={},routes=[shortest]){
 const origin=shortest.coords[0],sun=P.sunPosition(date,origin[0],origin[1]);
 const anchors=[];
 for(const route of routes){
  const lengths=route.coords.slice(1).map((p,i)=>Search.distance(route.coords[i],p));
  const total=lengths.reduce((a,b)=>a+b,0),steps=Math.max(1,Math.min(48,Math.ceil(total/150)));
  for(let j=0;j<=steps;j++){
   let target=total*j/steps,i=0;while(i<lengths.length-1&&target>lengths[i])target-=lengths[i++];
   const a=route.coords[i],b=route.coords[i+1]||a,t=lengths[i]?target/lengths[i]:0;
   anchors.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]);
  }
 }
 const all=(data?.elements||[]).map(b=>{const tags=overrides[b.id]?{...b.tags,height:String(overrides[b.id].height)}:b.tags;const h=P.heightRange(tags,15);return {rings:[b.geometry,...(b.holes||[])].map(r=>r.map(p=>[p.lat,p.lon])),height:h.source==='assumed'||b.tags.shade_geometry_unsupported?null:h,source:h.source};});
 const buckets=anchors.map(p=>all.map((b,i)=>({i,d:Search.distance(p,b.rings[0][0])})).filter(x=>x.d<=400).sort((a,b)=>a.d-b.d));
 const selected=new Set();let depth=0,added=true;
 while(selected.size<600&&added){added=false;for(const bucket of buckets){if(bucket[depth]){selected.add(bucket[depth].i);added=true;}if(selected.size>=600)break;}depth++;}
 const buildings=[...selected].map(i=>all[i]);
 return {buildings,sun,departureOnly:true,truncated:all.length>buildings.length,total:all.length,partial:!!data?.partial};
}
function timeComparison(routes,data,date,overrides,current,mode){
 return (mode==='now'?[0,30,60]:[-30,0,30]).map(offset=>{
  const instant=new Date(+date+offset*60000),local=new Date(+instant+9*3600000).toISOString();
  const evaluated=offset===0?current:A.evaluate(routes,data,instant,overrides);
  return {offset,date:local.slice(0,10),time:local.slice(11,16),sun:evaluated.sun,
   routes:evaluated.routes.map(r=>({analysis:r.analysis,reason:r.analysisReason||evaluated.reason||''}))};
 });
}
async function findJourney(input,dependencies){
 const {date,detour:requestedDetour}=validate(input),{walk,buildings,roads,signal}=dependencies,overrides=dependencies.overrides||{};
 const progress=(phase,message,partial)=>{signal?.throwIfAborted();dependencies.progress?.(phase,message,partial);};
 const compute=dependencies.compute||((module,method,args)=>({analysis:A,search:Search,journey:{timeComparison,visualContext}})[module][method](...args));
 progress('ROUTES','최단 도보 경로와 기본 후보를 확인하고 있어요.');
 const requests=['SHORTEST','BROAD_FIRST','ACCESSIBLE'].map(mode=>walk(mode,[]));
 const settled=Promise.allSettled(requests);
 try{
  const first=await requests[0];
  progress('ROUTES','최단 경로를 찾았어요. 다른 후보를 확인하고 있어요.',{routes:[first],shortest:0,shady:null,comparison:'pending'});
 }catch(error){signal?.throwIfAborted();}
 const initial=await settled;
 signal?.throwIfAborted();
 if(initial[0].status==='rejected'){const e=Error(initial[0].reason.message||'최단 경로를 찾지 못했어요.');e.status=initial[0].reason?.status===422?422:502;throw e;}
 const shortest=initial[0].value;
 const detour=input.extraMinutes?input.extraMinutes*60/shortest.time:requestedDetour;
 let routes=A.uniqueRoutes(initial.filter(r=>r.status==='fulfilled').map(r=>r.value)).filter((r,i)=>!i||withinLimit(r,shortest,detour,input.extraMinutes));
 const search={status:'not_started',proposed:0,verified:0,rejected:0,detour};const sun=P.sunPosition(date,input.start.lat,input.start.lng);
 const candidateFailures=initial.filter(r=>r.status==='rejected'&&r.reason?.status!==422).length;
 let data;
 const unavailable=(reason,reasonCode)=>({routes:routes.map(r=>({...r,analysis:null})),shortest:0,shady:null,comparison:'unavailable',analysisMode:'unavailable',reason,reasonCode,quality:null,sun,search,visuals:visualContext(data,date,shortest,overrides,routes),candidateFailures});
 progress('BUILDINGS','최단 경로를 찾았어요. 건물 자료를 확인하고 있어요.',{routes:[shortest],shortest:0,shady:null,comparison:'pending'});
 try{data=await buildings(routes);}catch(e){signal?.throwIfAborted();return unavailable(e.publicMessage||'주변 건물 자료를 확인하지 못했어요. 실제 경로만 표시합니다.',e.code||'BUILDING_FETCH_FAILED');}
 let result=await compute('analysis','evaluate',[routes,data,date,overrides]);
 if(result.comparison!=='unavailable'){
  progress('SHADE_SEARCH','실제 보행로에서 햇빛을 덜 맞는 우회 후보를 탐색하고 있어요.');
  try{
   const adjusted={...data,elements:data.elements.map(b=>overrides[b.id]?{...b,tags:{...b.tags,height:String(overrides[b.id].height)}}:b)};
   let proposed;try{const network=await roads(data.bbox);const dates=[0,shortest.time/2,shortest.time].map(seconds=>new Date(+date+seconds*1000));
   const samples=await compute('search','proposeAtTimes',[network.elements,adjusted,dates,shortest,detour]);
   proposed={...samples[0]};
   const seen=new Set();proposed.plans=[0,1,2].flatMap(index=>samples.map(sample=>sample.plans[index]).filter(Boolean)).filter(plan=>{const key=JSON.stringify(plan.via);if(seen.has(key))return false;seen.add(key);return true;}).slice(0,6);
   search.timeSamples=3;search.networkStatus=proposed.status;}catch(error){
    signal?.throwIfAborted();
    const status=error.code==='ROAD_AREA_LIMIT'?'network_limit':'network_unavailable';
    proposed={plans:[],status};search.networkStatus=status;
   }
   search.method='road-network';if(!proposed.plans.length){proposed.plans=await compute('search','shadowProbes',[adjusted,date,shortest,detour]);if(proposed.plans.length){proposed.status='shadow_points_proposed';search.method='shadow-probes';}}
   Object.assign(search,{status:proposed.status,proposed:proposed.plans.length,nodes:proposed.nodes||0,edges:proposed.edges||0});
   if(proposed.plans.length){
    progress('VERIFY_ROUTES','우회 후보를 카카오 도보 API로 다시 확인하고 있어요.');
    const checked=await Promise.allSettled(proposed.plans.map(p=>walk('SHORTEST',p.via)));
    signal?.throwIfAborted();
    const extra=checked.filter(r=>r.status==='fulfilled'&&withinLimit(r.value,shortest,detour,input.extraMinutes)).map(r=>({...r.value,origin:'shade-network'}));search.rejected=checked.length-extra.length;
    search.verificationFailures=checked.filter(r=>r.status==='rejected'&&r.reason?.status!==422).length;
    search.noRoute=checked.filter(r=>r.status==='rejected'&&r.reason?.status===422).length;
    search.overLimit=checked.filter(r=>r.status==='fulfilled').length-extra.length;
    const combined=A.uniqueRoutes([...routes,...extra]);search.verified=combined.length-routes.length;
    if(combined.length>routes.length){
     progress('CHECK_COVERAGE','새 경로 전체의 건물 범위와 이동 중 태양 변화를 다시 분석하고 있어요.');
     try{const expanded=await buildings(combined);const compared=await compute('analysis','evaluate',[combined,expanded,date,overrides]);if(compared.comparison!=='unavailable'){routes=combined;data=expanded;result=compared;}else{search.status='expanded_data_insufficient';search.verified=0;}}catch{signal?.throwIfAborted();search.status='expanded_data_failed';search.verified=0;}
    }
   }
  }catch{signal?.throwIfAborted();search.status='network_unavailable';}
 }else search.status='height_or_sun_unavailable';
 progress('RESULTS','경로 비교와 지도 위 그늘 표시를 준비하고 있어요.');
 result=rank(result,detour,input.extraMinutes);
 for(const route of result.routes){
  const geometryDistance=route.coords.slice(1).reduce((sum,point,i)=>sum+Search.distance(route.coords[i],point),0);
  const overlap=route.analysis?.buildingOverlapDistance||0;
  route.geometryCheck={geometryDistance,providerDistance:route.distance,lengthMismatch:Math.abs(geometryDistance-route.distance)>Math.max(50,route.distance*.25),buildingOverlap:overlap,overlapWarning:overlap>Math.max(20,route.distance*.1)};
 }progress('TIME_COMPARE','경로 비교를 마쳤어요. 시간별 예측을 계산하고 있어요.',{...result,search});
 let times=[],timeComparisonFailed=false;
 try{times=await compute('journey','timeComparison',[routes,data,date,overrides,result,input.departureMode]);}
 catch(error){signal?.throwIfAborted();timeComparisonFailed=true;}
 const visuals=await compute('journey','visualContext',[data,date,shortest,overrides,routes]);
 return {...result,timeComparison:times,timeComparisonFailed,comparisonMode:input.departureMode==='now'?'now':+date<Date.now()?'past':'scheduled',search,visuals,candidateFailures,departure:input.date+' '+input.time+' KST',diagnostic:{tiles:data.tiles,sources:data.heightDiagnostics,hub:data.hub}};
}
module.exports={validate,withinLimit,rank,visualContext,timeComparison,findJourney};

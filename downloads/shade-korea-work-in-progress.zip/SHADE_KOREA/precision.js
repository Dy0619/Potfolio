/* SHADE 3.8 — deterministic local sun position and ray/footprint shadow model.
   Solar coordinates: detailed NOAA/Meeus based equation of time and declination;
   not a certified NREL SPA implementation. Confidence bands reflect building heights only.
   All angles clockwise from TRUE north. EN plane: x east, y north, metres. */
(function(root,factory){const v=factory();if(typeof module!=='undefined'&&module.exports)module.exports=v;root.ShadePrecision=v;})(typeof window!=='undefined'?window:globalThis,function(){
 'use strict';
 const PI=Math.PI,RAD=PI/180,DEG=180/PI;
 const norm=(a)=>((a%360)+360)%360;
 const sind=(x)=>Math.sin(x*RAD),cosd=(x)=>Math.cos(x*RAD);
 const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
 function sunPosition(date,lat,lon){
  // NOAA solar calculator polynomial series, based on Meeus algorithms.
  const jd=date.getTime()/86400000+2440587.5,T=(jd-2451545.0)/36525;
  const L0=norm(280.46646+T*(36000.76983+0.0003032*T));
  const M=norm(357.52911+T*(35999.05029-0.0001537*T));
  const e=0.016708634-T*(0.000042037+0.0000001267*T);
  const C=sind(M)*(1.914602-T*(0.004817+0.000014*T))+sind(2*M)*(0.019993-0.000101*T)+sind(3*M)*0.000289;
  const omega=125.04-1934.136*T,lambda=L0+C-0.00569-0.00478*sind(omega);
  const eps0=23+(26+(21.448-T*(46.815+T*(0.00059-0.001813*T)))/60)/60;
  const eps=eps0+0.00256*cosd(omega);
  const decl=Math.asin(sind(eps)*sind(lambda));
  const y=Math.tan(eps*RAD/2)**2;
  const eqTime=4*DEG*(y*Math.sin(2*L0*RAD)-2*e*Math.sin(M*RAD)+4*e*y*Math.sin(M*RAD)*Math.cos(2*L0*RAD)-0.5*y*y*Math.sin(4*L0*RAD)-1.25*e*e*Math.sin(2*M*RAD));
  const utcMin=date.getUTCHours()*60+date.getUTCMinutes()+date.getUTCSeconds()/60;
  const solarMin=((utcMin+eqTime+4*lon)%1440+1440)%1440;
  let ha=solarMin/4-180;if(ha<-180)ha+=360;
  const phi=lat*RAD,har=ha*RAD;
  const elevation=Math.asin(clamp(Math.sin(phi)*Math.sin(decl)+Math.cos(phi)*Math.cos(decl)*Math.cos(har),-1,1))*DEG;
  const azimuth=norm(Math.atan2(Math.sin(har),Math.cos(har)*Math.sin(phi)-Math.tan(decl)*Math.cos(phi))*DEG+180);
  return {elevation,azimuth,model:'NOAA/Meeus (geometric)'};
 }
 function metresPerDegree(lat){const p=lat*RAD;return {north:111132.92-559.82*Math.cos(2*p)+1.175*Math.cos(4*p)-0.0023*Math.cos(6*p),east:111412.84*Math.cos(p)-93.5*Math.cos(3*p)+0.118*Math.cos(5*p)};}
 function heightRange(tags,fallback){const raw=Number.parseFloat(String(tags.height||'').replace(',','.'));
  if(Number.isFinite(raw)&&raw>=2&&raw<=400)return {low:raw,mid:raw,high:raw,source:'measured'};
  const levels=Number.parseFloat(String(tags['building:levels']||'').replace(',','.'));
  if(Number.isFinite(levels)&&levels>0&&levels<=120){const h=levels*3;return {low:h*0.8,mid:h,high:h*1.2,source:'floors'}};
  const mid=clamp(Number(fallback)||15,6,36);return {low:Math.max(3,mid*0.45),mid,high:mid*1.8,source:'assumed'};
 }
 function inside(x,y,pts){let inside=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){
  const a=pts[i],b=pts[j];if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])inside=!inside;
 }return inside;}
 function rayHitDistance(x,y,ux,uy,poly,maxLen){
  let closest=Infinity;
  for(let i=0,j=poly.length-1;i<poly.length;j=i++){
   const a=poly[j],b=poly[i],ex=b[0]-a[0],ey=b[1]-a[1];
   const denom=ux*ey-uy*ex;
   if(Math.abs(denom)<1e-12)continue;
   const rx=a[0]-x,ry=a[1]-y;
   const t=(rx*ey-ry*ex)/denom,u=(rx*uy-ry*ux)/denom;
   if(t>=0.0001&&t<=maxLen&&u>=-1e-9&&u<=1+1e-9&&t<closest)closest=t;
  }
  return closest;
 }
 function buildIndex(buildings, sun, fallback, cellSize=56){
  const grid=new Map(),items=[];
  const minimumEl=Math.max(5,sun.elevation-6),tanEl=Math.tan(minimumEl*RAD);
  for(const b of buildings){
   if(!b.xy||b.xy.length<3)continue;
   const heights=heightRange(b.tags||{},fallback);
   const poly=b.xy;
   const maxLen=Math.min(320,heights.high/tanEl);
   const minx=Math.min(...poly.map(p=>p[0]))-maxLen,maxx=Math.max(...poly.map(p=>p[0]))+maxLen;
   const miny=Math.min(...poly.map(p=>p[1]))-maxLen,maxy=Math.max(...poly.map(p=>p[1]))+maxLen;
   const item={poly,holes:b.holes||[],heights,maxLen};const id=items.push(item)-1;
   for(let ix=Math.floor(minx/cellSize);ix<=Math.floor(maxx/cellSize);ix++)for(let iy=Math.floor(miny/cellSize);iy<=Math.floor(maxy/cellSize);iy++){
    const key=ix+','+iy;if(!grid.has(key))grid.set(key,[]);grid.get(key).push(id);
   }
  }
  return {items,grid,cellSize};
 }
 function statusAt(index,x,y,sun){
  if(!index||sun.elevation<=5)return null;
  const list=index.grid.get(Math.floor(x/index.cellSize)+','+Math.floor(y/index.cellSize))||[];
  const ux=Math.sin(sun.azimuth*RAD),uy=Math.cos(sun.azimuth*RAD),tanEl=Math.tan(sun.elevation*RAD);
  let low=false,mid=false,high=false;
  // Check every footprint before accepting any shadow: a prior shadow hit must
  // never hide that a later footprint contains the walking sample.
  if(list.some(id=>{const b=index.items[id];return inside(x,y,b.poly)&&!b.holes.some(h=>inside(x,y,h));}))return {unknown:true,reason:'building_overlap',low:false,mid:false,high:false};
  for(const id of list){
   const b=index.items[id];
   const len=Math.min(320,b.heights.high/tanEl);
   const t=Math.min(...[b.poly,...b.holes].map(r=>rayHitDistance(x,y,ux,uy,r,len)));
   if(!Number.isFinite(t))continue;
   const z=t*tanEl;
   if(z<=b.heights.high)high=true;
   if(z<=b.heights.mid)mid=true;
   if(z<=b.heights.low)low=true;
   if(low&&mid&&high)break;
  }
  return {unknown:false,low,mid,high};
 }
 // Missing heights never receive an invented height. A sunward footprint can
 // affect a sample at some height; footprints behind the sample cannot.
 function missingHeightCanShade(buildings,x,y,sun){
  const ux=Math.sin(sun.azimuth*RAD),uy=Math.cos(sun.azimuth*RAD);
  return buildings.some(b=>{
   // Ray/AABB slab rejection before testing polygon edges. No arbitrary height cap.
   let enter=0,leave=Infinity;
   for(const [v,u,lo,hi] of [[x,ux,b.minx,b.maxx],[y,uy,b.miny,b.maxy]]){
    if(Math.abs(u)<1e-12){if(v<lo||v>hi)return false;}
    else{const a=(lo-v)/u,z=(hi-v)/u;enter=Math.max(enter,Math.min(a,z));leave=Math.min(leave,Math.max(a,z));if(leave<enter)return false;}
   }
   return Number.isFinite(rayHitDistance(x,y,ux,uy,b.xy,Infinity));
  });
 }
 function sampleRoute(coords,origin,date,sunIndex,speed=1.25,maxSamples=700,options={}){
  if(!sunIndex||!Array.isArray(coords)||coords.length<2)return null;
  const meters=metresPerDegree(origin.lat);
  const pt=a=>[(a[1]-origin.lng)*meters.east,(a[0]-origin.lat)*meters.north];
  let total=0,count=0,skipped=0,low=0,mid=0,high=0,elapsed=0,validLength=0,unknownLength=0,buildingOverlapLength=0;
  const dots=[],segments=[],cache=new Map(),reasonLengths={};let visualTruncated=false;
  function segment(i,j,n,kind,reason=null){
   const a=coords[i-1],b=coords[i],at=t=>[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];const left=at(j/n),right=at((j+1)/n),last=segments.at(-1);
   if(last&&last.kind===kind&&last.reason===reason&&Math.abs(last.coords.at(-1)[0]-left[0])+Math.abs(last.coords.at(-1)[1]-left[1])<1e-8){if(last.coords.length<10000)last.coords.push(right);else visualTruncated=true;}
   else if(segments.length<1500)segments.push({kind,reason,coords:[left,right]});else visualTruncated=true;
  }
  const distances=[];let pathLen=0;
  for(let i=1;i<coords.length;i++){const [ax,ay]=pt(coords[i-1]),[bx,by]=pt(coords[i]);const d=Math.hypot(bx-ax,by-ay);distances.push(d);pathLen+=d;}
  const pitch=Math.max(5,pathLen/maxSamples);
  for(let i=1;i<coords.length;i++){
   const a=pt(coords[i-1]),b=pt(coords[i]),dist=distances[i-1];
   if(!Number.isFinite(dist)||dist>3000)return {insufficient:true,coverage:0};if(dist<0.01)continue;
   const n=Math.max(1,Math.ceil(dist/pitch));
   for(let j=0;j<n;j++){
    const t=(j+0.5)/n,at=elapsed+dist*t;
    const instant=new Date(date.getTime()+at/speed*1000);
    const key=Math.floor(instant.getTime()/60000);let sun=cache.get(key);
    if(!sun){sun=sunPosition(instant,origin.lat,origin.lng);cache.set(key,sun);}
    if(sun.elevation<=5)return null;
    const x=a[0]+(b[0]-a[0])*t,y=a[1]+(b[1]-a[1])*t;
    let s=statusAt(sunIndex,x,y,sun);
    if(options.exclusions?.some(b=>x>=b.minx&&x<=b.maxx&&y>=b.miny&&y<=b.maxy&&inside(x,y,b.xy)&&!(b.holes||[]).some(h=>inside(x,y,h))))s={unknown:true,reason:'building_overlap',low:false,mid:false,high:false};
    if(s&&!s.unknown&&!s.low&&missingHeightCanShade(options.exclusions||[],x,y,sun))s={unknown:true,reason:'height_missing',low:false,mid:false,high:false};
    if(s&&!s.unknown&&(options.coverageGaps?.some(b=>x>=b.minx&&x<=b.maxx&&y>=b.miny&&y<=b.maxy)||(!s.low&&missingHeightCanShade(options.coverageGaps||[],x,y,sun))))s={unknown:true,reason:'source_incomplete',low:false,mid:false,high:false};
    if(options.reference&&s&&!s.unknown&&!s.high)s={unknown:true,reason:options.referenceReason||'source_incomplete',low:false,mid:false,high:false};
    if(!s||s.unknown){if(s?.reason==='building_overlap')buildingOverlapLength+=dist/n;const reason=s?.reason||'unclassified';reasonLengths[reason]=(reasonLengths[reason]||0)+dist/n;skipped++;unknownLength+=dist/n;segment(i,j,n,'unknown',reason);continue;}
    segment(i,j,n,s.low===s.high?(s.mid?'shade':'sun'):'uncertain');count++;validLength+=dist/n;low+=Number(s.low)*dist/n;mid+=Number(s.mid)*dist/n;high+=Number(s.high)*dist/n;
    if(dots.length<115&&j%3===0)dots.push({lat:coords[i-1][0]+(coords[i][0]-coords[i-1][0])*t,lng:coords[i-1][1]+(coords[i][1]-coords[i-1][1])*t,shade:s.mid,confident:s.low===s.high});
   }
   elapsed+=dist;
  }
  const totalSamples=count+skipped;
  if(!options.allowPartial&&(!count||validLength/Math.max(.001,validLength+unknownLength)<0.9))return {insufficient:true,coverage:validLength/Math.max(.001,validLength+unknownLength)};
  return {reasonFractions:Object.fromEntries(Object.entries(reasonLengths).map(([k,v])=>[k,v/Math.max(.001,validLength+unknownLength)])),sunFraction:(validLength-high)/Math.max(.001,validLength+unknownLength),uncertainFraction:(high-low)/Math.max(.001,validLength+unknownLength),buildingOverlapFraction:buildingOverlapLength/Math.max(.001,validLength+unknownLength),unknownFraction:unknownLength/Math.max(.001,validLength+unknownLength),low:low/Math.max(.001,validLength+unknownLength),mid:mid/Math.max(.001,validLength),high:(high+unknownLength)/Math.max(.001,validLength+unknownLength),knownShadeLow:low/Math.max(.001,validLength+unknownLength),knownShadeMid:mid/Math.max(.001,validLength+unknownLength),knownShadeHigh:high/Math.max(.001,validLength+unknownLength),coverage:validLength/Math.max(.001,validLength+unknownLength),points:count,skipped,dots,segments,visualTruncated};
 }
 return {sunPosition,metresPerDegree,heightRange,inside,rayHitDistance,buildIndex,statusAt,sampleRoute,missingHeightCanShade};
});

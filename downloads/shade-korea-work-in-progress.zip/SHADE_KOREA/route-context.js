'use strict';
const P=require('./precision');
const reference=P.metresPerDegree(36),SIZE=650,PADDING=350;
const xy=p=>[(p[1]-124)*reference.east,(p[0]-32.8)*reference.north];
const coord=(x,y)=>[32.8+y/reference.north,124+x/reference.east];
function pointSegment(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/Math.max(.0001,dx*dx+dy*dy)));return Math.hypot(p[0]-a[0]-dx*t,p[1]-a[1]-dy*t);}
function routeTiles(routes,limit=48){
 const tiles=new Map();
 for(const route of routes)for(let i=1;i<route.coords.length;i++){
  const a=xy(route.coords[i-1]),b=xy(route.coords[i]);if(Math.hypot(a[0]-b[0],a[1]-b[1])<.01)continue;
  const loX=Math.floor((Math.min(a[0],b[0])-PADDING)/SIZE),hiX=Math.floor((Math.max(a[0],b[0])+PADDING)/SIZE),loY=Math.floor((Math.min(a[1],b[1])-PADDING)/SIZE),hiY=Math.floor((Math.max(a[1],b[1])+PADDING)/SIZE);
  if((hiX-loX+1)*(hiY-loY+1)>5000)throw Error('분석 범위를 초과했어요. 더 가까운 경로를 선택해 주세요.');
  for(let x=loX;x<=hiX;x++)for(let y=loY;y<=hiY;y++){
   if(pointSegment([(x+.5)*SIZE,(y+.5)*SIZE],a,b)>PADDING+SIZE/Math.sqrt(2))continue;
   const key=x+':'+y;if(tiles.has(key))continue;const s=coord(x*SIZE,y*SIZE),n=coord((x+1)*SIZE,(y+1)*SIZE);if(s[0]<32.8||n[0]>39||s[1]<124||n[1]>132)throw Error('지원 구역 경계를 벗어났어요.');tiles.set(key,[s[0],s[1],n[0],n[1]]);if(tiles.size>limit)throw Error('주변 건물 조회량이 한 번에 분석할 수 있는 범위를 넘었어요.');
  }
 }
 if(!tiles.size)throw Error('경로 도형을 확인하지 못했어요.');
 const boxes=[...tiles.values()];const bbox=[Math.min(...boxes.map(b=>b[0])),Math.min(...boxes.map(b=>b[1])),Math.max(...boxes.map(b=>b[2])),Math.max(...boxes.map(b=>b[3]))];return {boxes,bbox};
}
module.exports={routeTiles,pointSegment};

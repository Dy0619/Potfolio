'use strict';
/** SHADE KOREA 3.8 — local-only Kakao walking API proxy, dependency-free Node.js 18+ */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = __dirname;
const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || 5500); // matches the domain already registered on Kakao Developers
const {parseEnv}=require('./scripts/settings');
function readEnv(){const target=path.join(ROOT,'.env');return fs.existsSync(target)?parseEnv(fs.readFileSync(target,'utf8')):{};}
const VERSION='5.17.0',BUILD='SK517-20261116-DESIGN';
const ENV = readEnv();
const Hub = require('./building-hub');
const hub = Hub.createHub({key:process.env.BUILDING_HUB_API_KEY || ENV.BUILDING_HUB_API_KEY || '',directory:path.join(ROOT,'data','building-hub')});
const API_KEY = (process.env.KAKAO_REST_API_KEY || ENV.KAKAO_REST_API_KEY || '').trim();
// Public JavaScript SDK key only. The REST API key never leaves this server.
const JS_KEY = (process.env.KAKAO_JAVASCRIPT_KEY || ENV.KAKAO_JAVASCRIPT_KEY || '').trim();
const cache = new Map();
function send(res,code,value) {
  const body = JSON.stringify(value);
  res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(body);
}
function checkCoord(value,min,max) {
  if (value===null || value.trim()==='')return null;
  const v=Number(value);
  return Number.isFinite(v) && v>=min && v<=max?v:null;
}
function requestSignal(signal, timeoutMs) {
 const timeout=AbortSignal.timeout(timeoutMs);
 return signal?AbortSignal.any([signal,timeout]):timeout;
}
async function walking(req,res,url,signal){
 signal?.throwIfAborted();
  if(!API_KEY)return send(res,503,{error:'장소·경로 서비스가 아직 준비되지 않았어요.'});
  const q=url.searchParams;
  const x0=checkCoord(q.get('start_x'),124,132), y0=checkCoord(q.get('start_y'),32.8,39),
        x1=checkCoord(q.get('end_x'),124,132), y1=checkCoord(q.get('end_y'),32.8,39);
  const mode=q.get('route_mode') || 'SHORTEST';
  if ([x0,y0,x1,y1].some(v=>v===null) || !['SHORTEST','BROAD_FIRST','ACCESSIBLE'].includes(mode)) {
    send(res,400,{error:'잘못된 좌표 또는 경로 옵션입니다.'});return;
  }
  const params = new URLSearchParams({start_x:String(x0), start_y:String(y0), end_x:String(x1), end_y:String(y1),route_mode:mode,input_coord:'WGS84',output_coord:'WGS84'});
  const vx=q.get('via_x'),vy=q.get('via_y');
  if(vx!==null||vy!==null){const xs=(vx||'').split(','),ys=(vy||'').split(',');if(xs.length!==ys.length||xs.length>5||xs.some(x=>checkCoord(x,124,132)===null)||ys.some(y=>checkCoord(y,32.8,39)===null))return send(res,400,{error:'경유지 좌표를 확인할 수 없어요.'});params.set('via_x',xs.join(','));params.set('via_y',ys.join(','));}
  const key=params.toString();
  const saved=cache.get(key);
  if(saved && Date.now()-saved.when<10*60*1000){send(res,200,saved.data);return;}
  try{
    const upstream = await fetch('https://dapi.kakao.com/v2/routing/walk?'+params.toString(),{
      headers:{Authorization:'KakaoAK '+API_KEY,Accept:'application/json'},signal:requestSignal(signal,14000)
    });
    const json=await upstream.json().catch(()=>({}));
    if (!upstream.ok){
      // Do not send credentials, upstream payloads or request headers to the browser.
      console.warn('Kakao routing status:',upstream.status);
      send(res,upstream.status===429?429:502,{error:upstream.status===429?'카카오 API 호출 한도를 초과했어요.':'카카오 API가 요청을 거절했어요. 상태 코드: '+upstream.status});
      return;
    }
    if (json.status==='NO_RESULT'){
      send(res,422,{error:'도보 경로를 찾지 못했어요.'});return;
    }
    if (json.status!=='OK' || !json.route){
      send(res,502,{error:'카카오 도보 경로 응답을 확인하지 못했어요.'});return;
    }
    const props=json.route.properties || {};
    const coords=[];let invalidPath=false;
    for(const leg of json.route.legs || [])for(const step of leg.steps || [])for(const pair of step.path?.points || []) {
      const lng=Number(pair[0]), lat=Number(pair[1]);
      if(Number.isFinite(lng)&&Number.isFinite(lat)&&lat>=32.8&&lat<=39&&lng>=124&&lng<=132)coords.push([lat,lng]);else invalidPath=true;
    }
    if(invalidPath || coords.length<2 || coords.length>30000 || !Number.isFinite(Number(props.totalDistance)) || !Number.isFinite(Number(props.totalTime)) || Number(props.totalDistance)<=0 || Number(props.totalTime)<=0){
      send(res,502,{error:'카카오 API 응답에서 경로 좌표를 읽지 못했어요.'});return;
    }
    const data={status:'OK',mode,origin:vx?'shade-network':'provider',distance:Number(props.totalDistance),time:Number(props.totalTime),coords};
    if(cache.size>=100)cache.delete(cache.keys().next().value);
    cache.set(key,{data,when:Date.now()});
    send(res,200,data);
  }catch(err){
    signal?.throwIfAborted();
    console.warn('Kakao route fetch error:',err.name);
    send(res,502,{error:err.name==='TimeoutError'?'카카오 응답 시간이 초과됐어요.':'카카오 서버에 연결할 수 없어요.'});
  }
}
// OSM building/road data: backend proxy, bounded Korea-only query, sequential fallback and cache.
// Public Overpass endpoints are best effort, not an uptime-guaranteed service.
const OSM_ENDPOINTS = [
  'https://overpass.private.coffee/api/interpreter',
  'https://overpass-api.de/api/interpreter',
];
const osmCache = new Map();
const osmPending = new Map();
function validKorea(v, min, max){return typeof v==='string' && v.trim()!=='' && Number.isFinite(Number(v)) && Number(v)>=min && Number(v)<=max ? Number(v) : null;}
function osmBBox(q){
  const lat=validKorea(q.get('lat'),32.8,39.0), lng=validKorea(q.get('lng'),124.0,132.0);
  if(lat===null||lng===null) return null;
  const aLat=validKorea(q.get('startLat'),32.8,39.0), aLng=validKorea(q.get('startLng'),124.0,132.0);
  const bLat=validKorea(q.get('endLat'),32.8,39.0), bLng=validKorea(q.get('endLng'),124.0,132.0);
  const yPad=0.0016, xPad=0.0016/Math.max(0.55,Math.cos(lat*Math.PI/180));
  let south=lat-0.0044, north=lat+0.0044, west=lng-0.0044/Math.max(.55,Math.cos(lat*Math.PI/180)), east=lng+0.0044/Math.max(.55,Math.cos(lat*Math.PI/180));
  if([aLat,aLng,bLat,bLng].every(v=>v!==null)) {
    const s=Math.min(aLat,bLat)-yPad,n=Math.max(aLat,bLat)+yPad;
    const w=Math.min(aLng,bLng)-xPad,e=Math.max(aLng,bLng)+xPad;
    // Limit nationwide free-public requests to a small walking neighborhood.
    if(n-s<=0.014 && e-w<=0.018 && (n-s)*(e-w)<=0.00018){south=s; north=n; west=w; east=e;}
  }
  return [south,west,north,east].map(v=>Number(v.toFixed(6)));
}
function osmQuery(bbox, buildingsOnly){
  const b=bbox.join(',');
  return `[out:json][timeout:22];(${`way["building"](${b});`}${buildingsOnly?'':`way["highway"](${b});`});out geom;`;
}
async function oneOverpass(endpoint,bbox,buildingsOnly,timeoutMs){
  const query=osmQuery(bbox,buildingsOnly);
  const body=new URLSearchParams({data:query}).toString();
  const resp=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},body,signal:AbortSignal.timeout(timeoutMs)});
  if(!resp.ok)throw new Error('Overpass HTTP '+resp.status);
  const ctype=(resp.headers.get('content-type')||'').toLowerCase();
  if(!ctype.includes('json'))throw new Error('Overpass returned non-JSON');
  // Avoid huge responses from public services overwhelming the local browser.
  const raw=await resp.text();
  if(raw.length>12_000_000)throw new Error('Overpass response too large');
  const data=JSON.parse(raw);
  if(!Array.isArray(data.elements))throw new Error('Overpass elements missing');
  return data.elements.filter(x=>x && x.type==='way' && Array.isArray(x.geometry)).slice(0,5000);
}
async function osmQueryWithFallback(bbox){
  const attempts=[
    {endpoint:OSM_ENDPOINTS[0],buildingsOnly:false,timeout:17000,source:'OpenStreetMap · 1차'},
    {endpoint:OSM_ENDPOINTS[1],buildingsOnly:false,timeout:17000,source:'OpenStreetMap · 2차'},
    {endpoint:OSM_ENDPOINTS[0],buildingsOnly:true,timeout:13000,source:'OpenStreetMap · 건물만'},
  ];
  let lastError='';
  for(const a of attempts){
    try{
      const elements=await oneOverpass(a.endpoint,bbox,a.buildingsOnly,a.timeout);
      return {elements,bbox,buildingsOnly:a.buildingsOnly,source:a.source};
    }catch(err){lastError=String(err.name==='TimeoutError'?'timeout':err.message||err.name).slice(0,160);console.warn('[SHADE/OSM]',a.source,'failed:',lastError);}
  }
  throw new Error('공개 OSM 데이터 서버 2곳이 응답하지 않았습니다. 네트워크 상태를 확인하거나 잠시 뒤 다시 요청해 주세요.');
}
async function osmArea(res,url){
  const bbox=osmBBox(url.searchParams);
  if(!bbox){send(res,400,{error:'대한민국 범위의 올바른 좌표가 필요해요.'});return;}
  const key=bbox.map(x=>x.toFixed(4)).join(':');
  const hit=osmCache.get(key);
  if(hit && Date.now()-hit.when<12*60*1000){send(res,200,{...hit.data,cached:true});return;}
  if(!osmPending.has(key))osmPending.set(key,osmQueryWithFallback(bbox).then(data=>{
    if(osmCache.size>=25)osmCache.delete(osmCache.keys().next().value);
    osmCache.set(key,{when:Date.now(),data});
    return data;
  }).finally(()=>osmPending.delete(key)));
  try{send(res,200,await osmPending.get(key));}
  catch(e){send(res,503,{error:e.message||'공개 지도 서버 연결 오류'});}
}


// SHADE 3.5: VWorld GIS building geometry proxy. The VWorld key is server-only.
// This endpoint is independent of Kakao routing and never exposes secrets in its JSON.
const VWORLD_KEY=(process.env.VWORLD_API_KEY||ENV.VWORLD_API_KEY||'').trim();
const VWORLD_DOMAIN=(process.env.VWORLD_DOMAIN||ENV.VWORLD_DOMAIN||'http://127.0.0.1:5500').trim();
const vwCache=new Map();
const vwPending=new Map();
const tileCache=new Map();
const TILE_CAP=650, TILE_MAX_DEPTH=3, MAX_REMOTE_CALLS=48, MAX_BUILDINGS=8500;
function projectCoord(pair){
  if(!Array.isArray(pair)||pair.length<2)return null;
  let x=Number(pair[0]),y=Number(pair[1]);
  if(!Number.isFinite(x)||!Number.isFinite(y))return null;
  // Some WFS EPSG:4326 responses flip latitude and longitude order.
  if(x>32&&x<40&&y>124&&y<132){const tmp=x;x=y;y=tmp;}
  if(Math.abs(x)>1000000&&Math.abs(y)>1000000){
    const lon=x*180/20037508.34;
    const lat=(2*Math.atan(Math.exp(y*Math.PI/20037508.34))-Math.PI/2)*180/Math.PI;
    x=lon;y=lat;
  }
  if(x<124||x>132||y<32.8||y>39)return null;
  return {lat:y,lon:x};
}
function getFeatures(root){
  const options=[root,root?.response?.result?.featureCollection,root?.response?.result,
    root?.featureCollection,root?.result,root?.data];
  for(const obj of options){
    if(obj&&Array.isArray(obj.features))return obj.features;
    if(obj&&obj.type==='FeatureCollection'&&Array.isArray(obj.features))return obj.features;
  }
  return null;
}
const {buildingHeight,enrichExact,schemaSummary}=require('./building-data');
function fromGeometry(geometry,properties,bbox){
  if(!geometry)return [];
  const polygons=geometry.type==='Polygon'?[geometry.coordinates]:geometry.type==='MultiPolygon'?geometry.coordinates:[];
  const result=[];
  for(const poly of polygons){
    if(!Array.isArray(poly)||!Array.isArray(poly[0]))continue;
    const ring=poly[0].map(projectCoord);
    if(ring.length<4||ring.some(x=>!x))continue;
    if(Math.max(...ring.map(p=>p.lat))<bbox[0]||Math.min(...ring.map(p=>p.lat))>bbox[2]||Math.max(...ring.map(p=>p.lon))<bbox[1]||Math.min(...ring.map(p=>p.lon))>bbox[3])continue;
    const h=buildingHeight(properties);
    const holes=poly.slice(1).map(r=>r.map(projectCoord));
    const outer=ring.map(p=>[p.lon,p.lat]);
    const invalidHole=holes.some(r=>r.length<4||r.some(p=>!p)||ringId(r)===ringId(ring)||r.some(p=>!require('./precision').inside(p.lon,p.lat,outer)));
    const tags={building:'yes',shade_geometry_unsupported:invalidHole};
    const hubIdentity=Hub.identity(properties);if(hubIdentity)tags.shade_hub_identity=hubIdentity;
    for(const [field,value] of Object.entries(properties))if(field.replace(/_/g,'').toLowerCase()==='bdmgtsn'&&/^[0-9]{20,30}$/.test(String(value)))tags.shade_join_id=String(value);
    if(h.height)tags.height=h.height;
    if(h.levels)tags['building:levels']=h.levels;
    tags.shade_height_source=h.quality;if(h.field)tags.shade_height_field=h.field;
    result.push({type:'way',id:crypto.createHash('sha256').update(ringId(ring)).digest('hex').slice(0,24),tags,geometry:ring,holes:invalidHole?[]:holes});
  }
  return result;
}
// SHADE 3.6: request actual JSON, not just an Accept header.
// Two official VWorld services are attempted: the 2D building layer first,
// followed by NED GIS building WFS. Provider XML error reports are classified.
function safeProviderText(value){
  return String(value||'').replaceAll(VWORLD_KEY,'[KEY-REDACTED]')
    .replace(/(\b(?:key|apikey|api_key)\s*[=:]\s*)[^\s&<"']+/ig,'$1[REDACTED]')
    .replace(/\b[a-f0-9]{32,}\b/ig,'[REDACTED]').slice(0,160);
}
function xmlErrorInfo(body){
  const code=(body.match(/(?:exceptionCode|code|errorCode)=["']([^"']{1,70})["']/i)||[])[1]||'';
  const text=(body.match(/<(?:\w+:)?(?:ExceptionText|ServiceException|errorText|message)[^>]*>([\s\S]*?)<\/(?:\w+:)?(?:ExceptionText|ServiceException|errorText|message)>/i)||[])[1]||'';
  const plain=text.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim();
  const head=body.slice(0,800).replace(/^\s*<\?xml[^>]*>\s*/i,'');
  const isXml=/^\s*</.test(head);
  return {code:safeProviderText(code),message:safeProviderText(plain),isXml,
    exception:/ExceptionReport|ServiceExceptionReport/i.test(head),
    featureCollection:/FeatureCollection/i.test(head)};
}
async function fetchVWorldJSON(source,endpoint,params,signal){
  let response;
  const remote='https://api.vworld.kr'+endpoint+'?'+new URLSearchParams({
    ...params,key:VWORLD_KEY,domain:VWORLD_DOMAIN
  }).toString();
  try{
    response=await fetch(remote,{headers:{Accept:'application/json',Referer:VWORLD_DOMAIN},signal:requestSignal(signal,9500)});
  }catch(err){throw new Error(source+': '+(err.name==='TimeoutError'?'응답 시간 초과':'서버 접속 실패'));}
  const body=await response.text();
  if(body.length>12_000_000)throw new Error(source+': 응답이 너무 큽니다. 더 작은 지역에서 시도해 주세요.');
  let json;
  try{json=JSON.parse(body);}catch{
    const info=xmlErrorInfo(body);
    if(info.exception){
      throw new Error(source+': XML 오류 '+[info.code,info.message].filter(Boolean).join(' — ').slice(0,170));
    }
    if(info.featureCollection){throw new Error(source+': 건물 도형을 XML로 반환했습니다. JSON 출력 설정이 적용되지 않았습니다.');}
    if(info.isXml)throw new Error(source+': XML 응답을 반환했습니다 (정상 JSON 응답 아님).');
    if(/^\s*<!doctype html|^\s*<html/i.test(body))throw new Error(source+': HTML 오류 페이지를 반환했습니다.');
    throw new Error(source+': JSON이 아닌 응답을 반환했습니다 (HTTP '+response.status+').');
  }
  if(!response.ok){throw new Error(source+': HTTP '+response.status+' '+safeProviderText(json?.response?.error?.text||''));}
  const status=json?.response?.status;
  if(status&&String(status).toUpperCase()==='NOT_FOUND')return {features:[],reportedTotal:0};
  if(status&&String(status).toUpperCase()!=='OK'&&String(status).toUpperCase()!=='SUCCESS'){
    const error=json?.response?.error||{};
    throw new Error(source+': '+safeProviderText(error.code||status)+(error.text?' — '+safeProviderText(error.text):''));
  }
  const features=getFeatures(json);
  if(!features)throw new Error(source+': 예상한 건물 도형 구조가 아닙니다.');
  const reportedTotal = [json?.response?.record?.total,json?.response?.result?.totalCount,
    json?.response?.result?.featureCollection?.totalFeatures,json?.totalFeatures,json?.numberMatched]
    .map(Number).find(n=>Number.isFinite(n)&&n>=0);
  return {features,reportedTotal:Number.isFinite(reportedTotal)?reportedTotal:null};
}
function ringId(ring){
  const a=ring.map(p=>`${p.lat.toFixed(6)},${p.lon.toFixed(6)}`);
  if(a.length>1&&a[0]===a[a.length-1])a.pop();
  if(a.length===0)return '';
  // Rotations/directions are normalized so overlapping tile responses dedupe.
  let first=0;for(let i=1;i<a.length;i++)if(a[i]<a[first])first=i;
  const forward=[],reverse=[];
  for(let i=0;i<a.length;i++){forward.push(a[(first+i)%a.length]);reverse.push(a[(first-i+a.length)%a.length]);}
  return (forward.join(';')<reverse.join(';')?forward:reverse).join(';');
}
function tileKey(b){return b.map(x=>x.toFixed(7)).join(':');}
function splitTile(b){
 const [s,w,n,e]=b,ym=(s+n)/2,xm=(w+e)/2;
 return [[s,w,ym,xm],[s,xm,ym,e],[ym,w,n,xm],[ym,xm,n,e]];
}
async function queryBuildingTile(b,signal){
 signal?.throwIfAborted();
 const key=tileKey(b),saved=tileCache.get(key);
 if(saved&&Date.now()-saved.at<15*60*1000)return {...saved.value,fromCache:true};
 const [south,west,north,east]=b;
 const sources=[
  {source:'도로명주소 건물',endpoint:'/req/data',params:{service:'data',request:'GetFeature',version:'2.0',data:'LT_C_SPBD',geomFilter:`BOX(${west},${south},${east},${north})`,geometry:'true',crs:'EPSG:4326',format:'json',errorformat:'json',size:String(TILE_CAP),page:'1'}},
  {source:'GIS건물통합 WFS',endpoint:'/ned/wfs/getBldgisSpceWFS',params:{bbox:[south,west,north,east].join(','),srsName:'EPSG:4326',output:'application/json',format:'json',maxFeatures:String(TILE_CAP)}},
  {source:'2D 건물정보',endpoint:'/req/data',params:{service:'data',request:'GetFeature',version:'2.0',data:'LT_C_BLDGINFO',geomFilter:`BOX(${west},${south},${east},${north})`,geometry:'true',crs:'EPSG:4326',format:'json',errorformat:'json',size:String(TILE_CAP),page:'1'}}
 ];
 const errors=[],diagnostics=[];let primary=null;
 for(const [sourceIndex,item] of sources.entries()){
  try{
   const {features,reportedTotal}=await fetchVWorldJSON(item.source,item.endpoint,item.params,signal);
   const elements=[];for(const f of features)elements.push(...fromGeometry(f.geometry,f.properties||{},b));
   if(features.length&&!elements.length)throw Error('도형 좌표 변환 실패');
   const value={elements,source:item.source,reportedTotal,count:features.length,truncated:features.length>=TILE_CAP||(reportedTotal!==null&&reportedTotal>features.length)};
   diagnostics.push({source:item.source,ok:true,...schemaSummary(features),truncated:value.truncated});
   if(!primary||!primary.elements.length){primary=value;
    // Subdivide capped geometry first. Otherwise query the second source when any height is missing.
    if(sourceIndex<sources.length-1&&!value.truncated&&(!elements.length||elements.some(x=>!x.tags.height)||!elements.some(x=>x.tags.shade_hub_identity)))continue;
   }else if(item.source==='GIS건물통합 WFS' && value.elements.some(building => building.tags.shade_hub_identity)) {
    // Use the GIS source's own geometry with its own parcel identity.
    // Different source footprints are never attached by proximity.
    const merged = enrichExact(value.elements, primary.elements);
    primary = {...value, elements: merged.elements, supplemented: merged.upgraded};
   }else if(!value.truncated){
    const merged=enrichExact(primary.elements,value.elements);primary={...primary,elements:merged.elements,supplemented:(primary.supplemented||0)+merged.upgraded};
   }
   if(sourceIndex<sources.length-1&&!primary.truncated&&(primary.elements.some(x=>!x.tags.height)||(sourceIndex===0&&!primary.elements.some(x=>x.tags.shade_hub_identity))))continue;
   break;
  }catch(err){signal?.throwIfAborted();errors.push(safeProviderText(err.message));diagnostics.push({source:item.source,ok:false});}
 }
 if(!primary)throw new Error(errors.join(' / ').slice(0,300));
 signal?.throwIfAborted();
 const value={...primary,heightDiagnostics:diagnostics};
 if(tileCache.size>=90)tileCache.delete(tileCache.keys().next().value);tileCache.set(key,{at:Date.now(),value});return value;
}

async function upstreamBuildings(bbox,plannedTiles,deadline=Date.now()+180000,signal){
 if(!VWORLD_KEY)throw new Error('VWorld 인증키가 설정되지 않았어요. .env의 VWORLD_API_KEY를 확인해 주세요.');
 const counts={requested:0,completed:0,split:0,cache:0,failed:0,capped:0};
 const failures=[],heightDiagnostics=[],coverageGaps=[];
 const unique=new Map();
 let bestSource='VWorld 2D 건물정보';
 // The worker pool bounds concurrent calls and avoids overloading the free provider.
 const queue=(plannedTiles||splitTile(bbox)).map(b=>({bbox:b,depth:0}));
 async function worker(){
  while(queue.length){
   signal?.throwIfAborted();
   const task=queue.shift();if(!task)break;
   if(counts.requested>=MAX_REMOTE_CALLS||Date.now()>deadline){counts.capped++;coverageGaps.push(task.bbox,...queue.map(t=>t.bbox));queue.length=0;break;}
   counts.requested++;
   try{
    const tile=await queryBuildingTile(task.bbox,signal);
    if(tile.fromCache)counts.cache++;heightDiagnostics.push(...(tile.heightDiagnostics||[]));
    if(tile.truncated){
     if(task.depth<TILE_MAX_DEPTH && counts.requested+queue.length+4<=MAX_REMOTE_CALLS){
      queue.push(...splitTile(task.bbox).map(b=>({bbox:b,depth:task.depth+1})));
      counts.split++;continue;
     }
     counts.capped++;coverageGaps.push(task.bbox);
    }
    counts.completed++;
    bestSource=tile.source;
    for(const entry of tile.elements){
     const signature=ringId(entry.geometry);
     if(!signature)continue;
     if(!unique.has(signature))unique.set(signature,entry);else {const old=unique.get(signature),rank=b=>b.tags.height?2:b.tags['building:levels']?1:0;if(rank(entry)>rank(old))unique.set(signature,entry);}
     if(unique.size>=MAX_BUILDINGS){counts.capped++;break;}
    }
    if(unique.size>=MAX_BUILDINGS){coverageGaps.push(task.bbox,...queue.map(t=>t.bbox));queue.length=0;break;}
   }catch(err){
    signal?.throwIfAborted();
    counts.failed++;coverageGaps.push(task.bbox);
    failures.push(safeProviderText(err.message).slice(0,120));
   }
  }
 }
 const workers=await Promise.allSettled(Array.from({length:3},()=>worker()));
 const failure=workers.find(worker=>worker.status==='rejected');
 if(failure)throw failure.reason;
 const partial=counts.failed>0||counts.capped>0||queue.length>0;
 const elements=[...unique.values()];
 if(!elements.length&&counts.failed)throw new Error('VWorld 분할 조회 실패: '+failures[0]);
 return {elements,bbox,source:'VWorld '+bestSource,buildingsOnly:true,
   partial,coverageGaps,tiles:counts,heightDiagnostics,supplementedHeights:elements.filter(x=>x.tags.shade_height_supplemented).length,realHeights:elements.filter(x=>x.tags.height).length,
   floorEstimates:elements.filter(x=>x.tags['building:levels']).length,
   unknownHeights:elements.filter(x=>!x.tags.height&&!x.tags['building:levels']).length,
   totalFeatures:elements.length,
   warning:partial?'일부 구역 조회 실패·상한 도달: 그늘 비율 분석 비활성화':''};
}
async function vworldBuildings(res,url){
  const bbox=osmBBox(url.searchParams);
  if(!bbox){send(res,400,{error:'대한민국 범위의 올바른 좌표가 필요해요.'});return;}
  if(!VWORLD_KEY){send(res,503,{error:'VWorld 키가 아직 설정되지 않았어요. .env에 VWORLD_API_KEY=... 를 추가해 주세요.'});return;}
  const k=bbox.map(n=>n.toFixed(5)).join(':');
  const hit=vwCache.get(k);
  if(hit&&Date.now()-hit.at<15*60*1000){send(res,200,{...hit.data,cached:true});return;}
  if(!vwPending.has(k))vwPending.set(k,upstreamBuildings(bbox).then(data=>{
    if(vwCache.size>18)vwCache.delete(vwCache.keys().next().value);
    vwCache.set(k,{at:Date.now(),data});return data;
  }).finally(()=>vwPending.delete(k)));
  try{send(res,200,await vwPending.get(k));}
  catch(err){console.warn('[SHADE/VWorld]',String(err.message).slice(0,150));send(res,502,{error:err.message||'VWorld 데이터 조회 실패'});}
}


// NASA JPL Horizons observer ephemeris (solar AZ/EL): ON-DEMAND verification only.
// The user's api.nasa.gov key is not required for JPL Horizons.
const nasaCache=new Map();let nasaLastRequest=0,nasaBusy=false;
async function nasaSun(res,url){
 const sp=url.searchParams,lat=validKorea(sp.get('lat'),32.8,39),lng=validKorea(sp.get('lng'),124,132);
 const date=sp.get('date'),clock=sp.get('time');
 if(lat===null||lng===null||!/^20\d\d-\d\d-\d\d$/.test(date||'')||!/^\d\d:\d\d$/.test(clock||''))return send(res,400,{error:'날짜, 시간 또는 좌표가 올바르지 않습니다.'});
 const k=[lat.toFixed(3),lng.toFixed(3),date,clock].join(':');
 const cached=nasaCache.get(k);if(cached){send(res,200,{...cached,cached:true});return;}
 if(nasaBusy||Date.now()-nasaLastRequest<12000)return send(res,429,{error:'NASA API 호출 간격을 유지해야 합니다. 잠시 뒤 다시 시도해 주세요.'});
 const dateObj=new Date(`${date}T${clock}:00+09:00`);
 if(!Number.isFinite(dateObj.getTime())||dateObj.getUTCFullYear()<2000||dateObj.getUTCFullYear()>2100)return send(res,400,{error:'지원하지 않는 날짜입니다.'});
 const stamp=d=>d.toISOString().slice(0,16).replace('T',' ');
 const params=new URLSearchParams({format:'json',COMMAND:"'10'",OBJ_DATA:"'NO'",MAKE_EPHEM:"'YES'",EPHEM_TYPE:"'OBSERVER'",CENTER:"'coord@399'",COORD_TYPE:"'GEODETIC'",SITE_COORD:`'${lng.toFixed(5)},${lat.toFixed(5)},0'`,START_TIME:`'${stamp(dateObj)}'`,STOP_TIME:`'${stamp(new Date(dateObj.getTime()+180000))}'`,STEP_SIZE:"'1m'",QUANTITIES:"'4'",CSV_FORMAT:"'YES'",APPARENT:"'AIRLESS'",TIME_DIGITS:"'MINUTES'"});
 nasaBusy=true;nasaLastRequest=Date.now();
 try{
  const response=await fetch('https://ssd.jpl.nasa.gov/api/horizons.api?'+params,{signal:AbortSignal.timeout(14000),headers:{Accept:'application/json'}});
  if(!response.ok)throw new Error('NASA 서버 응답 '+response.status);
  const payload=await response.json(),raw=payload.result||'';
  if(!raw.includes('$$SOE')||!raw.includes('$$EOE'))throw new Error('관측표를 반환하지 않았습니다.');
  const lines=raw.split('$$SOE')[1].split('$$EOE')[0].trim().split(/\r?\n/);
  let parsed=null;
  for(const line of lines){
   // CSV_FORMAT=YES, QUANTITIES=4: date[, illumination flag], azimuth, elevation.
   const nums=line.split(',').map(x=>x.trim()).filter(x=>x!=='' && /^[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?$/.test(x)).map(Number);
   if(nums.length>=2){const el=nums[nums.length-1],az=nums[nums.length-2];if(az>=0&&az<=360&&el>=-90&&el<=90){parsed={azimuth:az,elevation:el};break;}}
  }
  if(!parsed)throw new Error('NASA 태양 고도/방위각 표를 읽지 못했습니다.');
  const data={...parsed,source:'NASA JPL Horizons, airless Sun topocentric',at:stamp(dateObj)+' UTC'};
  if(nasaCache.size>=120)nasaCache.delete(nasaCache.keys().next().value);
  nasaCache.set(k,data);send(res,200,data);
 }catch(e){console.warn('[NASA/JPL]',String(e.message).slice(0,140));send(res,502,{error:e.name==='TimeoutError'?'NASA 서버 응답 시간 초과':'NASA 검증 실패: '+e.message});}
 finally{nasaBusy=false;}
}

const crypto=require('node:crypto');
const A=require('./analysis');
const Journey=require('./journey'),Context=require('./route-context');
const cfg=k=>String(process.env[k]||ENV[k]||'');
const production=cfg('NODE_ENV')==='production';
const origin=cfg('APP_ORIGIN')||`http://${HOST}:${PORT}`;
const sessions=new Map(), attempts=new Map(),requestRates=new Map();
let analysing=0;
const dataDir=process.env.SHADE_DATA_DIR||path.join(ROOT,'data'),correctionPath=path.join(dataDir,'heights.json');
let corrections={};
let correctionHistory=[];
 try{const stored=JSON.parse(fs.readFileSync(correctionPath,'utf8'));correctionHistory=Array.isArray(stored._history)?stored._history:[];for(const [id,c] of Object.entries(stored))if(/^[a-f0-9]{24}$/.test(id)&&Number.isFinite(c.height)&&c.height>=2&&c.height<=400)corrections[id]=c;}catch(e){if(e.code!=='ENOENT')console.error('Height corrections could not be loaded; check data/heights.json');}
const ADMIN_USER=cfg('ADMIN_USERNAME'),ADMIN_HASH=cfg('ADMIN_PASSWORD_HASH');
function passwordOK(password){
 const [kind,salt,hex]=ADMIN_HASH.split(':');
 if(kind!=='scrypt'||!salt||!/^([a-f0-9]{128})$/.test(hex||''))return false;
 return crypto.timingSafeEqual(crypto.scryptSync(password,salt,64),Buffer.from(hex,'hex'));
}
function session(req){const token=(req.headers.cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('shade_session='))?.slice(14);const value=sessions.get(token);if(!value)return null;if(value.expires<Date.now()){sessions.delete(token);return null;}return {...value,token};}
function limited(map,key,max,ms){const now=Date.now();for(const [k,v] of map)if(v.until<now)map.delete(k);let v=map.get(key);if(!v){if(map.size>5000)return true;v={count:0,until:now+ms};map.set(key,v);}return ++v.count>max;}
async function body(req){let raw='';for await(const part of req){raw+=part;if(raw.length>16000)throw Error('요청이 너무 큽니다.');}try{return JSON.parse(raw);}catch{throw Error('JSON 요청이 필요합니다.');}}
function csrf(req,s){return req.headers.origin===origin&&req.headers['x-csrf-token']===s.csrf;}
function capture(fn,...args){return new Promise((resolve,reject)=>{let status=200;const res={writeHead(n){status=n;},end(raw){const d=JSON.parse(raw);status>=400?reject(Object.assign(Error(d.error||'조회 실패'),{status})):resolve(d);}};Promise.resolve(fn(res,...args)).catch(reject);});}
async function places(res,url){
 const q=(url.searchParams.get('q')||'').trim();if(q.length<2||q.length>80)return send(res,400,{error:'검색어는 2~80자로 입력해 주세요.'});
 if(!API_KEY)return send(res,503,{error:'장소 검색 서비스가 아직 준비되지 않았어요.'});
 try{const r=await fetch('https://dapi.kakao.com/v2/local/search/keyword.json?'+new URLSearchParams({query:q,size:'6'}),{headers:{Authorization:'KakaoAK '+API_KEY},signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error();const j=await r.json();let items=(j.documents||[]).map(p=>({name:p.place_name,address:p.road_address_name||p.address_name,lat:Number(p.y),lng:Number(p.x)}));
 if(!items.length){const address=await fetch('https://dapi.kakao.com/v2/local/search/address.json?'+new URLSearchParams({query:q,size:'6'}),{headers:{Authorization:'KakaoAK '+API_KEY},signal:AbortSignal.timeout(10000)});if(!address.ok)throw Error();const a=await address.json();items=(a.documents||[]).map(p=>({name:p.road_address?.address_name||p.address_name,address:p.address_name,lat:Number(p.y),lng:Number(p.x)}));}
 send(res,200,{places:items.filter(p=>Number.isFinite(p.lat)&&Number.isFinite(p.lng)&&p.lat>=32.8&&p.lat<=39&&p.lng>=124&&p.lng<=132)});}catch{send(res,502,{error:'장소 검색에 연결할 수 없어요. 다시 시도해 주세요.'});}
}
const roadCache=new Map();
async function roadNetwork(bbox,signal){
 signal?.throwIfAborted();
 const key=bbox.map(x=>x.toFixed(5)).join(':');const cached=roadCache.get(key);if(cached&&Date.now()-cached.at<900000)return cached.data;
 if((bbox[2]-bbox[0])*(bbox[3]-bbox[1])>.002)throw Object.assign(Error('road area limit'),{code:'ROAD_AREA_LIMIT'});
 for(const endpoint of OSM_ENDPOINTS){try{const query=`[out:json][timeout:15];way["highway"]["area"!="yes"](${bbox.join(',')});out geom;`;
 const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded',Accept:'application/json'},body:new URLSearchParams({data:query}).toString(),signal:requestSignal(signal,16000)});if(!r.ok)throw Error('network');const raw=await r.text();if(raw.length>12000000)throw Error('size');const json=JSON.parse(raw);if(!Array.isArray(json.elements)||json.elements.length>=5000||json.remark)throw Error('incomplete network');const data={elements:json.elements,source:'OpenStreetMap'};if(roadCache.size>=20)roadCache.delete(roadCache.keys().next().value);roadCache.set(key,{at:Date.now(),data});return data;}catch{signal?.throwIfAborted();}}
 throw Error('보행로 조회를 완료하지 못했어요.');
}
async function routeBuildings(routes,deadline,signal){
 if(!VWORLD_KEY){const e=Error('건물 자료 연결 설정이 없어 그늘을 분석하지 못했어요.');e.code='BUILDING_NOT_CONFIGURED';e.publicMessage=e.message;throw e;}
 let plan;try{plan=Context.routeTiles(routes);}catch(error){error.code='AREA_LIMIT';error.publicMessage=error.message;throw error;}
 const data=await upstreamBuildings(plan.bbox,plan.boxes,deadline,signal);
 return hub.enrich(data,routes,deadline,signal);
}
async function calculateJourney(input,progress,signal,completedBuildings=new Map()){
 async function loadBuildings(routes){
  const key=JSON.stringify(routes.map(route=>route.coords));
  if(completedBuildings.has(key))return completedBuildings.get(key);
  const data=await routeBuildings(routes,deadline,signal);
  if(!data.partial&&!data.hub?.failed&&!data.hub?.deferredParcels&&completedBuildings.size<3)completedBuildings.set(key,data);
  return data;
 }
 const deadline=Date.now()+270000;
 const result=await Journey.findJourney(input,{compute:(module,method,args)=>require('./compute')(module,method,args,signal),progress,overrides:corrections,signal,buildings:loadBuildings,roads:bbox=>roadNetwork(bbox,signal),
 walk:(mode,via)=>{const params=new URLSearchParams({start_x:input.start.lng,start_y:input.start.lat,end_x:input.end.lng,end_y:input.end.lat,route_mode:mode});if(via.length){params.set('via_x',via.map(p=>p[1]).join(','));params.set('via_y',via.map(p=>p[0]).join(','));}return capture(out=>walking(null,out,new URL('/api/walk?'+params,origin),signal));}});
 signal?.throwIfAborted();
 const {diagnostic,...publicResult}=result;
 publicResult.buildingLookupFailed=Boolean(diagnostic?.tiles?.failed||diagnostic?.hub?.failed);
 try{fs.mkdirSync(dataDir,{recursive:true,mode:0o700});fs.writeFileSync(path.join(dataDir,'building-check.json'),JSON.stringify({at:new Date().toISOString(),version:VERSION,reasonCode:result.reasonCode,analysisMode:result.analysisMode,recommendationKind:result.recommendationKind,comparison:result.comparison,quality:result.quality,search:result.search,routeAudit:result.routes.map((r,i)=>({index:i,distance:r.distance,time:r.time,kind:r.analysis?.kind||null,calculatedShade:r.analysis?.knownShadeMidDistance??null,unclassified:r.analysis?.unclassifiedDistance??null,buildingOverlap:r.analysis?.buildingOverlapDistance??null,classifiedSun:r.analysis?.classifiedSunDistance??null,heightUncertain:r.analysis?.uncertainDistance??null,unknownReasons:r.analysis?.unknownReasonDistances??null})),...diagnostic},null,2),{mode:0o600});}catch{console.warn('[SHADE] Local diagnostic save failed.');}
 return publicResult;
}
async function analyse(req,res,progress=()=>{},input,signal,completedBuildings){
 let b=input||await body(req);try{Journey.validate(b);}catch(e){return send(res,400,{error:e.message});}
 if(analysing>=2)return send(res,429,{error:'다른 경로를 분석하고 있어요. 잠시 뒤 다시 시도해 주세요.'});
 analysing++;try{send(res,200,await calculateJourney(b,progress,signal,completedBuildings));}catch(e){send(res,signal?.aborted?504:e.status||502,{error:signal?.aborted?'분석 대기 시간이 길어졌어요. 가까운 구간으로 다시 찾아보세요.':e.message||'경로 분석을 완료하지 못했어요.'});}finally{analysing--;}
}
const jobs=new Map();
function pruneJobs(){for(const [id,j] of jobs)if(j.expires<Date.now()){j.controller.abort();jobs.delete(id);}}
async function publicSolarCheck(res,url){
 try{const d=A.departure(url.searchParams.get('date'),url.searchParams.get('time'));const reference=await capture(nasaSun,url);const local=require('./precision').sunPosition(d,Number(url.searchParams.get('lat')),Number(url.searchParams.get('lng')));const deltaElevation=Math.abs(reference.elevation-local.elevation),deltaAzimuth=Math.abs(((reference.azimuth-local.azimuth+540)%360)-180);send(res,200,{status:deltaElevation<=.7&&deltaAzimuth<=.7?'matched':'review',nasa:reference,local,deltaElevation,deltaAzimuth});}catch{send(res,503,{error:'NASA 태양 위치 비교를 완료하지 못했어요. 로컬 천문 계산을 사용합니다.'});}
}
const powerCache=new Map();
async function power(res,url){
 const lat=validKorea(url.searchParams.get('lat'),32.8,39),lng=validKorea(url.searchParams.get('lng'),124,132),date=url.searchParams.get('date');
 try{A.departure(date,'12:00');}catch{return send(res,400,{error:'올바른 날짜가 필요합니다.'});}
 if(lat===null||lng===null)return send(res,400,{error:'좌표 오류'});
 if(new Date(date+'T00:00:00Z')>=new Date())return send(res,422,{error:'POWER는 미래 예보가 아닙니다. 과거 날짜를 선택하세요.'});
 const cacheKey=lat.toFixed(3)+':'+lng.toFixed(3)+':'+date,hit=powerCache.get(cacheKey);if(hit&&Date.now()-hit.at<1800000)return send(res,200,hit.data);
 try{const day=date.replaceAll('-','');const r=await fetch('https://power.larc.nasa.gov/api/temporal/hourly/point?'+new URLSearchParams({parameters:'ALLSKY_SFC_SW_DWN',community:'RE',longitude:String(lng),latitude:String(lat),start:day,end:day,format:'JSON','time-standard':'UTC'}),{signal:AbortSignal.timeout(18000)});if(!r.ok)throw Error();const j=await r.json(),values=j.properties?.parameter?.ALLSKY_SFC_SW_DWN;if(!values)throw Error();const hours=Object.entries(values).filter(([,v])=>Number.isFinite(v)&&v>=0).map(([utc,value])=>({utc,value}));if(!hours.length)throw Error();const data={source:'NASA POWER',date,timeStandard:'UTC',unit:j.parameters?.ALLSKY_SFC_SW_DWN?.units||'제공기관 단위 미확인',hours,note:'광역 격자의 시간 평균 일사량 자료입니다. 해당 거리의 실제 일조량 또는 미래 예보가 아닙니다.'};if(powerCache.size>=100)powerCache.delete(powerCache.keys().next().value);powerCache.set(cacheKey,{at:Date.now(),data});send(res,200,data);}catch{send(res,502,{error:'NASA POWER 자료가 없거나 서버가 응답하지 않습니다.'});}
}
function file(res,name){const ext=path.extname(name);res.writeHead(200,{'Content-Type':({'.html':'text/html','.js':'application/javascript','.css':'text/css'})[ext]+'; charset=utf-8','Cache-Control':'no-store'});fs.createReadStream(path.join(ROOT,'public',name)).pipe(res);}
const server=http.createServer(async(req,res)=>{
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','strict-origin-when-cross-origin');res.setHeader('Cache-Control','no-store');
 res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' https://dapi.kakao.com https://*.daumcdn.net https://*.kakaocdn.net https://*.kakao.com; style-src 'self' 'unsafe-inline' https://*.daumcdn.net https://*.kakaocdn.net; img-src 'self' data: https://*.daumcdn.net https://*.kakao.com https://*.kakaocdn.net; connect-src 'self' https://*.kakao.com https://*.daum.net https://*.daumcdn.net https://*.kakaocdn.net; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'".replaceAll('https://*.daumcdn.net',production?'https://*.daumcdn.net':'https://*.daumcdn.net http://*.daumcdn.net').replaceAll('https://*.kakao.com',production?'https://*.kakao.com':'https://*.kakao.com http://*.kakao.com').replaceAll('https://*.kakaocdn.net',production?'https://*.kakaocdn.net':'https://*.kakaocdn.net http://*.kakaocdn.net'));
 try{
 const url=new URL(req.url,origin),p=url.pathname,ip=req.socket.remoteAddress;
 if(p==='/api/admin/login'&&req.method==='POST'){
 if(req.headers.origin!==origin)return send(res,403,{error:'허용되지 않은 출처입니다.'});
 if(limited(attempts,ip,5,15*60000))return send(res,429,{error:'로그인 시도가 많습니다. 15분 뒤 다시 시도하세요.'});
 const b=await body(req);if(!ADMIN_USER||!ADMIN_HASH)return send(res,503,{error:'서버에서 관리자 계정을 먼저 설정하세요.'});
 if(typeof b.password!=='string'||b.password.length>256||b.username!==ADMIN_USER||!passwordOK(b.password))return send(res,401,{error:'계정 정보를 확인하세요.'});
 for(const [k,v] of sessions)if(v.expires<Date.now())sessions.delete(k);
 if(sessions.size>=100)return send(res,429,{error:'세션 한도 초과'});
 const token=crypto.randomBytes(32).toString('hex'),value={csrf:crypto.randomBytes(24).toString('hex'),expires:Date.now()+8*3600000};sessions.set(token,value);
 res.setHeader('Set-Cookie',`shade_session=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${production?'; Secure':''}`);return send(res,200,{ok:true,csrf:value.csrf});
 }
 const isAdmin=p==='/admin'||p==='/admin/'||p==='/admin.html'||p==='/admin.js'||p.startsWith('/api/admin/')||['/api/buildings','/api/nasa-sun','/api/vworld-status','/api/osm','/api/power'].includes(p);
 const s=session(req);
 if(isAdmin&&!s){if(p.startsWith('/api/'))return send(res,401,{error:'관리자 로그인이 필요합니다.'});res.writeHead(303,{Location:'/admin/login'});return res.end();}
 if(isAdmin&&req.method!=='GET'&&!csrf(req,s))return send(res,403,{error:'요청 검증에 실패했습니다. 다시 로그인하세요.'});
 if(p.startsWith('/api/')&&p!=='/api/admin/login'&&limited(requestRates,ip,120,60000))return send(res,429,{error:'요청이 많습니다. 잠시 뒤 다시 시도하세요.'});
 if(req.method==='GET'){
 if(p==='/'||p==='/index.html')return file(res,'index.html');
 if(p==='/admin/login')return file(res,'login.html');
 if(p==='/admin'||p==='/admin/'||p==='/admin.html')return file(res,'admin.html');
 if(['/app.js','/map-loader.js','/map-visuals.js','/style.css','/experience.css','/admin.js','/login.js'].includes(p))return file(res,p.slice(1));
 if(p==='/api/health')return send(res,200,{ok:true,version:VERSION,build:BUILD});
 if(p==='/api/client-config')return send(res,200,{kakaoJavaScriptKey:/^[a-f0-9]{32}$/i.test(JS_KEY)?JS_KEY:''});
 if(p==='/api/places')return places(res,url);
 if(p==='/api/solar-check')return publicSolarCheck(res,url);
 if(p==='/api/solar-power'){if(limited(requestRates,'power:'+ip,8,60000))return send(res,429,{error:'일사량 조회가 많아요. 잠시 뒤 확인해 주세요.'});return power(res,url);}
 if(p==='/api/admin/session')return send(res,200,{csrf:s.csrf});
 if(p==='/api/admin/status'||p==='/api/vworld-status')return send(res,200,{kakao:!!API_KEY,vworld:!!VWORLD_KEY,javascript:!!JS_KEY,corrections:Object.keys(corrections).length,activeAnalyses:analysing});
 if(p==='/api/admin/buildings'||p==='/api/buildings')return vworldBuildings(res,url);
 if(p==='/api/osm')return osmArea(res,url);
 if(p==='/api/admin/heights')return send(res,200,{corrections});
 if(p==='/api/admin/sun'||p==='/api/nasa-sun'){
 try{const date=A.departure(url.searchParams.get('date'),url.searchParams.get('time'));const d=await capture(nasaSun,url);const local=require('./precision').sunPosition(date,Number(url.searchParams.get('lat')),Number(url.searchParams.get('lng')));return send(res,200,{nasa:d,local,deltaElevation:Math.abs(local.elevation-d.elevation),deltaAzimuth:Math.abs(((local.azimuth-d.azimuth+540)%360)-180)});}catch(e){return send(res,502,{error:e.message});}}
 if(p==='/api/admin/power'||p==='/api/power')return power(res,url);
 }
 if(p==='/api/journeys'&&req.method==='POST'){
 if(req.headers.origin!==origin)return send(res,403,{error:'허용되지 않은 출처입니다.'});pruneJobs();
 if(jobs.size>=32||limited(requestRates,'journey:'+ip,20,600000))return send(res,429,{error:'분석 요청이 많아요. 잠시 뒤 다시 시도해 주세요.'});
 const submitted=await body(req);
 const previous=submitted.retryJob?jobs.get(submitted.retryJob):null;
 if(submitted.retryJob&&(!previous||previous.status!=='done'))return send(res,404,{error:'이전 결과가 만료됐어요. 새로 검색해 주세요.'});
 const input=previous?previous.input:submitted;
 const completedBuildings=previous?.completedBuildings||new Map();
 try{Journey.validate(input);}catch(e){return send(res,400,{error:e.message});}
 const id=crypto.randomBytes(24).toString('hex'),job={input,completedBuildings,controller:new AbortController(),status:'running',phase:'ROUTES',message:'실제 도보 경로를 확인하고 있어요.',expires:Date.now()+600000};jobs.set(id,job);
 const signal=requestSignal(job.controller.signal,270000);
 let code=200;const output={writeHead(n){code=n;},end(raw){if(job.status==='cancelled')return;const value=JSON.parse(raw);job.status=code>=400?'error':'done';if(code>=400)job.error=value.error;else job.result=value;}};
 analyse(req,output,(phase,message,partial)=>{if(job.status==='cancelled')throw Error('분석을 취소했어요.');job.phase=phase;job.message=message;if(partial)job.partial=partial;},input,signal,completedBuildings).catch(()=>{if(job.status!=='cancelled'){job.status='error';job.error='분석 중 오류가 발생했어요.';}});
 return send(res,202,{id});
 }
 if(/^\/api\/journeys\/[a-f0-9]{48}$/.test(p)){
 pruneJobs();const job=jobs.get(p.split('/').at(-1));if(!job)return send(res,404,{error:'분석 기록이 만료됐어요. 다시 분석해 주세요.'});
 if(req.method==='DELETE'){if(req.headers.origin!==origin)return send(res,403,{error:'요청 출처를 확인할 수 없어요.'});job.status='cancelled';job.controller.abort();delete job.result;delete job.error;return send(res,200,{ok:true});}
 if(req.method==='GET')return send(res,200,{status:job.status,phase:job.phase,message:job.message,...(job.partial?{partial:job.partial}:{}),...(job.result?{result:job.result}:{}),...(job.error?{error:job.error}:{})});
 }
 if(p==='/api/analyse'&&req.method==='POST'){if(req.headers.origin!==origin)return send(res,403,{error:'허용되지 않은 출처입니다.'});return await analyse(req,res);}
 if(p==='/api/admin/logout'&&req.method==='POST'){sessions.delete(s.token);res.setHeader('Set-Cookie','shade_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');return send(res,200,{ok:true});}
 if(p==='/api/admin/height-history'&&req.method==='GET')return send(res,200,{history:correctionHistory});
 if(p==='/api/admin/heights'&&['POST','DELETE'].includes(req.method)){
 const b=await body(req);if(!/^[a-f0-9]{24}$/.test(b.id||''))return send(res,400,{error:'건물 ID 오류'});
 if(req.method==='POST'&&(!Number.isFinite(b.height)||b.height<2||b.height>400||typeof b.source!=='string'||b.source.trim().length<3||b.source.length>300))return send(res,400,{error:'2~400m 높이와 확인 근거(3~300자)를 입력하세요.'});
 const next={...corrections};if(req.method==='DELETE')delete next[b.id];else next[b.id]={height:b.height,source:b.source.trim(),updatedAt:new Date().toISOString(),updatedBy:ADMIN_USER};
 fs.mkdirSync(dataDir,{recursive:true,mode:0o700});const history=[...correctionHistory,{id:b.id,action:req.method,at:new Date().toISOString(),by:ADMIN_USER,before:corrections[b.id]||null,after:next[b.id]||null}];fs.writeFileSync(correctionPath+'.tmp',JSON.stringify({...next,_history:history},null,2),{mode:0o600});fs.renameSync(correctionPath+'.tmp',correctionPath);corrections=next;correctionHistory=history;return send(res,200,{ok:true});}
 send(res,404,{error:'존재하지 않는 주소입니다.'});
 }catch(e){if(!res.headersSent)send(res,400,{error:'요청을 처리하지 못했습니다. 입력과 서버 상태를 확인하세요.'});else res.end();}
});
if(require.main===module){
 server.on('error',e=>{console.error(e.code==='EADDRINUSE'?'5500 포트가 이미 사용 중입니다. 이전 SHADE 서버나 Live Server를 종료하세요.':e.code);if(process.send)process.send({type:'shade-error',code:e.code});process.exitCode=1;});
 server.listen(PORT,HOST,()=>{const url=`http://${HOST}:${server.address().port}`;console.log(`SHADE KOREA ${VERSION} | ${BUILD}\nFolder: ${ROOT}\n${url}`);if(process.send)process.send({type:'shade-ready',version:VERSION,build:BUILD,url});});
}
module.exports={server,buildingHeight,fromGeometry,upstreamBuildings,fetchVWorldJSON,queryBuildingTile,calculateJourney,walking,roadNetwork};

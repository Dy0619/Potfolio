(function(root,factory){const v=factory();if(typeof module==='object'&&module.exports)module.exports=v;else root.ShadeMapVisuals=v;})(typeof globalThis==='object'?globalThis:this,function(){
 'use strict';
 function wallShadows(rings,height,sun){if(!height||!sun||sun.elevation<=5||!Number.isFinite(height)||height<=0)return [];const length=height/Math.tan(sun.elevation*Math.PI/180);if(length>320)return [];const angle=sun.azimuth*Math.PI/180;const quads=[];
 for(const ring of rings){if(ring.length<3)continue;for(let i=0;i<ring.length;i++){const a=ring[i],b=ring[(i+1)%ring.length];if(a[0]===b[0]&&a[1]===b[1])continue;const lat=(a[0]+b[0])/2*Math.PI/180,north=111132.92-559.82*Math.cos(2*lat)+1.175*Math.cos(4*lat)-.0023*Math.cos(6*lat),east=111412.84*Math.cos(lat)-93.5*Math.cos(3*lat)+.118*Math.cos(5*lat),dy=-length*Math.cos(angle)/north,dx=-length*Math.sin(angle)/east;quads.push([a,b,[b[0]+dy,b[1]+dx],[a[0]+dy,a[1]+dx]]);}}
 return quads;
 }
 return {wallShadows};
});

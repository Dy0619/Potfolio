/* SDK connection lifecycle. Browser-independent adapter for regression tests. */
(function(root,factory){const value=factory();if(typeof module==='object'&&module.exports)module.exports=value;else root.ShadeMapLoader=value;})(typeof globalThis==='object'?globalThis:this,function(){
 'use strict';
 const valid=key=>typeof key==='string'&&/^[a-f0-9]{32}$/i.test(key.trim());
 function candidates(server,saved,manual){const seen=new Set();return [{key:manual,source:'manual'},{key:server,source:'server'},{key:saved,source:'saved'}].filter(c=>{if(!valid(c.key))return false;c.key=c.key.trim();if(seen.has(c.key))return false;seen.add(c.key);return true;});}
 function load(key,options={}){
  const w=options.window||window,d=options.document||document,stage=options.onStage||(()=>{}),schedule=options.setTimeout||setTimeout,cancel=options.clearTimeout||clearTimeout;
  if(!valid(key))return Promise.reject(Object.assign(Error('지도 연결 설정이 비어 있거나 올바르지 않아요.'),{code:'KEY_MISSING'}));
  if(typeof w.kakao?.maps?.Map==='function')return Promise.resolve();
  return new Promise((resolve,reject)=>{
   let finished=false,phase='SDK_REQUEST';const script=d.createElement('script');
   const timer=schedule(()=>fail(phase==='SDK_REQUEST'?'SDK_TIMEOUT':'SDK_INIT_TIMEOUT',phase==='SDK_REQUEST'?'지도 파일을 받는 시간이 초과됐어요.':'지도 초기화 응답이 오지 않았어요.'),options.timeoutMs||15000);
   function cleanup(){cancel(timer);d.removeEventListener('securitypolicyviolation',policy);script.onload=null;script.onerror=null;}
   function fail(code,message){if(finished)return;finished=true;cleanup();script.remove();reject(Object.assign(Error(message),{code}));}
   function policy(event){if(/(?:kakao\.com|daumcdn\.net|kakaocdn\.net)/i.test(event.blockedURI||''))fail('SDK_POLICY','브라우저의 보안 정책이 지도 파일 연결을 막았어요.');}
   d.addEventListener('securitypolicyviolation',policy);
   script.src='https://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey='+encodeURIComponent(key);script.async=true;
   script.onerror=()=>fail('SDK_NETWORK','카카오 지도 파일을 불러오지 못했어요. 지도 키·허용 주소·네트워크 설정을 확인해 주세요.');
   script.onload=()=>{if(finished)return;phase='SDK_INIT';stage(phase);if(typeof w.kakao?.maps?.load!=='function'){fail('SDK_RESPONSE','카카오 지도 초기화 함수를 받지 못했어요.');return;}
    try{w.kakao.maps.load(()=>{if(finished)return;if(typeof w.kakao?.maps?.Map!=='function'){fail('SDK_INCOMPLETE','지도 초기화가 완료되지 않았어요.');return;}finished=true;cleanup();resolve();});}catch{fail('SDK_INIT_ERROR','지도 초기화 중 오류가 발생했어요.');}
   };
   stage(phase);d.head.append(script);
  });
 }
 return {valid,candidates,load};
});

'use strict';
const $=id=>document.getElementById(id);let csrf='',buildings=[],heights={};const now=new Date(Date.now()+9*3600000).toISOString();$('date').value=now.slice(0,10);
async function request(url,method='GET',data){const r=await fetch(url,{method,headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},...(data?{body:JSON.stringify(data)}:{})});if(r.status===401){location.replace('/admin/login');throw Error('세션 만료');}const d=await r.json();if(!r.ok)throw Error(d.error);return d;}
function query(){return new URLSearchParams({lat:$('lat').value,lng:$('lng').value,date:$('date').value,time:$('time').value});}
async function run(button,out,work){$(button).disabled=true;$(out).textContent='조회 중…';try{await work();$('adminStatus').textContent='요청을 완료했습니다.';}catch(e){$(out).textContent=e.message;$('adminStatus').textContent='요청에 실패했습니다. 입력을 확인하고 다시 시도하세요.';}finally{$(button).disabled=false;}}
async function refresh(){const d=await request('/api/admin/status');$('diagnostic').textContent=`Kakao REST 키: ${d.kakao?'설정됨':'없음'}\n지도 SDK 키: ${d.javascript?'설정됨':'없음'}\nVWorld 키: ${d.vworld?'설정됨':'없음'}\n저장된 보정: ${d.corrections}개\n진행 중 분석: ${d.activeAnalyses}건`;}
async function loadHeights(){heights=(await request('/api/admin/heights')).corrections;const list=$('savedHeights');list.replaceChildren();for(const [id,c] of Object.entries(heights)){const b=document.createElement('button');b.className='building-option';b.textContent=`${id} · ${c.height}m · ${c.source}`;b.onclick=()=>{$('buildingId').value=id;$('height').value=c.height;$('source').value=c.source;$('buildingLocation').textContent='저장 시각: '+c.updatedAt;};list.append(b);}if(!list.children.length)list.textContent='저장된 보정이 없습니다.';}
function showBuildings(){drawAdminMap().catch(error=>{$('adminMapStatus').textContent=error.message;});const q=$('buildingFilter').value.trim();const list=$('buildings');list.replaceChildren();const rows=buildings.filter(b=>b.id.includes(q));for(const b of rows.slice(0,150)){const el=document.createElement('button');el.className='building-option';const t=b.tags;el.textContent=`${b.id} · ${heights[b.id]?'보정 '+heights[b.id].height+'m':t.height?'높이 제공 '+t.height+'m':t['building:levels']?'층수 '+t['building:levels']+'층':'높이 미상'}`;el.onclick=()=>{$('buildingId').value=b.id;$('height').value=heights[b.id]?.height||t.height||'';$('source').value=heights[b.id]?.source||'';$('buildingLocation').textContent=`도형 첫 좌표: ${b.geometry[0].lat}, ${b.geometry[0].lon} · 꼭짓점 ${b.geometry.length}개. 같은 높이의 여러 동인지 현장 자료로 확인하세요.`;};list.append(el);}if(rows.length>150){const p=document.createElement('p');p.textContent='처음 150개 표시. ID로 필터링하세요.';list.append(p);}}
$('buildingFilter').oninput=showBuildings;
$('refreshStatus').onclick=()=>run('refreshStatus','diagnostic',refresh);
$('loadBuildings').onclick=()=>run('loadBuildings','buildingQuality',async()=>{const d=await request('/api/admin/buildings?'+query());buildings=d.elements;$('buildingQuality').textContent=`건물 ${d.totalFeatures}개 · 높이 제공 ${d.realHeights}개 · 층수 추정 ${d.floorEstimates}개 · 높이 미상 ${d.unknownHeights}개\n완전성: ${d.partial?'부분 자료 — 사용자 그늘 분석 중단':'조회 구역 완료 (현장 완전성 보장 아님)'}\n격자: ${JSON.stringify(d.tiles)}\n높이 보완 ${d.supplementedHeights||0}개\n응답 필드/원천 진단: ${JSON.stringify(d.heightDiagnostics||[])}`;showBuildings();});
$('saveHeight').onclick=()=>run('saveHeight','heightResult',async()=>{await request('/api/admin/heights','POST',{id:$('buildingId').value,height:Number($('height').value),source:$('source').value});$('heightResult').textContent='보정을 저장했습니다. 다음 사용자 분석부터 반영합니다.';await loadHeights();showBuildings();await refresh();});
$('deleteHeight').onclick=()=>run('deleteHeight','heightResult',async()=>{await request('/api/admin/heights','DELETE',{id:$('buildingId').value});$('heightResult').textContent='보정을 해제했습니다. 제공기관 원본과 추정 모델로 돌아갑니다.';await loadHeights();showBuildings();await refresh();});
$('verifySun').onclick=()=>run('verifySun','sunResult',async()=>{const d=await request('/api/admin/sun?'+query());$('sunResult').textContent=`NASA 고도 ${d.nasa.elevation.toFixed(3)}° / 방위각 ${d.nasa.azimuth.toFixed(3)}°\n로컬 고도 ${d.local.elevation.toFixed(3)}° / 방위각 ${d.local.azimuth.toFixed(3)}°\n차이: 고도 ${d.deltaElevation.toFixed(3)}° · 방위각 ${d.deltaAzimuth.toFixed(3)}°\n${d.deltaElevation>.7||d.deltaAzimuth>.7?'차이가 큽니다. 시간대·좌표·모델을 점검하세요.':'설정된 검토 기준 0.7° 이내입니다.'}\n${d.nasa.at}`;});
$('loadPower').onclick=()=>run('loadPower','powerResult',async()=>{const d=await request('/api/admin/power?'+query());$('powerResult').textContent=`${d.source} · ${d.date} · ${d.timeStandard}\n단위: ${d.unit}\n${d.hours.map(h=>h.utc+': '+h.value).join('\n')}\n${d.note}`;});
$('logout').onclick=async()=>{try{await request('/api/admin/logout','POST',{});location.replace('/admin/login');}catch(e){$('adminStatus').textContent=e.message;}};
(async()=>{try{csrf=(await request('/api/admin/session')).csrf;await refresh();await loadHeights();$('adminStatus').textContent='서버 인증 완료 · 세션은 8시간 뒤 만료됩니다.';}catch(e){$('adminStatus').textContent=e.message;}})();

let adminMap,adminShapes=[];
async function drawAdminMap(){
 if(!adminMap){
  const config=await request('/api/client-config');
  await ShadeMapLoader.load(config.kakaoJavaScriptKey);
  adminMap=new kakao.maps.Map($('adminMap'),{center:new kakao.maps.LatLng(Number($('lat').value),Number($('lng').value)),level:3});
 }
 adminShapes.forEach(shape=>shape.setMap(null));
 adminShapes=[];
 adminMap.setCenter(new kakao.maps.LatLng(Number($('lat').value),Number($('lng').value)));
 for(const building of buildings.slice(0,600)){
  const shape=new kakao.maps.Polygon({map:adminMap,path:building.geometry.map(point=>new kakao.maps.LatLng(point.lat,point.lon)),strokeWeight:1,strokeColor:'#25564d',fillColor:'#b8efcc',fillOpacity:.5});
  kakao.maps.event.addListener(shape,'click',()=>{
   $('buildingId').value=building.id;
   $('height').value=heights[building.id]?.height||building.tags.height||'';
   $('source').value=heights[building.id]?.source||'';
   $('buildingLocation').textContent='선택한 도형 · '+building.id+' · '+(building.tags.height?'제공 높이':building.tags['building:levels']?'층수 추정':'높이 미확인');
   adminShapes.forEach(item=>item.setOptions({fillColor:'#b8efcc'}));
   shape.setOptions({fillColor:'#f2c48d'});
   request('/api/admin/height-history').then(data=>{
    $('heightHistory').textContent=data.history.filter(item=>item.id===building.id).map(item=>JSON.stringify(item,null,2)).join('\n')||'저장된 변경 이력이 없습니다.';
   }).catch(error=>{$('heightHistory').textContent=error.message;});
  });
  adminShapes.push(shape);
 }
 $('adminMapStatus').textContent='도형을 눌러 보정 대상을 선택하세요. 최대 600개 표시합니다.';
}

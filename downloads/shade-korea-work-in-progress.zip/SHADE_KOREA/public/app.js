'use strict';
const $=id=>document.getElementById(id);
const S={start:null,end:null,map:null,pins:[],lines:[],pick:null,busy:false,result:null,buildings:[],shadows:[],exposure:[],showBuildings:false,showShadows:false,showExposure:true,selected:0,conditionVersion:0,controller:null};
let departNow=true,previewIndex=1;
const kst=new Date(Date.now()+9*3600000).toISOString();$('date').value=kst.slice(0,10);$('time').value=kst.slice(11,16);
function status(text,kind=''){$('status').textContent=text;$('status').className='status '+kind;}
async function api(url,options={}){const r=await fetch(url,{...options,headers:{'Content-Type':'application/json',...options.headers}});const j=await r.json();if(!r.ok)throw Object.assign(Error(j.error||'연결에 실패했어요.'),{status:r.status});return j;}
function clearResults(){$('timeExplorer').open=false;$('segmentSummary').open=false;updateLegend();$('timeFailure').hidden=true;$('segmentSummary').hidden=true;$('previewNotice').hidden=true;$('geometryWarning').hidden=true;$('results').classList.remove('preview-active');previewIndex=1;$('showRouteResults').hidden=true;$('timeExplorer').hidden=true;S.conditionsKey=null;S.conditionVersion++;$('conditions').hidden=true;[...S.buildings,...S.shadows,...S.exposure].forEach(x=>x.setMap(null));S.buildings=[];S.shadows=[];S.exposure=[];S.result=null;$('results').hidden=true;S.lines.forEach(l=>l?.setMap(null));S.lines=[];}
function drawPins(){S.pins.forEach(p=>p.setMap(null));S.pins=[];if(!S.map)return;for(const [key,label] of [['start','출발'],['end','도착']]){const p=S[key];if(!p)continue;const el=document.createElement('div');el.className='pin-label';el.textContent=label;const marker=new kakao.maps.CustomOverlay({position:new kakao.maps.LatLng(p.lat,p.lng),content:el,yAnchor:1.3});marker.setMap(S.map);S.pins.push(marker);}}
function choose(key,place){S[key]=place;$(key).value=place.name;$(key+'Hint').textContent=place.address||'지도에서 선택한 위치';closeList(key);clearResults();drawPins();if(S.map)S.map.panTo(new kakao.maps.LatLng(place.lat,place.lng));status(S.start&&S.end?'준비됐어요. 그늘진 길을 찾아보세요.':'도착지와 출발지를 모두 선택해 주세요.');}
function closeList(key){$(key+'List').hidden=true;$(key).setAttribute('aria-expanded','false');$(key).removeAttribute('aria-activedescendant');}
for(const key of ['start','end']){
 let timer,version=0,index=-1,options=[];const input=$(key),list=$(key+'List');
 function active(i){index=i;[...list.children].forEach((el,n)=>el.setAttribute('aria-selected',String(n===i)));if(i>=0){input.setAttribute('aria-activedescendant',`${key}Option${i}`);list.children[i]?.scrollIntoView({block:'nearest'});}}
 input.addEventListener('input',()=>{S[key]=null;clearResults();drawPins();clearTimeout(timer);version++;const stamp=version,q=input.value.trim();closeList(key);$(key+'Hint').textContent='검색 결과에서 장소를 선택해 주세요.';if(q.length<2)return;
 timer=setTimeout(async()=>{try{$(key+'Hint').textContent='장소를 찾고 있어요…';const data=await api('/api/places?q='+encodeURIComponent(q));if(stamp!==version||input.value.trim()!==q||document.activeElement!==input)return;options=data.places;index=-1;list.replaceChildren();for(const [i,p] of options.entries()){const el=document.createElement('div');el.id=`${key}Option${i}`;el.setAttribute('role','option');el.setAttribute('aria-selected','false');const title=document.createElement('span');title.textContent=p.name;const address=document.createElement('small');address.textContent=p.address;el.append(title,address);el.addEventListener('mousedown',e=>e.preventDefault());el.addEventListener('click',()=>{version++;choose(key,p);});list.append(el);}list.hidden=!options.length;input.setAttribute('aria-expanded',String(options.length>0));$(key+'Hint').textContent=options.length?'장소를 선택하거나 방향키와 Enter를 눌러 주세요.':'검색 결과가 없어요. 지역명을 함께 입력해 보세요.';}catch(e){if(stamp===version)$(key+'Hint').textContent=e.message;}},300);
 });
 input.addEventListener('keydown',e=>{if(e.key==='Escape'){closeList(key);return;}if(list.hidden)return;if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();active((index+(e.key==='ArrowDown'?1:-1)+options.length)%options.length);}if(e.key==='Enter'&&index>=0){e.preventDefault();version++;choose(key,options[index]);}});
 input.addEventListener('blur',()=>setTimeout(()=>closeList(key),160));
 input.addEventListener('focus',()=>{if(S.pick){S.pick=null;document.querySelectorAll('.map-pick').forEach(b=>b.setAttribute('aria-pressed','false'));}});
}
$('swap').onclick=()=>{const a=S.start,b=S.end;if(!a&&!b)return;S.start=b;S.end=a;for(const key of ['start','end']){$(key).value=S[key]?.name||'';$(key+'Hint').textContent=S[key]?.address||'검색 결과에서 장소를 선택해 주세요.';closeList(key);}clearResults();drawPins();status('출발지와 도착지를 바꿨어요. 다시 분석해 주세요.');};
function setDepartureMode(now){departNow=now;$('departureFields').hidden=now;$('departNow').setAttribute('aria-pressed',String(now));$('departLater').setAttribute('aria-pressed',String(!now));$('departureHint').textContent=now?'검색을 누르는 시각으로 계산해요. 한국 시각(KST)을 사용해요.':'한국 시각(KST)으로 출발 날짜와 시간을 골라 주세요.';}
$('departNow').onclick=()=>{setDepartureMode(true);const now=new Date(Date.now()+9*3600000).toISOString();$('date').value=now.slice(0,10);$('time').value=now.slice(11,16);clearResults();status('현재 시각으로 출발해요. 경로를 검색해 주세요.');};
$('departLater').onclick=()=>{if(departNow){setDepartureMode(false);clearResults();status('출발 날짜와 시간을 선택해 주세요.');}$('date').focus();};
for(const id of ['date','time'])$(id).addEventListener('change',()=>setDepartureMode(false));
$('extraMinutes').onchange=()=>{$('advancedDetour').hidden=$('extraMinutes').value!=='advanced';clearResults();};
 for(const id of ['date','time','detour'])$(id).addEventListener('change',()=>{clearResults();status('출발 조건이 바뀌었어요. 다시 분석해 주세요.');});
function exposureTime(seconds){return seconds<60?Math.max(0,Math.round(seconds))+'초':Math.round(seconds/60)+'분';}
function formatDistance(d){return d>=1000?(d/1000).toFixed(2)+' km':Math.round(d)+' m';}
function focusRoute(index){S.selected=index;
 const check=S.result?.routes[index]?.geometryCheck;
 $('geometryWarning').hidden=!(check?.lengthMismatch||check?.overlapWarning);
 $('geometryWarning').textContent=check?.lengthMismatch?'제공 거리와 경로 도형 길이에 차이가 커 좌표 확인이 필요해요.':check?.overlapWarning?'경로가 건물 도형과 많이 겹쳐요. 좌표 오차나 실내 연결통로일 수 있어 해당 구간의 그늘 판정을 보류했어요.':'';
if(!S.map||!S.result)return;const route=S.result.routes[index],bounds=new kakao.maps.LatLngBounds();route.coords.forEach(p=>bounds.extend(new kakao.maps.LatLng(p[0],p[1])));S.map.setBounds(bounds,70,50,70,50);S.lines.forEach((l,i)=>{l?.setOptions({strokeOpacity:i===index?1:.35,strokeWeight:i===index?7:4});});document.querySelectorAll('.route-card').forEach(b=>(b.classList.toggle('selected',Number(b.dataset.index)===index),b.setAttribute('aria-pressed',String(Number(b.dataset.index)===index))));updateTimePreview();animateSelectedRoute(index);}
function card(title,r,index,tag){const el=document.createElement(index===null?'div':'button');el.className='route-card '+(title.startsWith('최단')?'route-shortest':'route-shade');if(index!==null){el.type='button';el.dataset.index=index;el.onclick=()=>focusRoute(index);}const heading=document.createElement('div');heading.className='card-heading';const name=document.createElement('span');name.textContent=title;const badge=document.createElement('span');badge.className='tag';badge.textContent=tag;heading.append(name,badge);el.append(heading);
 if(!r){const p=document.createElement('p');p.className='result-note';p.textContent='그늘 경로를 추천할 자료가 부족해요.';el.append(p);return el;}
 const metrics=document.createElement('div');metrics.className='route-metrics';const time=document.createElement('strong');time.textContent=Math.ceil(r.time/60)+'분';const distance=document.createElement('span');distance.textContent=formatDistance(r.distance);metrics.append(time,distance);el.append(metrics);
 const shade=document.createElement('div');shade.className='shade-value';el.append(shade);
 if(r.analysis?.kind==='reference'){
  const metres=r.analysis.knownShadeMidDistance;shade.textContent=metres>.5?'높이 자료 기준 그늘 약 '+formatDistance(metres):'확인한 높이 자료로는 그늘 구간 미확인';
  const range=document.createElement('small');range.className='shade-range';range.textContent=r.analysis.unclassifiedDistance>.5?'그늘 여부 미확인 '+formatDistance(r.analysis.unclassifiedDistance):'부분 자료 · 추정 범위 제한';el.append(range);
  if(metres>.5&&formatDistance(r.analysis.knownShadeLowDistance)!==formatDistance(r.analysis.knownShadeHighDistance)){const bounds=document.createElement('small');bounds.className='shade-range';bounds.textContent=`높이 가정 범위 ${formatDistance(r.analysis.knownShadeLowDistance)}–${formatDistance(r.analysis.knownShadeHighDistance)}`;el.append(bounds);}
 }else{
  shade.textContent=r.analysis?'예상 그늘 '+Math.round(r.analysis.mid*100)+'%':'그늘 자료 미확보';
  if(r.analysis){const range=document.createElement('small');range.className='shade-range';range.textContent=Math.round(r.analysis.low*100)===Math.round(r.analysis.high*100)?'건물 그림자 모델의 예측값':`자료 가정에 따른 범위 ${Math.round(r.analysis.low*100)}–${Math.round(r.analysis.high*100)}%`;const bar=document.createElement('div');bar.className='shade-bar';const fill=document.createElement('div');fill.style.width=(r.analysis.mid*100)+'%';bar.append(fill);el.append(range,bar);const exposure=document.createElement('small');exposure.className='shade-range';exposure.textContent='예상 햇빛 노출 '+exposureTime(r.analysis.exposedSeconds??r.time*(1-r.analysis.mid));el.append(exposure);}
 }
 return el;
}
function describeResult(result) {
 const search=result.search||{};
 const code=result.reasonCode;
 const failures=[];
 if(result.buildingLookupFailed||['BUILDING_FETCH_FAILED','HEIGHT_LOOKUP_FAILED'].includes(code)||search.status==='expanded_data_failed')failures.push('건물 자료');
 if(['network_unavailable','unavailable'].includes(search.networkStatus)||search.status==='network_unavailable')failures.push('주변 보행로');
 if(result.candidateFailures||search.verificationFailures)failures.push('우회 후보');
 const lookupFailed=failures.length>0;
 const searchLimited=[search.status,search.networkStatus].some(state=>
  ['network_limit','network_not_connected','expanded_data_insufficient'].includes(state));
 if(result.comparison==='different') {
  const reference=result.analysisMode==='reference';
  const heading=reference?'그늘 우선 참고 경로를 찾았어요':'햇빛을 덜 받는 경로를 찾았어요';
  let note=reference?'확보한 건물 자료로 계산한 참고 경로예요. 전체 햇빛 노출은 비교하기 어려워요.':
   '확인한 후보 중 예상 햇빛 노출이 줄어드는 경로예요.';
  if(result.recommendationRobust===false)note+=' 건물 높이 가정에 따라 추천이 달라질 수 있어요.';
  if(lookupFailed)note+=' 미완료 조회 · '+failures.join(', ');
  else if(searchLimited)note+=' 확인 가능한 후보만 비교했어요.';
  return {heading,note,retry:lookupFailed};
 }
 if(result.routes[0]?.analysisReason==='SUN_TOO_LOW')
  return {heading:'이 시간에는 그늘 비교가 어려워요',note:'걷는 동안 태양이 낮아요. 낮 시간으로 바꿔 다시 찾아보세요.'};
 if(lookupFailed)
  return {heading:'최단 경로를 찾았어요',note:failures.join(', ')+' 조회가 미완료예요. 그늘 우회 비교에 영향을 줄 수 있어요.',retry:true};
 if(code==='AREA_LIMIT')
  return {heading:'건물 조회 범위가 너무 넓어요',note:result.reason};
 if(result.coverageMismatch)return {heading:'최단 경로를 찾았어요',note:'미확인 구간 비율 차이가 커서 그늘 우회 추천을 보류했어요.'};
 if(result.analysisMode==='reference'||result.comparison==='unavailable'||result.routes.some(route=>!route.analysis))
  return {heading:'최단 경로를 찾았어요',note:result.comparison==='unavailable'&&result.reason?result.reason:
   '최단 경로와 계산 가능한 구간을 표시해요. 확보한 자료로는 어느 길이 햇빛을 덜 받는지 판단하기 어려워요.'};
 if(searchLimited)
  return {heading:'우회 경로 탐색 범위가 제한됐어요',note:'최단 경로를 표시해요. 출발지나 도착지를 바꿔 더 짧은 구간을 검색해 보세요.'};
 if(result.routes.length===1)
  return {heading:'비교할 다른 길을 찾지 못했어요',note:'선택한 우회 범위 안에서 도보 경로 한 개를 확인했어요.'};
 return {heading:'햇빛 노출을 충분히 줄이는 우회로가 없었어요',compareComplete:true,note:'선택한 우회 범위 안에서 확인한 후보의 예상 햇빛 노출 시간을 비교했어요.'};
}
let retryJob=null,lastCompletedJob=null;
$('retryJourney').onclick=()=>{if(S.busy)return;retryJob=lastCompletedJob;$('routeForm').requestSubmit();};
function render(result){S.result=result;previewIndex=result.comparisonMode==='now'?0:1;$('resultTime').hidden=false;$('resultTime').textContent='검색 결과 기준 · '+(result.departure||$('date').value+' '+$('time').value+' KST');$('timeFailure').hidden=!result.timeComparisonFailed;$('results').hidden=false;$('showRouteResults').hidden=false;$('routeCards').replaceChildren();const shortest=result.routes[0],shady=result.shady===null?null:result.routes[result.shady];$('routeCards').append(card('최단 경로',shortest,0,'카카오 도보'));
 if(result.shady!==null&&result.shady!==0)$('routeCards').append(card(result.analysisMode==='reference'?'그늘 우선 참고 경로':'그늘 우선 경로',shady,result.shady,result.analysisMode==='reference'?'부분 자료로 비교':'햇빛 노출 감소 예상'));
 $('timeExplorer').hidden=!result.timeComparison?.length;

 const outcome=describeResult(result);
 updateHighlight(result,outcome);
 $('candidateCount').textContent='비교에 사용한 경로 '+result.routes.length+'개';
 $('resultHeading').textContent='경로 선택';
 $('resultNote').textContent=outcome.note;
 $('resultNote').hidden=Boolean(outcome.compareComplete);
 $('retryJourney').hidden=!outcome.retry;
 const q=result.quality;$('quality').textContent=q?`높이 제공 ${q.provided}개(관리자 보정 ${q.corrected}개 포함) · 층수 추정 ${q.floorEstimated}개 · 높이 미확인 ${q.missing??q.assumed}개 · 다른 자료로 보완 ${q.supplemented||0}개. 제공 높이는 현장 실측 여부를 별도로 보장하지 않아요.`:'건물 자료를 확인하지 못해 그늘 비율을 계산하지 않았어요.';

 if(S.map){S.lines.forEach(l=>l?.setMap(null));S.lines=result.routes.map((r,i)=>{if(i!==0&&i!==result.shady)return null;const line=new kakao.maps.Polyline({path:r.coords.map(p=>new kakao.maps.LatLng(p[0],p[1])),strokeWeight:6,strokeColor:i===result.shady&&i!==0?'#20a774':'#628ffc',strokeStyle:i===result.shady&&i!==0?'dash':'solid',strokeOpacity:.4});line.setMap(S.map);return line;});focusRoute(result.shady??0);}$('mapCaption').textContent=`${$('date').value} · ${$('time').value} KST 기준`;updateConditions(result);updateTimePreview();status('');}
const progressGroup={
 ROUTES:'routes',BUILDINGS:'buildings',SHADE_SEARCH:'compare',VERIFY_ROUTES:'compare',
 CHECK_COVERAGE:'compare',RESULTS:'compare',TIME_COMPARE:'compare'
};
function showProgress(phase,message){
 for(const item of $('analysisProgress').querySelectorAll('[data-phase]')){
  if(item.dataset.phase===progressGroup[phase])item.setAttribute('aria-current','step');
  else item.removeAttribute('aria-current');
 }
 if($('status').textContent!==message)status(message,'loading');
}
function waitForPoll(signal,delay){
 signal.throwIfAborted();
 return new Promise((resolve,reject)=>{
  const timer=setTimeout(()=>{signal.removeEventListener('abort',abort);resolve();},delay);
  function abort(){clearTimeout(timer);reject(signal.reason);}
  signal.addEventListener('abort',abort,{once:true});
 });
}
async function pollJourney(input,signal){
 // Keep the submission alive long enough to obtain its ID if the user cancels early.
 const {id}=await api('/api/journeys',{method:'POST',body:JSON.stringify(input),signal:AbortSignal.timeout(15000)});
 const url='/api/journeys/'+id,deadline=Date.now()+290000;
 let finished=false,failures=0,partialPhase=null;
 try{
  while(Date.now()<deadline){
   signal.throwIfAborted();
   let job;
   try{
    const request=AbortSignal.any([signal,AbortSignal.timeout(10000)]);
    job=await api(url,{signal:request});
    failures=0;
   }catch(error){
    signal.throwIfAborted();
    if((error.status&&error.status<500)||++failures>3)throw error;
    status('분석 상태에 다시 연결하고 있어요.','loading');
    await waitForPoll(signal,failures*1500);
    continue;
   }
   if(job.status==='done'){finished=true;lastCompletedJob=id;return job.result;}
   if(job.status==='error'){finished=true;throw Error(job.error);}
   if(job.status==='cancelled'){finished=true;throw new DOMException('cancelled','AbortError');}
   if(!input.retryJob&&job.partial&&partialPhase!==job.phase){
    partialPhase=job.phase;
    if(job.partial.comparison==='pending'){
     $('resultTime').hidden=true;$('retryJourney').hidden=true;$('routeHighlight').hidden=true;$('candidateCount').textContent='';$('segmentSummary').hidden=true;
     $('results').hidden=false;
     $('resultHeading').textContent='최단 경로를 먼저 확인하세요';
     $('routeCards').replaceChildren(card('최단 경로',job.partial.routes[0],null,'그늘 분석 중'));
     $('resultNote').hidden=false;$('resultNote').textContent='그늘 비교가 끝나면 결과가 갱신됩니다.';
     if(S.map){
      S.lines.forEach(line=>line?.setMap(null));
      const path=job.partial.routes[0].coords.map(p=>new kakao.maps.LatLng(p[0],p[1]));
      S.lines=[new kakao.maps.Polyline({map:S.map,path,strokeWeight:6,strokeColor:'#628ffc'})];updateLegend(['shortest']);
     }
    }else render(job.partial);
   }
   showProgress(job.phase,job.message);
   await waitForPoll(signal,1200);
  }
  throw Error('분석 시간이 길어지고 있어요. 가까운 구간으로 다시 찾아보세요.');
 }finally{
  if(!finished)api(url,{method:'DELETE',keepalive:true,signal:AbortSignal.timeout(8000)}).catch(()=>{});
 }
}
function moveToSection(id){
 const section=$(id);
 section.focus({preventScroll:true});
 section.scrollIntoView({block:'start'});
}
$('showRouteMap').onclick=()=>moveToSection('mapStage');
$('showRouteResults').onclick=()=>moveToSection('results');
$('routeForm').onsubmit=async event=>{
 event.preventDefault();
 if(S.busy)return;
 if(!S.start||!S.end){
  status('검색 결과에서 출발지와 도착지를 모두 선택해 주세요.','error');
  (!S.start?$('start'):$('end')).focus();
  return;
 }
 const retry=retryJob;retryJob=null;
 if(departNow&&!retry){
  const now=new Date(Date.now()+9*3600000).toISOString();
  $('date').value=now.slice(0,10);$('time').value=now.slice(11,16);
 }
 if(!$('date').value||!$('time').value){status('날짜와 출발 시간을 선택해 주세요.','error');return;}
 S.busy=true;
 if(!retry){lastCompletedJob=null;clearResults();}
 const controller=new AbortController();
 S.controller=controller;
 const controls=document.querySelectorAll('#routeForm input,#routeForm select,#routeForm button:not(#cancelAnalyse)');
 controls.forEach(el=>el.disabled=true);
 $('analysisProgress').hidden=false;
 $('analysisWait').hidden=true;
 $('cancelAnalyse').disabled=false;
 $('analyse').textContent='그늘 우회 경로를 찾고 있어요…';
 showProgress('ROUTES','최단 경로부터 확인하고 있어요.');
 const slowTimer=setTimeout(()=>{$('analysisWait').hidden=false;},12000);
 let completed=false;
 try{
  const input={departureMode:departNow?'now':'scheduled',start:S.start,end:S.end,date:$('date').value,time:$('time').value,detour:Number($('detour').value),...($('extraMinutes').value==='advanced'?{}:{extraMinutes:Number($('extraMinutes').value)})};
  const result=await pollJourney(retry?{retryJob:retry}:input,controller.signal);
  controller.signal.throwIfAborted();
  render(result);
  completed=true;
 }catch(error){
  const cancelled=controller.signal.aborted||error.name==='AbortError';
  $('resultNote').hidden=false;
  if(retry&&S.result){
   $('resultNote').textContent=(cancelled?'재확인을 취소했어요. ':'재확인을 완료하지 못했어요. ')+(cancelled?'':error.message+' ')+'이전 경로 결과를 표시하고 있어요.';
  }else if(!$('results').hidden){
   $('resultHeading').textContent=cancelled?'분석을 취소했어요.':'분석을 완료하지 못했어요.';
   $('resultNote').textContent=S.result?'완료된 경로 비교는 확인할 수 있어요.':'확인된 최단 경로의 거리와 소요 시간을 표시해요.';
   const tag=$('routeCards').querySelector('.tag');
   if(!S.result&&tag)tag.textContent='카카오 도보';
   $('retryJourney').hidden=false;
  }
  status(cancelled?'분석을 취소했어요.':error.message,cancelled?'':'error');
 }finally{
  clearTimeout(slowTimer);
  S.busy=false;
  S.controller=null;
  $('analysisProgress').hidden=true;
  controls.forEach(el=>el.disabled=false);
  $('analyse').textContent='◒  그늘진 길 찾아보기  ↗';
  if(completed){
   $('usePreviewTime').disabled=previewIndex===(S.result?.comparisonMode==='now'?0:1);
   if(window.matchMedia?.('(max-width: 650px)').matches)moveToSection('results');
  }else if(controller.signal.aborted)$('analyse').focus();
 }
};
$('cancelAnalyse').onclick=()=>{
 $('cancelAnalyse').disabled=true;
 status('분석을 취소하고 있어요.','loading');
 S.controller?.abort();
};
function updateLegend(routes=[],segments=[]){
 const shown=new Set([...routes,...segments.map(segment=>segment.kind)]);
 const legend=$('mapLegend');
 legend.hidden=!shown.size;
 for(const item of legend.querySelectorAll('[data-legend]'))item.hidden=!shown.has(item.dataset.legend);
}
function drawExposure(){
 const routes=S.lines.flatMap((line,index)=>line?[index===0?'shortest':'alternative']:[]);
 updateLegend(routes);
S.exposure.forEach(x=>x.setMap(null));S.exposure=[];if(!S.map||!S.showExposure||!S.result)return;const r=S.result.routes[S.selected];const segments=(S.result.timeComparison?.[previewIndex]?.routes[S.selected]?.analysis||(!S.result.timeComparison?r?.analysis:null))?.segments||[];updateLegend(routes,segments);for(const seg of segments){const line=new kakao.maps.Polyline({map:S.map,path:seg.coords.map(p=>new kakao.maps.LatLng(p[0],p[1])),strokeWeight:5,strokeColor:seg.kind==='shade'?'#159c69':seg.kind==='sun'?'#ed9837':seg.kind==='unknown'?'#8a929c':'#8a7caa',strokeStyle:seg.kind==='uncertain'||seg.kind==='unknown'?'dash':'solid',strokeOpacity:.95,zIndex:5});S.exposure.push(line);}}
function drawContext(){
 [...S.buildings,...S.shadows].forEach(x=>x.setMap(null));S.buildings=[];S.shadows=[];if(!S.map||!S.result?.visuals)return;const data=S.result.visuals;$('visualScope').textContent=`경로 주변 건물 ${data.buildings.length}개 표시${data.truncated?' · 표시 수·범위 제한 있음':''} · 계산된 그림자`;
 if(!S.showBuildings&&!S.showShadows)return;
 for(const b of data.buildings){if(S.showBuildings){const paths=b.rings.map(r=>r.map(p=>new kakao.maps.LatLng(p[0],p[1])));const outline=new kakao.maps.Polygon({path:paths,strokeWeight:1,strokeColor:b.height?'#486273':'#9a9fa5',strokeOpacity:.7,fillColor:b.source==='floors'?'#8b84a6':'#71828d',fillOpacity:.14,zIndex:1});outline.setMap(S.showBuildings?S.map:null);S.buildings.push(outline);}
  if(S.showShadows&&b.height)for(const quad of ShadeMapVisuals.wallShadows(b.rings,b.height.mid,(S.result.timeComparison?.[previewIndex]?.sun||data.sun)).slice(0,Math.max(1,Math.floor(6000/data.buildings.length)))){if(S.shadows.length>=6000)break;const shadow=new kakao.maps.Polygon({path:quad.map(p=>new kakao.maps.LatLng(p[0],p[1])),strokeWeight:0,fillColor:'#2a5572',fillOpacity:.14,zIndex:0});shadow.setMap(S.showShadows?S.map:null);S.shadows.push(shadow);}
 }
}
for(const [id,key] of [['toggleBuildings','showBuildings'],['toggleShadows','showShadows']])$(id).onclick=()=>{S[key]=!S[key];$(id).setAttribute('aria-pressed',String(S[key]));drawContext();};
$('toggleExposure').onclick=()=>{S.showExposure=!S.showExposure;$('toggleExposure').setAttribute('aria-pressed',String(S.showExposure));drawExposure();};
async function updateConditions(result){
 const key=JSON.stringify([S.start?.lat,S.start?.lng,$('date').value,$('time').value]);if(S.conditionsKey===key&&!$('conditions').hidden)return;S.conditionsKey=key;const version=++S.conditionVersion;$('conditions').hidden=false;const sun=result.sun||result.visuals?.sun;updateSunGraphic(sun);if(sun)$('sunCondition').textContent=sun.elevation>5?`태양 높이 ${sun.elevation.toFixed(1)}° · ${['북','북동','동','남동','남','남서','서','북서'][Math.round(sun.azimuth/45)%8]}쪽 하늘`:'태양이 낮거나 진 시간이에요. 낮 시간의 그늘길 비교가 어려워요.';
 $('nasaCondition').textContent='NASA 기준 태양 위치와 비교 중…';$('powerCondition').textContent='과거 광역 일사량 자료 확인 중…';
 $('sunCondition').textContent='검색 기준 '+$('date').value+' '+$('time').value+' KST · '+$('sunCondition').textContent;
 const params=new URLSearchParams({lat:String(S.start.lat),lng:String(S.start.lng),date:$('date').value,time:$('time').value});
 api('/api/solar-check?'+params,{signal:AbortSignal.timeout(20000)}).then(d=>{if(version!==S.conditionVersion)return;$('nasaCondition').textContent=`NASA JPL 교차 확인: 고도 차이 ${d.deltaElevation.toFixed(3)}°, 방향 차이 ${d.deltaAzimuth.toFixed(3)}°. ${d.status==='matched'?'로컬 천문 계산과 비교 기준 이내예요.':'차이가 커서 재검토가 필요해요.'}`;}).catch(()=>{if(version===S.conditionVersion)$('nasaCondition').textContent='NASA 태양 위치 비교를 완료하지 못했어요. 로컬 천문 계산을 사용했어요.';});
 $('powerCondition').textContent='참고 자료를 열면 과거 광역 일사량을 조회합니다.';
 const details=$('powerCondition').closest('details');
 let loaded=false;
 details.ontoggle=()=>{if(details.open)loadPower();};
 function loadPower(){
  if(loaded)return;loaded=true;
 const instant=new Date($('date').value+'T'+$('time').value+':00+09:00');if(+instant>Date.now()){ $('powerCondition').textContent='NASA POWER는 미래 예보 자료가 아니어서 선택한 시각의 일사량을 제공하지 않아요.';return;}
 const date=instant.toISOString().slice(0,10),hour=instant.toISOString().slice(0,13).replaceAll('-','').replace('T','');params.set('date',date);
 api('/api/solar-power?'+params,{signal:AbortSignal.timeout(22000)}).then(d=>{if(version!==S.conditionVersion)return;const h=d.hours.find(h=>h.utc===hour);$('powerCondition').textContent=h?`NASA POWER 광역 일사량: ${h.value} ${d.unit} · ${date} ${instant.getUTCHours()}:00 UTC 시간 평균. 현장 날씨나 길 위의 순간값은 아니에요.`:'선택 시각의 NASA POWER 일사량 자료는 아직 없어요.';}).catch(()=>{if(version===S.conditionVersion)$('powerCondition').textContent='선택 날짜의 NASA POWER 자료가 없거나 연결하지 못했어요. 그늘 경로 수치에 임의로 대입하지 않았어요.';});
 }
 if(details.open)loadPower();
}
document.querySelectorAll('.map-pick').forEach(button=>button.onclick=()=>{if(!S.map){status('지도를 연결한 뒤 위치를 선택해 주세요.','error');return;}S.pick=button.dataset.target;document.querySelectorAll('.map-pick').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));status((S.pick==='start'?'출발':'도착')+' 위치를 지도에서 눌러 주세요.');$('map').scrollIntoView({block:'center',behavior:'smooth'});});
$('zoomIn').onclick=()=>S.map?.setLevel(S.map.getLevel()-1);$('zoomOut').onclick=()=>S.map?.setLevel(S.map.getLevel()+1);
let mapConnecting=false;
const MAP_KEY_STORAGE='shade-korea-kakao-javascript-key-v1';
const localSetup=['127.0.0.1','localhost','::1'].includes(location.hostname);
function savedMapKey(){try{return localStorage.getItem(MAP_KEY_STORAGE)||'';}catch{return '';}}
function saveMapKey(key){try{localStorage.setItem(MAP_KEY_STORAGE,key);}catch{}}
function mapDiagnostic(code,source){$('mapSetup').hidden=!localSetup;$('mapDiagnostic').textContent=`단계: ${code} · 설정: ${source||'없음'} · 현재 주소: ${location.origin} · 키 값은 표시하지 않습니다. 카카오 웹 허용 주소와 현재 주소가 같은지 확인하세요.`;}
async function connectMap(manualKey=''){
 if(S.map||mapConnecting)return;
 mapConnecting=true;$('retryMap').disabled=true;$('applyMapKey').disabled=true;$('retryMap').textContent='연결 중…';$('mapStatus').textContent='지도 연결 설정을 확인하고 있어요.';
 let source='none',connectedKey='';
 try{
  let config={};
  try{config=await api('/api/client-config',{signal:AbortSignal.timeout(8000)});}catch{mapDiagnostic('CONFIG_REQUEST_FAILED','saved fallback');}
  const choices=ShadeMapLoader.candidates(config.kakaoJavaScriptKey,savedMapKey(),manualKey);
  if(!choices.length)throw Object.assign(Error('사용할 지도 연결 설정이 없어요. 기존 지도 키를 아래에서 연결해 주세요.'),{code:'KEY_MISSING'});
  let failure;
  for(const choice of choices){source=choice.source;
   try{await ShadeMapLoader.load(choice.key,{onStage:phase=>{$('mapStatus').textContent=phase==='SDK_REQUEST'?'카카오 지도 파일을 불러오고 있어요.':'지도 화면을 준비하고 있어요.';mapDiagnostic(phase,source);}});connectedKey=choice.key;failure=null;break;}catch(e){failure=e;}
  }
  if(failure)throw failure;
  // Assign only after successful construction, so retry is possible after constructor failure.
  const map=new kakao.maps.Map($('map'),{center:new kakao.maps.LatLng(35.158,129.06),level:5});S.map=map;
  if(source==='manual')saveMapKey(connectedKey);
  $('mapKey').value='';$('mapFallback').hidden=true;drawPins();
  kakao.maps.event.addListener(map,'click',event=>{if(!S.pick||S.busy)return;const key=S.pick;choose(key,{lat:event.latLng.getLat(),lng:event.latLng.getLng(),name:'지도에서 선택한 '+(key==='start'?'출발지':'도착지'),address:`${event.latLng.getLat().toFixed(5)}, ${event.latLng.getLng().toFixed(5)}`});S.pick=null;document.querySelectorAll('.map-pick').forEach(b=>b.setAttribute('aria-pressed','false'));});
  if(typeof ResizeObserver==='function')new ResizeObserver(()=>{const c=map.getCenter();map.relayout();map.setCenter(c);}).observe($('map'));
  if(S.result)render(S.result);
 }catch(e){$('mapStatus').textContent=e.code?e.message:'지도 화면을 만들지 못했어요. 아래 연결 상태를 확인해 주세요.';mapDiagnostic(e.code||'MAP_CREATE_ERROR',source);if(localSetup)$('mapSetup').open=true;}
 finally{mapConnecting=false;$('retryMap').disabled=false;$('applyMapKey').disabled=false;$('retryMap').textContent='지도 다시 연결';}
}
$('mapKeyForm').onsubmit=e=>{e.preventDefault();const key=$('mapKey').value.trim();if(!ShadeMapLoader.valid(key)){$('mapStatus').textContent='JavaScript 키 32자리를 확인해 주세요.';return;}connectMap(key);};
$('mapSetup').hidden=!localSetup;
$('retryMap').onclick=()=>connectMap();connectMap();

function updateHighlight(result,outcome) {
 const base=result.routes[0];
 const alternative=result.comparison==='different'?result.routes[result.shady]:null;
 const complete=alternative&&result.analysisMode==='complete'&&result.savedExposureSeconds>0;
 const gain=alternative?.analysis?.knownShadeMidDistance-base.analysis?.knownShadeMidDistance;
 const extra=alternative?alternative.time-base.time:0;
 const cost=extra>0?'약 '+exposureTime(extra)+' 더 걸으면':'추가 도보 시간 없이';
 const label=$('highlightLabel'), value=$('highlightValue'), detail=$('highlightDetail');
 label.textContent=alternative?cost:'지금 걸을 길';
 if(complete){
  value.textContent='햇빛을 약 '+exposureTime(result.savedExposureSeconds)+' 덜 받아요';
  detail.textContent='확인한 후보에서 계산한 예상값이에요.'+(result.recommendationRobust===false?' 건물 높이 가정에 따라 차이가 달라질 수 있어요.':'');
 }else if(alternative&&result.analysisMode==='reference'){
  value.textContent=gain>=1?'계산된 그늘 약 '+formatDistance(gain)+' 더':'그늘 우회 후보가 있어요';
  detail.textContent='확보한 건물 자료 기준이에요. 전체 햇빛 노출 시간의 차이는 확인하기 어려워요.';
 }else if(outcome.compareComplete){
  value.textContent='이번에는 빠른 길을 추천해요';
  detail.textContent='비교한 후보 중 우회할 만큼 예상 햇빛 노출이 줄어드는 길을 찾지 못했어요.';
 }else{
  value.textContent='빠른 길로 갈 수 있어요';
  detail.textContent='햇빛을 덜 받는 우회 길이 있는지는 판단하기 어려워요.';
  if(base.analysisReason==='SUN_TOO_LOW')detail.textContent='이 시각에는 태양이 낮아 그늘 차이를 비교하기 어려워요.';
 }
 $('routeHighlight').hidden=false;
 $('routeHighlight').classList.toggle('decision-neutral',!complete);
}
let routeAnimation = 0;
function animateSelectedRoute(index) {
 cancelAnimationFrame(routeAnimation);
 const line = S.lines[index];
 if (!line || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
 const started = performance.now();
 function frame(now) {
  if (!S.result || S.selected !== index || S.lines[index] !== line) return;
  const progress = Math.min(1, (now - started) / 420);
  line.setOptions({strokeOpacity: .45 + .55 * progress});
  if (progress < 1) routeAnimation = requestAnimationFrame(frame);
 }
 routeAnimation = requestAnimationFrame(frame);
}
function updateSunGraphic(sun) {
 const graphic = $('sunGraphic');
 graphic.hidden = !Number.isFinite(sun?.elevation) || sun.elevation < 0;
 if (graphic.hidden) return;
 const angle = Math.max(0, Math.min(90, sun.elevation)) * Math.PI / 180;
 graphic.style.setProperty('--sun-x', (50 - 44 * Math.cos(angle)) + '%');
 graphic.style.setProperty('--sun-y', (92 - 80 * Math.sin(angle)) + '%');
}

const reasonLabels={height_missing:'태양 쪽 건물 높이 미확인',source_incomplete:'조회 범위 누락·실패',geometry_unsupported:'건물 도형 판정 제한',shadow_limit:'낮은 태양·그림자 계산 범위 제한',building_overlap:'경로와 건물 도형 겹침',unclassified:'기타 판정 불가'};
function renderSegmentSummary(analysis,route){
 $('segmentSummary').hidden=!analysis;if(!analysis)return;
 const entries=[['shade','그늘 예상',analysis.knownShadeLowDistance],['sun','햇빛 예상',analysis.classifiedSunDistance],['uncertain','높이에 따라 달라짐',analysis.uncertainDistance],['unknown','미확인',analysis.unclassifiedDistance]];
 $('segmentBar').replaceChildren();$('segmentValues').replaceChildren();
 for(const [kind,label,distance] of entries){const value=Number.isFinite(distance)?Math.max(0,distance):0;if(value<.5)continue;const bar=document.createElement('span');bar.className='segment-'+kind;bar.style.width=(route.distance>0?value/route.distance*100:0)+'%';$('segmentBar').append(bar);const item=document.createElement('li');const dot=document.createElement('i');dot.className='segment-'+kind;const text=document.createElement('span');text.textContent=label;const metric=document.createElement('strong');metric.textContent=formatDistance(value);item.append(dot,text,metric);$('segmentValues').append(item);}
 const reasons=Object.entries(analysis.unknownReasonDistances||{}).filter(([,v])=>v>.01).map(([key,value])=>(reasonLabels[key]||'판정 불가')+' '+formatDistance(value));
 $('segmentReasons').textContent=(reasons.length?'미확인 이유: '+reasons.join(' · ')+'. ':'')+'그늘 예상은 높이 가정 범위에서 공통으로 그늘인 구간이에요. 현장 실측이 아니며 거리 표시는 반올림됩니다.';
}
function updateTimePreview(){
 const preview=S.result?.timeComparison?.[previewIndex];
 const route=S.result?.routes[S.selected];
 const analysis=preview?preview.routes[S.selected]?.analysis:route?.analysis;
 renderSegmentSummary(analysis,route);
 $('segmentTime').textContent=(preview?preview.date+' '+preview.time+' KST':S.result?.departure||'')+' · 선택 경로';
 $('resetPreview').hidden=!preview?.offset;
 $('routeAudit').textContent=!analysis?'구간 판정 자료가 없어요.':`선택 경로 판정: 자료·판정 미확인 약 ${formatDistance(analysis.unclassifiedDistance||0)} · 이 중 건물 도형과 겹쳐 제외한 구간 약 ${formatDistance(analysis.buildingOverlapDistance||0)}. 경로 좌표와 도형의 불일치 또는 실내 통로일 수 있어 그늘로 계산하지 않아요. 높이 가정 범위는 전체 오차나 정확도를 뜻하지 않아요.`;
 if(!preview){drawContext();drawExposure();return;}
 for(const button of $('previewTimes').querySelectorAll('button')){
  const index=Number(button.dataset.preview),option=S.result.timeComparison[index];
  button.hidden=!option;
  button.setAttribute('aria-pressed',String(index===previewIndex));
  button.firstChild.textContent=(S.result.comparisonMode==='now'?['지금','30분 후','1시간 후']:['30분 전','선택 시각','30분 후'])[index]+' ';
  button.querySelector('span').textContent=option?.time||'';
 }
 $('previewLabel').textContent=(S.result.comparisonMode==='past'?'과거 시각 비교 · ':'같은 길 미리보기 · ')+preview.date+' '+preview.time+' KST';
 const a=preview.routes[S.selected]?.analysis;
 $('previewMetric').textContent=!a?'이 시각에는 태양이 낮거나 자료가 부족해 비교할 수 없어요.':a.kind==='reference'?'확보한 자료로 계산한 그늘 약 '+formatDistance(a.knownShadeMidDistance):'예상 햇빛 노출 '+exposureTime(S.result.routes[S.selected].time*(1-a.mid));
 const original=S.result.timeComparison[S.result.comparisonMode==='now'?0:1]?.routes[S.selected]?.analysis;
 const comparable=a&&original&&a.kind===original.kind;
 let change='검색 시각과 비교할 자료가 부족해요.';
 if(previewIndex===(S.result?.comparisonMode==='now'?0:1))change='검색한 출발 시각이에요. 다른 출발 시각을 비교해 보세요.';
 else if(comparable){
  const reference=a.kind==='reference';
  const delta=reference?a.knownShadeMidDistance-original.knownShadeMidDistance:S.result.routes[S.selected].time*(original.mid-a.mid);
  const threshold=reference?5:30;
  change=Math.abs(delta)<threshold?'선택 시각에서는 계산된 '+(reference?'그늘 거리':'햇빛 노출 시간')+' 변화가 작아요.':reference?'검색 시각보다 계산된 그늘이 약 '+formatDistance(Math.abs(delta))+(delta>0?' 늘어요.':' 줄어요.'):'검색 시각보다 예상 햇빛 노출이 약 '+exposureTime(Math.abs(delta))+(delta>0?' 늘어요.':' 줄어요.');
 }
 $('previewChange').textContent=change;
 $('previewScope').textContent=a?.kind==='reference'?'부분 자료 기반 예측 · 전체 햇빛 노출 시간은 판단하지 않아요.':'건물 그림자 모델의 예측 · 구름·나무·현장 상황은 반영하지 않아요.';
 $('usePreviewTime').disabled=previewIndex===(S.result?.comparisonMode==='now'?0:1)||S.busy;
 $('mapCaption').textContent=preview.date+' · '+preview.time+' KST'+(previewIndex===(S.result?.comparisonMode==='now'?0:1)?' 출발 기준':' 출발 미리보기 · 같은 길');
 $('results').classList.toggle('preview-active',preview.offset!==0);
 $('previewNotice').hidden=preview.offset===0;
 drawContext();drawExposure();
}
$('previewTimes').addEventListener('click',event=>{
 const button=event.target.closest('[data-preview]');
 if(!button||S.busy)return;
 previewIndex=Number(button.dataset.preview);
 updateTimePreview();
});
$('usePreviewTime').onclick=()=>{const p=S.result?.timeComparison?.[previewIndex];if(!p||S.busy)return;setDepartureMode(false);$('date').value=p.date;$('time').value=p.time;$('routeForm').requestSubmit();};

$('resetPreview').onclick=()=>{previewIndex=S.result.timeComparison.findIndex(item=>item.offset===0);updateTimePreview();$('previewTimes').querySelector('[aria-pressed=true]')?.focus();};

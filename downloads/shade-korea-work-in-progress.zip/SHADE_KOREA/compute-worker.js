'use strict';
const {parentPort,workerData}=require('node:worker_threads');
const modules={analysis:require('./analysis'),search:require('./walk-search'),journey:require('./journey')};
try{
 const value=modules[workerData.module][workerData.method](...workerData.args);
 parentPort.postMessage({value});
}catch(error){parentPort.postMessage({error:error.message});}
